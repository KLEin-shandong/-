import type { AppConfig } from "./config.ts";

export type AiTask = "explain" | "hint" | "analyze_error" | "recommend_review";

export interface AiRequestContext {
  task: AiTask;
  kpTitle: string;
  kpSummary: string[];
  questionPrompt?: string;
  questionOptions?: string[];
  hintLevel?: number;
  userAnswer?: string;
  correct?: boolean;
  reviewDue?: string[];
  recentStats?: string;
}

export interface AiResult {
  source: "ai" | "builtin";
  task: AiTask;
  content: string;
  hintLevel?: number;
  references: string[];
  fallbackReason?: string;
}

const SYSTEM_PROMPT = `你是中文微积分助教，服务对象是高中函数基础薄弱的大一学生。
要求：
1. 只使用简体中文，语气平静、具体，不使用“显然”“易知”。
2. 一次只处理一个主要动作，先解释符号再使用符号。
3. 不编造课程来源。不确定时明确说明。
4. hint 任务只给当前层级的提示，绝不直接给出最终答案。
5. 不输出 HTML、脚本或链接。可以使用简短 Markdown 和 $...$ 行内公式。
6. 必须只返回一个 JSON 对象，字段为：
   {"content": "字符串", "references": ["可选字符串"]}
不要输出 JSON 之外的任何文字。`;

function buildUserPrompt(ctx: AiRequestContext): string {
  const lines = [
    `任务：${ctx.task}`,
    `当前知识点：${ctx.kpTitle}`,
    `本节要点：${ctx.kpSummary.join("；")}`,
  ];
  if (ctx.questionPrompt) lines.push(`当前题目：${ctx.questionPrompt}`);
  if (ctx.questionOptions?.length) lines.push(`选项：${ctx.questionOptions.join(" / ")}`);
  if (ctx.hintLevel) lines.push(`提示层级：第 ${ctx.hintLevel} 级（1=思路，2=关键步骤，3=主要计算过程，均不得直接给最终答案）`);
  if (ctx.userAnswer) lines.push(`学生本次答案：${ctx.userAnswer}`);
  if (ctx.correct != null) lines.push(`判分结果：${ctx.correct ? "正确" : "错误"}`);
  if (ctx.reviewDue?.length) lines.push(`到期复习：${ctx.reviewDue.join("；")}`);
  if (ctx.recentStats) lines.push(`近期表现：${ctx.recentStats}`);
  lines.push("请按系统要求返回 JSON。");
  return lines.join("\n");
}

function sanitizeContent(text: string): string {
  return text
    .replace(/<script[\s\S]*?<\/script>/gi, "")
    .replace(/<style[\s\S]*?<\/style>/gi, "")
    .replace(/<[^>]+>/g, "")
    .replace(/javascript:/gi, "")
    .trim()
    .slice(0, 4000);
}

export async function callAi(config: AppConfig, ctx: AiRequestContext): Promise<AiResult> {
  const fallback = (reason: string): AiResult => ({
    source: "builtin",
    task: ctx.task,
    content: "",
    references: [],
    fallbackReason: reason,
  });

  if (!config.ai.enabled) return fallback("AI 未启用");
  if (!config.ai.baseUrl || !config.ai.model || !config.ai.apiKey) return fallback("AI 配置不完整");

  const base = config.ai.baseUrl.replace(/\/+$/, "");
  const url = base.endsWith("/chat/completions") ? base : `${base}/chat/completions`;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), config.ai.timeoutMs);
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${config.ai.apiKey}`,
      },
      body: JSON.stringify({
        model: config.ai.model,
        temperature: 0.2,
        max_tokens: 700,
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: buildUserPrompt(ctx) },
        ],
      }),
      signal: controller.signal,
    });
    if (!res.ok) return fallback(`上游返回 ${res.status}`);
    const data = (await res.json()) as {
      choices?: Array<{ message?: { content?: unknown } }>;
    };
    const raw = data.choices?.[0]?.message?.content;
    if (typeof raw !== "string" || !raw.trim()) return fallback("上游返回空内容");

    let parsed: unknown;
    const jsonText = raw.replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();
    try {
      parsed = JSON.parse(jsonText);
    } catch {
      return fallback("上游未返回预期 JSON");
    }
    if (!parsed || typeof parsed !== "object") return fallback("上游内容结构不符");
    const obj = parsed as { content?: unknown; references?: unknown };
    if (typeof obj.content !== "string" || !obj.content.trim()) return fallback("上游内容为空");
    const content = sanitizeContent(obj.content);
    if (!content) return fallback("上游内容不可用");
    const references = Array.isArray(obj.references)
      ? obj.references.filter((r): r is string => typeof r === "string").slice(0, 5)
      : [];
    if (ctx.task === "hint") {
      // 提示不能因 AI 而越过层级；内容长度也做限制
      if (content.length > 800) return fallback("提示内容过长");
    }
    return { source: "ai", task: ctx.task, content, hintLevel: ctx.hintLevel, references };
  } catch (e) {
    const msg = (e as Error).name === "AbortError" ? "AI 请求超时" : "AI 请求失败";
    return fallback(msg);
  } finally {
    clearTimeout(timer);
  }
}

export function builtinTask(
  task: AiTask,
  data: {
    kpSummary: string[];
    hint?: string;
    solutionFirstStep?: string;
    dueTitles?: string[];
  },
): string {
  switch (task) {
    case "explain":
      return `这节课的核心是：${data.kpSummary.join("；")}。如果不确定，先回到讲解里的例题，把每一步对应到符号上。`;
    case "hint":
      return data.hint ?? "先回到一级提示，找出题目给出的条件。";
    case "analyze_error":
      return `先不急着改答案。${data.solutionFirstStep ?? "把题目条件逐条写下来，确认分母、根号与正负号。"} 对照你的步骤，找出第一个与它不同的地方。`;
    case "recommend_review":
      return data.dueTitles?.length
        ? `目前到期需要复习：${data.dueTitles.join("；")}。先完成这些，再开始新内容。`
        : "目前没有到期复习。可以先完成今天的小结，再决定是否继续新知识点。";
  }
}
