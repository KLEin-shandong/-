import { createHash, randomBytes } from "node:crypto";
import type { DB } from "./db.ts";
import { nowIso, randomId, tx } from "./db.ts";
import type { ContentBundle } from "./content.ts";
import type { AppConfig } from "./config.ts";
import type { Router, Ctx } from "./http.ts";
import { HttpError, sendJson, sameOrigin } from "./http.ts";
import {
  createUser,
  currentUser,
  findUserByUsername,
  login,
  logout,
  requireUser,
  validateCredentials,
  verifyPassword,
  type UserRow,
} from "./auth.ts";
import {
  allKpStates,
  attemptsForKp,
  applyReviewResult,
  dueReviews,
  findWrongNotebook,
  getKpState,
  getSession,
  getSettings,
  kpSummary,
  publicKnowledgePoint,
  questionSelection,
  reviewResultFromSession,
  saveKpState,
  sessionPayload,
  sessionState,
  statsForUser,
  updateSettings,
  updateStateAfterSubmission,
  upsertReview,
  type ReviewRow,
} from "./services.ts";
import { gradeAnswer, isIndependent } from "../shared/grading.ts";
import { shanghaiDate, addDays, recentDistinctFirstAttempts } from "../shared/learning.ts";
import type { AnswerValue, Difficulty, Question } from "../shared/types.ts";
import { builtinTask, callAi, type AiTask } from "./ai.ts";

export interface ApiDeps {
  db: DB;
  content: ContentBundle;
  config: AppConfig;
}

function str(v: unknown): string {
  return typeof v === "string" ? v : "";
}
function obj(v: unknown): Record<string, unknown> {
  return v && typeof v === "object" ? (v as Record<string, unknown>) : {};
}
function has(obj: Record<string, unknown>, key: string): boolean {
  return Object.prototype.hasOwnProperty.call(obj, key);
}
function secureReq(req: Ctx["req"]): boolean {
  return Boolean((req.socket as { encrypted?: boolean }).encrypted) || req.headers["x-forwarded-proto"] === "https";
}

function guard(req: Ctx["req"], method: string): void {
  if (method === "GET" || method === "HEAD") return;
  if (!sameOrigin(req)) throw new HttpError(403, "CSRF_REJECTED", "请求来源不被允许。");
}

function parseAnswerValue(v: unknown): AnswerValue {
  const o = obj(v);
  const kind = str(o.kind);
  if (kind === "steps") {
    const values = obj(o.values);
    const out: Record<string, string> = {};
    for (const [k, val] of Object.entries(values)) {
      if (typeof val !== "string" || val.length > 300) throw new HttpError(400, "INVALID_ANSWER", "答案格式不正确。");
      out[k] = val;
    }
    return { kind: "steps", values: out };
  }
  if (!["choice", "number", "fraction", "symbol", "expression"].includes(kind)) {
    throw new HttpError(400, "INVALID_ANSWER", "答案格式不正确。");
  }
  const value = str(o.value);
  if (value.length > 300) throw new HttpError(400, "INVALID_ANSWER", "答案过长。");
  return { kind: kind as AnswerValue["kind"], value } as AnswerValue;
}

function requireKp(content: ContentBundle, id: string) {
  const kp = content.kpById.get(id);
  if (!kp) throw new HttpError(404, "KP_NOT_FOUND", "知识点不存在。");
  return kp;
}

export function registerApi(router: Router, deps: ApiDeps): void {
  const { db, content, config } = deps;

  router.get("/api/health", (ctx) => {
    sendJson(ctx.res, 200, { ok: true, contentVersion: content.version, contentProblems: content.problems.length });
  });

  // ---------------- 认证 ----------------
  router.post("/api/auth/register", (ctx) => {
    guard(ctx.req, "POST");
    const b = obj(ctx.body);
    const { username, password } = validateCredentials(b.username, b.password);
    const count = Number((db.prepare("SELECT COUNT(*) AS n FROM users").get() as { n: number }).n);
    if (count > 0) {
      if (!config.allowRegistration) throw new HttpError(403, "REGISTRATION_CLOSED", "站点已关闭新账号注册。");
      if (config.signupCode && str(b.signupCode) !== config.signupCode) {
        throw new HttpError(403, "INVALID_SIGNUP_CODE", "邀请码不正确。");
      }
    }
    if (findUserByUsername(db, username)) throw new HttpError(409, "USERNAME_TAKEN", "用户名已被使用。");
    const user = createUser(db, username, password);
    login(db, ctx.res, user, secureReq(ctx.req));
    sendJson(ctx.res, 201, { user: { id: user.id, username: user.username } });
  });

  router.post("/api/auth/login", (ctx) => {
    guard(ctx.req, "POST");
    const b = obj(ctx.body);
    const username = str(b.username).trim();
    const password = str(b.password);
    if (!username || !password) throw new HttpError(400, "INVALID_REQUEST", "请填写用户名和密码。");
    const row = findUserByUsername(db, username);
    if (!row || !verifyPassword(password, row.password_hash)) {
      throw new HttpError(401, "INVALID_CREDENTIALS", "用户名或密码不正确。");
    }
    login(db, ctx.res, row, secureReq(ctx.req));
    sendJson(ctx.res, 200, { user: { id: row.id, username: row.username } });
  });

  router.post("/api/auth/logout", (ctx) => {
    guard(ctx.req, "POST");
    logout(db, ctx.req, ctx.res);
    sendJson(ctx.res, 200, { ok: true });
  });

  router.get("/api/auth/me", (ctx) => {
    const user = currentUser(db, ctx.req);
    sendJson(ctx.res, 200, { user: user ? { id: user.id, username: user.username } : null });
  });

  // ---------------- 首页 / 课程 ----------------
  router.get("/api/bootstrap", (ctx) => {
    const user = requireUser(db, ctx.req);
    const settings = getSettings(db, user.id);
    const states = allKpStates(db, user.id);
    const reviews = db
      .prepare("SELECT * FROM review_items WHERE user_id = ?")
      .all(user.id) as unknown as ReviewRow[];
    const reviewByKp = new Map(
      reviews.filter((r) => r.target_kind === "kp").map((r) => [r.target_id, r]),
    );
    const today = shanghaiDate();
    const due = reviews.filter((r) => r.due_date <= today);
    const last = db
      .prepare("SELECT * FROM study_sessions WHERE user_id = ? ORDER BY updated_at DESC LIMIT 1")
      .get(user.id) as Record<string, unknown> | undefined;
    const placement = db.prepare("SELECT score, skipped, created_at FROM placement_results WHERE user_id = ?").get(user.id) as
      | { score: number; skipped: number; created_at: string }
      | undefined;
    const pendingSuggestions = Number(
      (db.prepare("SELECT COUNT(*) AS n FROM agent_suggestions WHERE user_id = ? AND status = 'pending'").get(user.id) as { n: number }).n,
    );
    sendJson(ctx.res, 200, {
      user: { id: user.id, username: user.username },
      settings: {
        classroomKpId: settings.classroom_kp_id,
        defaultMinutes: settings.default_minutes,
        timezone: settings.timezone,
      },
      modules: content.modules,
      kps: content.kps.map((kp) => kpSummary(db, content, user.id, kp, states.get(kp.id), reviewByKp.get(kp.id))),
      dueReviewCount: due.length,
      dueReviews: due.slice(0, 8).map((r) => reviewItemView(content, r)),
      lastSession: last
        ? {
            id: String(last.id),
            kpId: String(last.kp_id),
            status: String(last.status),
            updatedAt: String(last.updated_at),
            position: Number(last.position),
            mode: String(last.mode),
          }
        : null,
      placement: placement ?? null,
      contentVersion: content.version,
      aiEnabled: config.ai.enabled,
      pendingSuggestions,
    });
  });

  router.get("/api/knowledge-points", (ctx) => {
    const user = requireUser(db, ctx.req);
    const states = allKpStates(db, user.id);
    const reviewByKp = new Map(
      (db.prepare("SELECT * FROM review_items WHERE user_id = ? AND target_kind = 'kp'").all(user.id) as unknown as ReviewRow[]).map(
        (r) => [r.target_id, r],
      ),
    );
    sendJson(ctx.res, 200, {
      modules: content.modules,
      kps: content.kps.map((kp) => kpSummary(db, content, user.id, kp, states.get(kp.id), reviewByKp.get(kp.id))),
    });
  });

  router.get("/api/knowledge-points/:id", (ctx) => {
    const user = requireUser(db, ctx.req);
    const kp = requireKp(content, ctx.params.id);
    const state = getKpState(db, user.id, kp.id);
    const review = db
      .prepare("SELECT * FROM review_items WHERE user_id = ? AND target_kind = 'kp' AND target_id = ?")
      .get(user.id, kp.id) as ReviewRow | undefined;
    sendJson(ctx.res, 200, {
      kp: publicKnowledgePoint(content, kp),
      state: {
        difficulty: state.difficulty,
        mastery: state.mastery,
        pendingSince: state.pending_since,
        verifiedAt: state.verified_at,
        masteredAt: state.mastered_at,
      },
      review: review ? reviewItemView(content, review) : null,
      questionCount: (content.questionsByKp.get(kp.id) ?? []).filter((q) => !q.tags?.includes("placement")).length,
      remediation: kp.prereqs.map((id) => ({ id, title: content.kpById.get(id)?.title ?? id })),
    });
  });

  // ---------------- 学习会话 ----------------
  router.post("/api/sessions", (ctx) => {
    guard(ctx.req, "POST");
    const user = requireUser(db, ctx.req);
    const b = obj(ctx.body);
    const kpId = str(b.kpId);
    const kp = requireKp(content, kpId);
    const mode = str(b.mode) === "review" ? "review" : "learn";
    const forceNew = Boolean(b.forceNew);
    if (!forceNew) {
      const existing = db
        .prepare(
          "SELECT * FROM study_sessions WHERE user_id = ? AND kp_id = ? AND status = 'active' AND mode = ? ORDER BY updated_at DESC LIMIT 1",
        )
        .get(user.id, kp.id, mode) as Record<string, unknown> | undefined;
      if (existing) {
        sendJson(ctx.res, 200, sessionPayload(db, content, user.id, existing));
        return;
      }
    }
    const state = getKpState(db, user.id, kp.id);
    const difficulty = (str(b.difficulty) as Difficulty) || state.difficulty;
    if (!["basic", "standard", "advanced"].includes(difficulty)) {
      throw new HttpError(400, "INVALID_DIFFICULTY", "难度取值不正确。");
    }
    const questions = questionSelection(content, kp.id, difficulty, 6);
    if (questions.length === 0) throw new HttpError(409, "NO_QUESTIONS", "这个知识点暂时没有可用的练习。");
    const id = randomId("s_");
    const now = nowIso();
    db.prepare(
      "INSERT INTO study_sessions (id, user_id, kp_id, status, mode, question_ids, position, drafts, revision, created_at, updated_at) VALUES (?, ?, ?, 'active', ?, ?, 0, '{}', 1, ?, ?)",
    ).run(id, user.id, kp.id, mode, JSON.stringify(questions.map((q) => q.id)), now, now);
    const row = getSession(db, user.id, id)!;
    sendJson(ctx.res, 201, sessionPayload(db, content, user.id, row));
  });

  router.post("/api/sessions/focus", (ctx) => {
    guard(ctx.req, "POST");
    const user = requireUser(db, ctx.req);
    const qid = str(obj(ctx.body).questionId);
    const q = content.activeQuestion.get(qid);
    if (!q) throw new HttpError(404, "QUESTION_NOT_FOUND", "题目不存在。");
    const state = getKpState(db, user.id, q.kpId);
    const id = randomId("s_");
    const now = nowIso();
    db.prepare(
      "INSERT INTO study_sessions (id, user_id, kp_id, status, mode, question_ids, position, drafts, revision, created_at, updated_at) VALUES (?, ?, ?, 'active', 'review', ?, 0, '{}', 1, ?, ?)",
    ).run(id, user.id, q.kpId, JSON.stringify([q.id]), now, now);
    sendJson(ctx.res, 201, sessionPayload(db, content, user.id, getSession(db, user.id, id)!));
  });

  router.get("/api/sessions/:id", (ctx) => {
    const user = requireUser(db, ctx.req);
    const row = getSession(db, user.id, ctx.params.id);
    if (!row) throw new HttpError(404, "SESSION_NOT_FOUND", "学习会话不存在。");
    sendJson(ctx.res, 200, sessionPayload(db, content, user.id, row));
  });

  router.post("/api/sessions/:id/state", (ctx) => {
    guard(ctx.req, "POST");
    const user = requireUser(db, ctx.req);
    const row = getSession(db, user.id, ctx.params.id);
    if (!row) throw new HttpError(404, "SESSION_NOT_FOUND", "学习会话不存在。");
    const b = obj(ctx.body);
    const revision = Number(b.revision);
    if (!Number.isInteger(revision)) throw new HttpError(400, "INVALID_REVISION", "缺少修订号。");
    if (revision !== Number(row.revision)) {
      sendJson(ctx.res, 409, {
        error: { code: "REVISION_CONFLICT", message: "云端会话已在其他设备更新。" },
        session: sessionPayload(db, content, user.id, row),
      });
      return;
    }
    const state = sessionState(row);
    const position = has(b, "position") ? Number(b.position) : state.position;
    if (!Number.isInteger(position) || position < 0 || position > state.questionIds.length) {
      throw new HttpError(400, "INVALID_POSITION", "题目位置不正确。");
    }
    let drafts = state.drafts;
    if (has(b, "drafts")) {
      const raw = JSON.stringify(b.drafts ?? {});
      if (raw.length > 200_000) throw new HttpError(413, "DRAFTS_TOO_LARGE", "草稿内容过大。");
      drafts = (b.drafts ?? {}) as typeof drafts;
    }
    db.prepare("UPDATE study_sessions SET position = ?, drafts = ?, revision = revision + 1, updated_at = ? WHERE id = ?").run(
      position,
      JSON.stringify(drafts),
      nowIso(),
      state.id,
    );
    sendJson(ctx.res, 200, sessionPayload(db, content, user.id, getSession(db, user.id, state.id)!));
  });

  router.post("/api/sessions/:id/fork", (ctx) => {
    guard(ctx.req, "POST");
    const user = requireUser(db, ctx.req);
    const row = getSession(db, user.id, ctx.params.id);
    if (!row) throw new HttpError(404, "SESSION_NOT_FOUND", "学习会话不存在。");
    const b = obj(ctx.body);
    const state = sessionState(row);
    const drafts = JSON.stringify(b.drafts ?? {});
    if (drafts.length > 200_000) throw new HttpError(413, "DRAFTS_TOO_LARGE", "草稿内容过大。");
    const position = has(b, "position") ? Number(b.position) : state.position;
    const id = randomId("s_");
    const now = nowIso();
    db.prepare(
      "INSERT INTO study_sessions (id, user_id, kp_id, status, mode, question_ids, position, drafts, revision, created_at, updated_at) VALUES (?, ?, ?, 'active', ?, ?, ?, ?, 1, ?, ?)",
    ).run(
      id,
      user.id,
      state.kpId,
      String(row.mode ?? "learn"),
      JSON.stringify(state.questionIds),
      Math.max(0, Math.min(position, state.questionIds.length)),
      drafts,
      now,
      now,
    );
    sendJson(ctx.res, 201, sessionPayload(db, content, user.id, getSession(db, user.id, id)!));
  });

  router.post("/api/sessions/:id/complete", (ctx) => {
    guard(ctx.req, "POST");
    const user = requireUser(db, ctx.req);
    const row = getSession(db, user.id, ctx.params.id);
    if (!row) throw new HttpError(404, "SESSION_NOT_FOUND", "学习会话不存在.");
    const b = obj(ctx.body);
    if (has(b, "revision") && Number(b.revision) !== Number(row.revision)) {
      sendJson(ctx.res, 409, {
        error: { code: "REVISION_CONFLICT", message: "云端会话已在其他设备更新。" },
        session: sessionPayload(db, content, user.id, row),
      });
      return;
    }
    const state = sessionState(row);
    const kpId = state.kpId;
    const mode = String(row.mode ?? "learn");
    const result = tx(db, () => {
      db.prepare("UPDATE study_sessions SET status = 'completed', revision = revision + 1, updated_at = ? WHERE id = ?").run(
        nowIso(),
        state.id,
      );
      const attempts = db
        .prepare(
          "SELECT question_id, kp_id, correct, format_error, independent, first_attempt, hint_level, solution_viewed, created_at FROM submissions WHERE session_id = ? ORDER BY created_at ASC",
        )
        .all(state.id) as Array<Record<string, unknown>>;
      const facts = attempts.map((r) => ({
        questionId: String(r.question_id),
        kpId: String(r.kp_id),
        correct: Boolean(r.correct),
        formatError: Boolean(r.format_error),
        independent: Boolean(r.independent),
        firstAttempt: Boolean(r.first_attempt),
        hintLevel: Number(r.hint_level),
        solutionViewed: Boolean(r.solution_viewed),
        createdAt: String(r.created_at),
      }));
      let reviewResult: "good" | "fuzzy" | "bad" | null = null;
      if (mode === "review") {
        const item = db
          .prepare("SELECT * FROM review_items WHERE user_id = ? AND target_kind = 'kp' AND target_id = ?")
          .get(user.id, kpId) as ReviewRow | undefined;
        if (item) {
          reviewResult = reviewResultFromSession(facts);
          applyReviewResult(db, user.id, item, reviewResult);
        }
      } else {
        const existing = db
          .prepare("SELECT * FROM review_items WHERE user_id = ? AND target_kind = 'kp' AND target_id = ?")
          .get(user.id, kpId) as ReviewRow | undefined;
        if (!existing) upsertReview(db, user.id, "kp", kpId, { dueDate: addDays(shanghaiDate(), 1) });
        const kp = content.kpById.get(kpId);
        for (const fid of kp?.formulaIds ?? []) {
          const f = db
            .prepare("SELECT * FROM review_items WHERE user_id = ? AND target_kind = 'formula' AND target_id = ?")
            .get(user.id, fid) as ReviewRow | undefined;
          if (!f) upsertReview(db, user.id, "formula", fid, { dueDate: addDays(shanghaiDate(), 1) });
        }
      }
      return { reviewResult, facts };
    });
    const stateNow = getKpState(db, user.id, kpId);
    const item = db
      .prepare("SELECT * FROM review_items WHERE user_id = ? AND target_kind = 'kp' AND target_id = ?")
      .get(user.id, kpId) as ReviewRow | undefined;
    sendJson(ctx.res, 200, {
      ok: true,
      state: { difficulty: stateNow.difficulty, mastery: stateNow.mastery },
      reviewResult: result.reviewResult,
      nextReview: item ? reviewItemView(content, item) : null,
      stats: {
        firstAttempts: result.facts.filter((f) => f.firstAttempt).length,
        independentCorrect: result.facts.filter((f) => f.firstAttempt && f.independent).length,
        wrong: result.facts.filter((f) => f.firstAttempt && !f.correct && !f.formatError).length,
      },
    });
  });

  // ---------------- 提示、解析、提交 ----------------
  function loadEventQuestion(ctx: Ctx, user: UserRow) {
    const b = obj(ctx.body);
    const sessionId = str(b.sessionId ?? ctx.params.id);
    const questionId = str(b.questionId);
    const row = getSession(db, user.id, sessionId);
    if (!row) throw new HttpError(404, "SESSION_NOT_FOUND", "学习会话不存在。");
    const state = sessionState(row);
    if (!state.questionIds.includes(questionId)) throw new HttpError(404, "QUESTION_NOT_IN_SESSION", "题目不在当前会话中。");
    const q = content.activeQuestion.get(questionId);
    if (!q) throw new HttpError(404, "QUESTION_NOT_FOUND", "题目不存在。");
    return { row, state, q };
  }

  router.post("/api/sessions/:id/hint", (ctx) => {
    guard(ctx.req, "POST");
    const user = requireUser(db, ctx.req);
    const { q } = loadEventQuestion(ctx, user);
    const b = obj(ctx.body);
    const level = Number(b.level);
    if (![1, 2, 3].includes(level)) throw new HttpError(400, "INVALID_HINT_LEVEL", "提示层级只能是 1、2、3。");
    const sessionId = str(b.sessionId ?? ctx.params.id);
    const existing = db
      .prepare("SELECT * FROM question_events WHERE session_id = ? AND question_id = ?")
      .get(sessionId, q.id) as { hint_level: number; solution_viewed: number } | undefined;
    const max = Math.max(Number(existing?.hint_level ?? 0), level);
    if (existing) {
      db.prepare("UPDATE question_events SET hint_level = ?, updated_at = ? WHERE session_id = ? AND question_id = ?").run(
        max,
        nowIso(),
        sessionId,
        q.id,
      );
    } else {
      db.prepare(
        "INSERT INTO question_events (user_id, session_id, question_id, hint_level, solution_viewed, updated_at) VALUES (?, ?, ?, ?, 0, ?)",
      ).run(user.id, sessionId, q.id, max, nowIso());
    }
    sendJson(ctx.res, 200, {
      level,
      maxLevel: max,
      content: q.hints[level - 1],
      source: "builtin",
    });
  });

  router.post("/api/sessions/:id/solution", (ctx) => {
    guard(ctx.req, "POST");
    const user = requireUser(db, ctx.req);
    const { q } = loadEventQuestion(ctx, user);
    const sessionId = str(obj(ctx.body).sessionId ?? ctx.params.id);
    const existing = db
      .prepare("SELECT * FROM question_events WHERE session_id = ? AND question_id = ?")
      .get(sessionId, q.id) as { hint_level: number; solution_viewed: number } | undefined;
    if (existing) {
      db.prepare("UPDATE question_events SET solution_viewed = 1, updated_at = ? WHERE session_id = ? AND question_id = ?").run(
        nowIso(),
        sessionId,
        q.id,
      );
    } else {
      db.prepare(
        "INSERT INTO question_events (user_id, session_id, question_id, hint_level, solution_viewed, updated_at) VALUES (?, ?, ?, 0, 1, ?)",
      ).run(user.id, sessionId, q.id, nowIso());
    }
    sendJson(ctx.res, 200, { solution: q.solution, solutionViewed: true });
  });

  router.post("/api/submissions", (ctx) => {
    guard(ctx.req, "POST");
    const user = requireUser(db, ctx.req);
    const b = obj(ctx.body);
    const clientId = str(b.clientId);
    if (!clientId || clientId.length > 100) throw new HttpError(400, "INVALID_CLIENT_ID", "缺少提交编号。");
    const existing = db
      .prepare("SELECT * FROM submissions WHERE user_id = ? AND client_id = ?")
      .get(user.id, clientId) as Record<string, unknown> | undefined;
    if (existing) {
      sendJson(ctx.res, 200, {
        replayed: true,
        correct: Boolean(existing.correct),
        formatError: Boolean(existing.format_error),
        independent: Boolean(existing.independent),
        firstAttempt: Boolean(existing.first_attempt),
        result: JSON.parse(String(existing.result)),
        state: null,
      });
      return;
    }
    const sessionId = str(b.sessionId);
    const row = getSession(db, user.id, sessionId);
    if (!row) throw new HttpError(404, "SESSION_NOT_FOUND", "学习会话不存在。");
    const state = sessionState(row);
    const questionId = str(b.questionId);
    if (!state.questionIds.includes(questionId)) throw new HttpError(404, "QUESTION_NOT_IN_SESSION", "题目不在当前会话中。");
    const version = Number(b.questionVersion);
    const q = content.questionVersions.get(`${questionId}@${version}`);
    if (!q) throw new HttpError(409, "QUESTION_VERSION_NOT_FOUND", "题目版本不存在，请刷新页面。");
    const answer = parseAnswerValue(b.answer);

    const event = db
      .prepare("SELECT hint_level, solution_viewed FROM question_events WHERE session_id = ? AND question_id = ?")
      .get(sessionId, questionId) as { hint_level: number; solution_viewed: number } | undefined;
    const hintLevel = Number(event?.hint_level ?? 0);
    const solutionViewed = Boolean(event?.solution_viewed);

    const prior = db
      .prepare("SELECT COUNT(*) AS n FROM submissions WHERE session_id = ? AND question_id = ? AND format_error = 0")
      .get(sessionId, questionId) as { n: number };

    const result = gradeAnswer(q.answer, answer);
    const firstAttempt = !result.formatError && Number(prior.n) === 0;
    const independent = isIndependent({
      correct: result.correct,
      formatError: result.formatError,
      firstAttempt,
      hintLevel,
      solutionViewed,
    });
    const submissionId = randomId("a_");
    const createdAt = nowIso();
    let stateInfo: { difficulty: string; mastery: string; moved: string; justMastered: boolean } | null = null;

    tx(db, () => {
      db.prepare(
        `INSERT INTO submissions
         (id, client_id, user_id, session_id, kp_id, question_id, question_version, question_snapshot, answer, result,
          correct, format_error, independent, hint_level, solution_viewed, first_attempt, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      ).run(
        submissionId,
        clientId,
        user.id,
        sessionId,
        state.kpId,
        questionId,
        version,
        JSON.stringify(q),
        JSON.stringify(answer),
        JSON.stringify({ correct: result.correct, formatError: result.formatError, message: result.message, detail: result.detail }),
        result.correct ? 1 : 0,
        result.formatError ? 1 : 0,
        independent ? 1 : 0,
        hintLevel,
        solutionViewed ? 1 : 0,
        firstAttempt ? 1 : 0,
        createdAt,
      );
      if (!result.formatError && firstAttempt) {
        const updated = updateStateAfterSubmission(db, user.id, state.kpId, {
          questionId,
          kpId: state.kpId,
          correct: result.correct,
          formatError: result.formatError,
          independent,
          firstAttempt,
          hintLevel,
          solutionViewed,
          createdAt,
        });
        stateInfo = updated;
      }
    });

    sendJson(ctx.res, 200, {
      replayed: false,
      submissionId,
      correct: result.correct,
      formatError: result.formatError,
      message: result.message,
      detail: result.detail,
      independent,
      firstAttempt,
      state: stateInfo,
    });
  });

  // ---------------- 复习 ----------------
  router.get("/api/reviews", (ctx) => {
    const user = requireUser(db, ctx.req);
    const today = shanghaiDate();
    const items = db
      .prepare("SELECT * FROM review_items WHERE user_id = ? ORDER BY due_date ASC, created_at ASC")
      .all(user.id) as unknown as ReviewRow[];
    sendJson(ctx.res, 200, {
      today,
      due: items.filter((r) => r.due_date <= today).map((r) => reviewItemView(content, r)),
      upcoming: items.filter((r) => r.due_date > today).slice(0, 20).map((r) => reviewItemView(content, r)),
    });
  });

  router.post("/api/formulas/:id/result", (ctx) => {
    guard(ctx.req, "POST");
    const user = requireUser(db, ctx.req);
    const f = content.formulaById.get(ctx.params.id);
    if (!f) throw new HttpError(404, "FORMULA_NOT_FOUND", "公式卡不存在。");
    const result = str(obj(ctx.body).result);
    if (!["good", "fuzzy", "bad"].includes(result)) {
      throw new HttpError(400, "INVALID_RESULT", "复习结果只能是 good、fuzzy 或 bad。");
    }
    const item = upsertReview(db, user.id, "formula", f.id, { dueDate: shanghaiDate() });
    const updated = applyReviewResult(db, user.id, item, result as "good" | "fuzzy" | "bad");
    sendJson(ctx.res, 200, { review: reviewItemView(content, updated) });
  });

  router.get("/api/formulas", (ctx) => {
    const user = requireUser(db, ctx.req);
    const reviewRows = db
      .prepare("SELECT * FROM review_items WHERE user_id = ? AND target_kind = 'formula'")
      .all(user.id) as unknown as ReviewRow[];
    const byId = new Map(reviewRows.map((r) => [r.target_id, r]));
    sendJson(ctx.res, 200, {
      formulas: content.formulas.map((f) => ({
        ...f,
        kpTitles: f.kpIds.map((id) => content.kpById.get(id)?.title ?? id),
        review: byId.get(f.id) ? reviewItemView(content, byId.get(f.id)!) : null,
      })),
    });
  });

  // ---------------- 摸底 ----------------
  router.get("/api/placement", (ctx) => {
    requireUser(db, ctx.req);
    const qs = content.questions.filter((q) => q.tags?.includes("placement"));
    sendJson(ctx.res, 200, {
      questions: qs.map((q) => {
        const { answer: _a, solution: _s, hints: _h, ...rest } = q;
        return rest;
      }),
      areas: qs.map((q) => q.tags?.find((t) => t.startsWith("area:"))?.slice(5) ?? ""),
    });
  });

  router.post("/api/placement", (ctx) => {
    guard(ctx.req, "POST");
    const user = requireUser(db, ctx.req);
    const b = obj(ctx.body);
    const skipped = Boolean(b.skipped);
    if (skipped) {
      db.prepare(
        "INSERT INTO placement_results (user_id, answers, score, skipped, created_at) VALUES (?, '{}', 0, 1, ?) ON CONFLICT(user_id) DO UPDATE SET answers = '{}', score = 0, skipped = 1, created_at = excluded.created_at",
      ).run(user.id, nowIso());
      sendJson(ctx.res, 200, { skipped: true, score: 0 });
      return;
    }
    const answers = obj(b.answers);
    const qs = content.questions.filter((q) => q.tags?.includes("placement"));
    if (qs.length === 0) throw new HttpError(409, "NO_PLACEMENT", "摸底题目尚未配置。");
    let score = 0;
    const detail = qs.map((q) => {
      const raw = str(answers[q.id]);
      const r = gradeAnswer(q.answer, { kind: q.answer.kind === "choice" ? "choice" : "number", value: raw } as AnswerValue);
      if (r.correct) score++;
      return { questionId: q.id, correct: r.correct, kpId: q.kpId };
    });
    db.prepare(
      "INSERT INTO placement_results (user_id, answers, score, skipped, created_at) VALUES (?, ?, ?, 0, ?) ON CONFLICT(user_id) DO UPDATE SET answers = excluded.answers, score = excluded.score, skipped = 0, created_at = excluded.created_at",
    ).run(user.id, JSON.stringify(answers), score, nowIso());
    sendJson(ctx.res, 200, { score, total: qs.length, detail });
  });

  // ---------------- 记录 / 设置 / 导出 ----------------
  router.get("/api/notebook", (ctx) => {
    const user = requireUser(db, ctx.req);
    sendJson(ctx.res, 200, { items: findWrongNotebook(db, content, user.id) });
  });

  router.get("/api/stats", (ctx) => {
    const user = requireUser(db, ctx.req);
    const stats = statsForUser(db, content, user.id);
    const totals = stats.reduce(
      (acc, s) => ({
        firstAttempts: acc.firstAttempts + s.firstAttempts,
        independentCorrect: acc.independentCorrect + s.independentCorrect,
        hintedCorrect: acc.hintedCorrect + s.hintedCorrect,
        wrong: acc.wrong + s.wrong,
      }),
      { firstAttempts: 0, independentCorrect: 0, hintedCorrect: 0, wrong: 0 },
    );
    const due = dueReviews(db, user.id).length;
    sendJson(ctx.res, 200, { stats, totals, dueCount: due });
  });

  router.post("/api/settings", (ctx) => {
    guard(ctx.req, "POST");
    const user = requireUser(db, ctx.req);
    const b = obj(ctx.body);
    const patch: { classroomKpId?: string; defaultMinutes?: number } = {};
    if (has(b, "classroomKpId")) {
      const id = str(b.classroomKpId);
      if (!content.kpById.has(id)) throw new HttpError(400, "INVALID_KP", "课堂位置的知识点不存在。");
      patch.classroomKpId = id;
    }
    if (has(b, "defaultMinutes")) {
      const n = Number(b.defaultMinutes);
      if (!Number.isFinite(n) || n < 10 || n > 90) throw new HttpError(400, "INVALID_MINUTES", "默认练习时长需在 10—90 分钟之间。");
      patch.defaultMinutes = n;
    }
    const s = updateSettings(db, user.id, patch);
    sendJson(ctx.res, 200, { settings: { classroomKpId: s.classroom_kp_id, defaultMinutes: s.default_minutes, timezone: s.timezone } });
  });

  router.get("/api/export", (ctx) => {
    const user = requireUser(db, ctx.req);
    const data = {
      exportedAt: nowIso(),
      app: "calculus-learning",
      version: 1,
      user: { id: user.id, username: user.username, createdAt: user.created_at },
      settings: getSettings(db, user.id),
      kpStates: db.prepare("SELECT * FROM kp_state WHERE user_id = ?").all(user.id),
      sessions: db
        .prepare("SELECT id, kp_id, status, mode, position, revision, created_at, updated_at FROM study_sessions WHERE user_id = ?")
        .all(user.id),
      submissions: db.prepare("SELECT * FROM submissions WHERE user_id = ? ORDER BY created_at").all(user.id),
      reviews: db.prepare("SELECT * FROM review_items WHERE user_id = ?").all(user.id),
      formulaReviews: db.prepare("SELECT * FROM formula_reviews WHERE user_id = ?").all(user.id),
      placement: db.prepare("SELECT * FROM placement_results WHERE user_id = ?").all(user.id),
      suggestions: db.prepare("SELECT * FROM agent_suggestions WHERE user_id = ?").all(user.id),
    };
    ctx.res.writeHead(200, {
      "content-type": "application/json; charset=utf-8",
      "content-disposition": `attachment; filename="calculus-learning-${shanghaiDate()}.json"`,
      "cache-control": "no-store",
    });
    ctx.res.end(JSON.stringify(data, null, 2));
  });

  // ---------------- Agent 令牌与建议 ----------------
  router.get("/api/agent-tokens", (ctx) => {
    const user = requireUser(db, ctx.req);
    const rows = db
      .prepare("SELECT id, name, scopes, created_at, expires_at, revoked_at, last_used_at FROM agent_tokens WHERE user_id = ? ORDER BY created_at DESC")
      .all(user.id);
    sendJson(ctx.res, 200, { tokens: rows });
  });

  router.post("/api/agent-tokens", (ctx) => {
    guard(ctx.req, "POST");
    const user = requireUser(db, ctx.req);
    const b = obj(ctx.body);
    const name = str(b.name).trim();
    if (name.length < 1 || name.length > 60) throw new HttpError(400, "INVALID_NAME", "令牌名称需为 1—60 个字符。");
    const requested = Array.isArray(b.scopes) ? b.scopes.map(String) : [];
    const allowed = ["learning:read", "suggestions:write"];
    const scopes = requested.filter((s: string) => allowed.includes(s));
    if (scopes.length === 0) throw new HttpError(400, "INVALID_SCOPES", "至少选择一个权限。");
    const token = randomBytes(32).toString("base64url");
    const hash = createHash("sha256").update(token).digest("hex");
    const id = randomId("t_");
    const now = new Date();
    const expires = new Date(now.getTime() + 90 * 86400000);
    db.prepare(
      "INSERT INTO agent_tokens (id, user_id, name, token_hash, scopes, created_at, expires_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
    ).run(id, user.id, name, hash, JSON.stringify(scopes), now.toISOString(), expires.toISOString());
    sendJson(ctx.res, 201, {
      token,
      tokenId: id,
      name,
      scopes,
      createdAt: now.toISOString(),
      expiresAt: expires.toISOString(),
      notice: "令牌只显示这一次，请立即保存。数据库只保存摘要。",
    });
  });

  router.delete("/api/agent-tokens/:id", (ctx) => {
    guard(ctx.req, "DELETE");
    const user = requireUser(db, ctx.req);
    const row = db.prepare("SELECT id FROM agent_tokens WHERE id = ? AND user_id = ?").get(ctx.params.id, user.id);
    if (!row) throw new HttpError(404, "TOKEN_NOT_FOUND", "令牌不存在。");
    db.prepare("UPDATE agent_tokens SET revoked_at = ? WHERE id = ?").run(nowIso(), ctx.params.id);
    sendJson(ctx.res, 200, { ok: true });
  });

  router.get("/api/suggestions", (ctx) => {
    const user = requireUser(db, ctx.req);
    const status = ctx.url.searchParams.get("status") ?? "pending";
    const rows = db
      .prepare("SELECT * FROM agent_suggestions WHERE user_id = ? AND status = ? ORDER BY created_at DESC LIMIT 100")
      .all(user.id, status) as Array<Record<string, unknown>>;
    sendJson(ctx.res, 200, {
      suggestions: rows.map((r) => ({
        id: String(r.id),
        kind: String(r.kind),
        content: JSON.parse(String(r.content)),
        status: String(r.status),
        createdAt: String(r.created_at),
        reviewedAt: r.reviewed_at ? String(r.reviewed_at) : null,
      })),
    });
  });

  router.post("/api/suggestions/:id/review", (ctx) => {
    guard(ctx.req, "POST");
    const user = requireUser(db, ctx.req);
    const action = str(obj(ctx.body).action);
    if (!["accept", "ignore"].includes(action)) throw new HttpError(400, "INVALID_ACTION", "操作只能是 accept 或 ignore。");
    const row = db
      .prepare("SELECT id FROM agent_suggestions WHERE id = ? AND user_id = ? AND status = 'pending'")
      .get(ctx.params.id, user.id);
    if (!row) throw new HttpError(404, "SUGGESTION_NOT_FOUND", "待处理建议不存在。");
    db.prepare("UPDATE agent_suggestions SET status = ?, reviewed_at = ? WHERE id = ?").run(
      action === "accept" ? "accepted" : "ignored",
      nowIso(),
      ctx.params.id,
    );
    sendJson(ctx.res, 200, { ok: true, status: action === "accept" ? "accepted" : "ignored" });
  });

  // ---------------- AI ----------------
  router.get("/api/ai/status", (ctx) => {
    requireUser(db, ctx.req);
    const configured = Boolean(config.ai.baseUrl && config.ai.model && config.ai.apiKey);
    sendJson(ctx.res, 200, {
      enabled: config.ai.enabled,
      configured,
      model: config.ai.enabled && configured ? config.ai.model : null,
      timeoutMs: config.ai.timeoutMs,
    });
  });

  router.post("/api/ai/tasks", async (ctx) => {
    guard(ctx.req, "POST");
    const user = requireUser(db, ctx.req);
    const b = obj(ctx.body);
    const task = str(b.task) as AiTask;
    if (!["explain", "hint", "analyze_error", "recommend_review"].includes(task)) {
      throw new HttpError(400, "INVALID_TASK", "不支持的 AI 任务。");
    }
    const kpId = str(b.kpId);
    const kp = requireKp(content, kpId);
    let question: Question | undefined;
    let hintLevel: number | undefined;
    if (task === "hint") {
      hintLevel = Number(b.hintLevel);
      if (![1, 2, 3].includes(hintLevel)) throw new HttpError(400, "INVALID_HINT_LEVEL", "提示层级只能是 1、2、3。");
    }
    if (b.questionId) {
      const qid = str(b.questionId);
      const version = Number(b.questionVersion);
      question = content.questionVersions.get(`${qid}@${version}`) ?? content.activeQuestion.get(qid);
      if (!question) throw new HttpError(404, "QUESTION_NOT_FOUND", "题目不存在。");
      if (question.kpId !== kp.id) throw new HttpError(400, "QUESTION_KP_MISMATCH", "题目不属于该知识点。");
    }
    if (task === "hint" && !question) throw new HttpError(400, "QUESTION_REQUIRED", "提示任务需要指定题目。");
    if (b.sessionId) {
      const session = getSession(db, user.id, str(b.sessionId));
      if (!session) throw new HttpError(404, "SESSION_NOT_FOUND", "学习会话不存在。");
    }
    if (task === "analyze_error" && !question) throw new HttpError(400, "QUESTION_REQUIRED", "错因分析需要指定题目。");

    const due = dueReviews(db, user.id).slice(0, 5);
    const dueTitles = due.map((r) => reviewTitle(content, r));
    const recent = statsForUser(db, content, user.id).find((s) => s.kpId === kp.id);
    const ctxData = {
      task,
      kpTitle: kp.title,
      kpSummary: kp.summary,
      questionPrompt: question ? flattenBlocks(question.prompt) : undefined,
      questionOptions: question?.options?.map((o) => `${o.id}. ${flattenBlocks([{ t: "p", md: o.md }])}`),
      hintLevel,
      reviewDue: dueTitles.map((t) => `${t.title}`),
      recentStats: recent
        ? `首次作答 ${recent.firstAttempts} 次，独立答对 ${recent.independentCorrect} 次，答错 ${recent.wrong} 次`
        : undefined,
    };
    const ai = await callAi(config, ctxData);
    let source: "ai" | "builtin" = ai.source;
    let contentText = ai.content;
    if (source === "builtin") {
      contentText = builtinTask(task, {
        kpSummary: kp.summary,
        hint: question && hintLevel ? question.hints[hintLevel - 1] : undefined,
        solutionFirstStep: question ? flattenBlocks(question.solution) : undefined,
        dueTitles: dueTitles.map((t) => t.title),
      });
    }
    db.prepare("INSERT INTO ai_log (id, user_id, task, source, status, detail, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)").run(
      randomId("ai_"),
      user.id,
      task,
      source,
      source === "ai" ? "ok" : "fallback",
      ai.fallbackReason ?? null,
      nowIso(),
    );
    sendJson(ctx.res, 200, {
      source,
      task,
      content: contentText,
      hintLevel,
      references: ai.references.length ? ai.references : question ? [question.id] : [kp.id],
    });
  });
}

function flattenBlocks(blocks: unknown): string {
  const arr = Array.isArray(blocks) ? blocks : [];
  const out: string[] = [];
  for (const b of arr) {
    if (!b || typeof b !== "object") continue;
    const o = b as Record<string, unknown>;
    if (typeof o.md === "string") out.push(o.md);
    if (typeof o.text === "string") out.push(o.text);
    if (typeof o.title === "string") out.push(o.title);
    if (Array.isArray(o.steps)) out.push(...o.steps.filter((s) => typeof s === "string"));
    if (Array.isArray(o.items)) out.push(...o.items.filter((s) => typeof s === "string"));
  }
  return out.join(" ").replace(/\s+/g, " ").slice(0, 1200);
}

export function reviewTitle(content: ContentBundle, r: ReviewRow): { kind: string; title: string } {
  if (r.target_kind === "kp") {
    return { kind: "kp", title: content.kpById.get(r.target_id)?.title ?? r.target_id };
  }
  return { kind: "formula", title: content.formulaById.get(r.target_id)?.name ?? r.target_id };
}

export function reviewItemView(content: ContentBundle, r: ReviewRow) {
  const info = reviewTitle(content, r);
  return {
    id: r.id,
    kind: r.target_kind,
    targetId: r.target_id,
    title: info.title,
    stage: r.stage,
    dueDate: r.due_date,
    lastResult: r.last_result,
    kpId: r.target_kind === "kp" ? r.target_id : content.formulaById.get(r.target_id)?.kpIds[0] ?? null,
    formula: r.target_kind === "formula" ? content.formulaById.get(r.target_id) ?? null : null,
  };
}
