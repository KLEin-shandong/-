import { createHash } from "node:crypto";
import type { DB } from "./db.ts";
import { nowIso, randomId } from "./db.ts";
import type { ContentBundle } from "./content.ts";
import type { Router, Ctx } from "./http.ts";
import { HttpError, sendJson } from "./http.ts";
import { allKpStates, dueReviews, getSettings, statsForUser } from "./services.ts";
import { shanghaiDate } from "../shared/learning.ts";

interface AgentToken {
  id: string;
  user_id: string;
  name: string;
  scopes: string[];
  expires_at: string;
  revoked_at: string | null;
}

const rate = new Map<string, { start: number; count: number }>();

function checkRate(tokenId: string): void {
  const now = Date.now();
  const windowMs = 60_000;
  const item = rate.get(tokenId);
  if (!item || now - item.start >= windowMs) {
    rate.set(tokenId, { start: now, count: 1 });
    return;
  }
  item.count++;
  if (item.count > 60) {
    throw new HttpError(429, "RATE_LIMITED", "请求过于频繁，请稍后再试（每令牌每分钟 60 次）。");
  }
}

type Scope = "learning:read" | "suggestions:write";

function authenticate(db: DB, ctx: Ctx, scope: Scope): AgentToken & { user_id: string } {
  const header = String(ctx.req.headers.authorization ?? "");
  if (!header.startsWith("Bearer ")) throw new HttpError(401, "UNAUTHENTICATED", "缺少 Agent 令牌。");
  const token = header.slice(7).trim();
  if (token.length < 20) throw new HttpError(401, "UNAUTHENTICATED", "令牌格式不正确。");
  const hash = createHash("sha256").update(token).digest("hex");
  const row = db
    .prepare("SELECT id, user_id, name, scopes, expires_at, revoked_at FROM agent_tokens WHERE token_hash = ?")
    .get(hash) as
    | { id: string; user_id: string; name: string; scopes: string; expires_at: string; revoked_at: string | null }
    | undefined;
  if (!row) throw new HttpError(401, "INVALID_TOKEN", "令牌无效。");
  if (row.revoked_at) throw new HttpError(401, "TOKEN_REVOKED", "令牌已撤销。");
  if (new Date(row.expires_at).getTime() < Date.now()) throw new HttpError(401, "TOKEN_EXPIRED", "令牌已过期。");
  const scopes = JSON.parse(row.scopes) as string[];
  if (!scopes.includes(scope)) throw new HttpError(403, "INSUFFICIENT_SCOPE", `令牌缺少 ${scope} 权限。`);
  checkRate(row.id);
  db.prepare("UPDATE agent_tokens SET last_used_at = ? WHERE id = ?").run(nowIso(), row.id);
  return { ...row, scopes, user_id: row.user_id };
}

function pageParams(ctx: Ctx): { limit: number; offset: number } {
  const limitRaw = Number(ctx.url.searchParams.get("limit") ?? "20");
  const limit = Number.isFinite(limitRaw) ? Math.max(1, Math.min(100, Math.floor(limitRaw))) : 20;
  const cursor = ctx.url.searchParams.get("cursor") ?? "";
  let offset = 0;
  if (cursor) {
    try {
      offset = Math.max(0, Number(Buffer.from(cursor, "base64url").toString("utf8")) || 0);
    } catch {
      throw new HttpError(400, "INVALID_CURSOR", "分页游标无效。");
    }
  }
  return { limit, offset };
}

function nextCursor(offset: number, limit: number, total: number): string | null {
  const next = offset + limit;
  return next < total ? Buffer.from(String(next)).toString("base64url") : null;
}

export function registerAgentApi(router: Router, deps: { db: DB; content: ContentBundle }): void {
  const { db, content } = deps;

  router.get("/api/agent/v1/context", (ctx) => {
    const token = authenticate(db, ctx, "learning:read");
    const settings = getSettings(db, token.user_id);
    const states = allKpStates(db, token.user_id);
    const stats = statsForUser(db, content, token.user_id);
    const last = db
      .prepare("SELECT id, kp_id, status, updated_at, position, mode FROM study_sessions WHERE user_id = ? ORDER BY updated_at DESC LIMIT 1")
      .get(token.user_id) as Record<string, unknown> | undefined;
    const due = dueReviews(db, token.user_id);
    const weak = stats
      .filter((s) => s.firstAttempts > 0 && (s.mastery === "needs_review" || s.independentCorrect < Math.max(1, s.firstAttempts / 2)))
      .sort((a, b) => b.wrong - a.wrong)
      .slice(0, 5)
      .map((s) => ({
        kpId: s.kpId,
        title: s.title,
        mastery: s.mastery,
        firstAttempts: s.firstAttempts,
        independentCorrect: s.independentCorrect,
        wrong: s.wrong,
      }));
    const since = new Date(Date.now() - 7 * 86400000).toISOString();
    const recent = db
      .prepare(
        "SELECT COUNT(*) AS attempts, SUM(independent) AS independent, MAX(created_at) AS lastAt FROM submissions WHERE user_id = ? AND created_at >= ?",
      )
      .get(token.user_id, since) as { attempts: number; independent: number | null; lastAt: string | null };
    sendJson(ctx.res, 200, {
      user: { id: token.user_id },
      classroom: {
        kpId: settings.classroom_kp_id,
        title: content.kpById.get(settings.classroom_kp_id)?.title ?? settings.classroom_kp_id,
      },
      lastSession: last
        ? {
            id: String(last.id),
            kpId: String(last.kp_id),
            kpTitle: content.kpById.get(String(last.kp_id))?.title ?? String(last.kp_id),
            status: String(last.status),
            mode: String(last.mode),
            position: Number(last.position),
            updatedAt: String(last.updated_at),
          }
        : null,
      weakPoints: weak,
      dueReviewCount: due.length,
      dueReviews: due.slice(0, 10).map((r) => ({
        kind: r.target_kind,
        targetId: r.target_id,
        title:
          r.target_kind === "kp"
            ? content.kpById.get(r.target_id)?.title ?? r.target_id
            : content.formulaById.get(r.target_id)?.name ?? r.target_id,
        stage: r.stage,
        dueDate: r.due_date,
      })),
      recent7d: {
        attempts: Number(recent.attempts ?? 0),
        independentCorrect: Number(recent.independent ?? 0),
        lastActivityAt: recent.lastAt ?? null,
      },
      masteryCounts: {
        mastered: [...states.values()].filter((s) => s.mastery === "mastered").length,
        pendingVerify: [...states.values()].filter((s) => s.mastery === "pending_verify").length,
        needsReview: [...states.values()].filter((s) => s.mastery === "needs_review").length,
      },
    });
  });

  router.get("/api/agent/v1/knowledge-points", (ctx) => {
    const token = authenticate(db, ctx, "learning:read");
    const { limit, offset } = pageParams(ctx);
    const states = allKpStates(db, token.user_id);
    const list = content.kps.map((kp) => ({
      id: kp.id,
      module: kp.module,
      order: kp.order,
      title: kp.title,
      subtitle: kp.subtitle,
      prereqs: kp.prereqs,
      minutes: kp.minutes,
      source: kp.source,
      mastery: states.get(kp.id)?.mastery ?? "not_started",
      difficulty: states.get(kp.id)?.difficulty ?? "basic",
    }));
    sendJson(ctx.res, 200, {
      total: list.length,
      items: list.slice(offset, offset + limit),
      nextCursor: nextCursor(offset, limit, list.length),
    });
  });

  router.get("/api/agent/v1/review-items", (ctx) => {
    const token = authenticate(db, ctx, "learning:read");
    const { limit, offset } = pageParams(ctx);
    const dueOnly = ctx.url.searchParams.get("due") !== "0";
    const today = shanghaiDate();
    const all = db
      .prepare("SELECT * FROM review_items WHERE user_id = ? ORDER BY due_date ASC")
      .all(token.user_id) as Array<Record<string, unknown>>;
    const filtered = dueOnly ? all.filter((r) => String(r.due_date) <= today) : all;
    sendJson(ctx.res, 200, {
      today,
      total: filtered.length,
      items: filtered.slice(offset, offset + limit).map((r) => ({
        kind: String(r.target_kind),
        targetId: String(r.target_id),
        title:
          String(r.target_kind) === "kp"
            ? content.kpById.get(String(r.target_id))?.title ?? String(r.target_id)
            : content.formulaById.get(String(r.target_id))?.name ?? String(r.target_id),
        stage: Number(r.stage),
        dueDate: String(r.due_date),
        lastResult: r.last_result ? String(r.last_result) : null,
      })),
      nextCursor: nextCursor(offset, limit, filtered.length),
    });
  });

  router.post("/api/agent/v1/suggestions", (ctx) => {
    const token = authenticate(db, ctx, "suggestions:write");
    const body = (ctx.body && typeof ctx.body === "object" ? ctx.body : {}) as Record<string, unknown>;
    const kind = String(body.kind ?? "");
    if (!["review_recommendation", "question_candidate"].includes(kind)) {
      throw new HttpError(400, "INVALID_KIND", "kind 只能是 review_recommendation 或 question_candidate。");
    }
    const contentBody = body.content;
    if (!contentBody || typeof contentBody !== "object") {
      throw new HttpError(400, "INVALID_CONTENT", "请提供 content 对象。");
    }
    const c = contentBody as Record<string, unknown>;
    if (kind === "review_recommendation") {
      if (typeof c.text !== "string" || c.text.trim().length < 5 || c.text.length > 2000) {
        throw new HttpError(400, "INVALID_CONTENT", "复习建议需包含 5—2000 字的 text。");
      }
      if (c.kpIds != null && (!Array.isArray(c.kpIds) || c.kpIds.some((x) => typeof x !== "string" || !content.kpById.has(x)))) {
        throw new HttpError(400, "INVALID_CONTENT", "kpIds 含有不存在的知识点。");
      }
    } else {
      const kpId = typeof c.kpId === "string" ? c.kpId : "";
      if (!content.kpById.has(kpId)) throw new HttpError(400, "INVALID_CONTENT", "候选题必须指定存在的 kpId。");
      if (typeof c.prompt !== "string" || c.prompt.trim().length < 3) {
        throw new HttpError(400, "INVALID_CONTENT", "候选题需要 prompt。");
      }
      if (!["choice", "fill", "steps", "calc"].includes(String(c.type))) {
        throw new HttpError(400, "INVALID_CONTENT", "候选题 type 不合法。");
      }
      if (c.answer == null || (typeof c.answer !== "string" && typeof c.answer !== "object")) {
        throw new HttpError(400, "INVALID_CONTENT", "候选题需要 answer。");
      }
      if (typeof c.solution !== "string" || !c.solution.trim()) {
        throw new HttpError(400, "INVALID_CONTENT", "候选题需要 solution。");
      }
      if (typeof c.source !== "string" || !c.source.trim()) {
        throw new HttpError(400, "INVALID_CONTENT", "候选题需要来源说明。");
      }
    }
    const id = randomId("sg_");
    db.prepare(
      "INSERT INTO agent_suggestions (id, user_id, token_id, kind, content, status, created_at) VALUES (?, ?, ?, ?, ?, 'pending', ?)",
    ).run(id, token.user_id, token.id, kind, JSON.stringify(c), nowIso());
    sendJson(ctx.res, 201, {
      id,
      kind,
      status: "pending",
      notice: "建议已进入待采纳列表。候选题目不会参与正式计分，需维护者核验后写入版本化题库。",
    });
  });
}
