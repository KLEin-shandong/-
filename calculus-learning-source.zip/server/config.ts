import { randomBytes } from "node:crypto";
import { existsSync, readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { join } from "node:path";

export interface AppConfig {
  port: number;
  host: string;
  dataDir: string;
  dbPath: string;
  sessionSecret: string;
  signupCode: string;
  allowRegistration: boolean;
  ai: {
    enabled: boolean;
    baseUrl: string;
    model: string;
    apiKey: string;
    timeoutMs: number;
  };
}

function env(name: string, fallback = ""): string {
  return process.env[name] ?? fallback;
}

function loadEnvFile(root: string): void {
  const file = join(root, ".env");
  if (!existsSync(file)) return;
  const text = readFileSync(file, "utf8");
  for (const line of text.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#") || !trimmed.includes("=")) continue;
    const idx = trimmed.indexOf("=");
    const key = trimmed.slice(0, idx).trim();
    let value = trimmed.slice(idx + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    if (process.env[key] === undefined) process.env[key] = value;
  }
}

export function loadConfig(root = process.cwd()): AppConfig {
  loadEnvFile(root);
  const dataDir = join(root, "data");
  mkdirSync(dataDir, { recursive: true });

  let secret = env("SESSION_SECRET");
  if (!secret) {
    const keyFile = join(dataDir, "session.key");
    if (existsSync(keyFile)) secret = readFileSync(keyFile, "utf8").trim();
    else {
      secret = randomBytes(32).toString("hex");
      writeFileSync(keyFile, secret, { mode: 0o600 });
    }
  }

  const signupCode = env("SIGNUP_CODE");
  return {
    port: Number(env("PORT", "3000")),
    host: env("HOST", "127.0.0.1"),
    dataDir,
    dbPath: join(dataDir, "calculus.db"),
    sessionSecret: secret,
    signupCode,
    allowRegistration: env("APP_ALLOW_REGISTRATION", "true") !== "false",
    ai: {
      enabled: env("AI_ENABLED", "false").toLowerCase() === "true",
      baseUrl: env("AI_BASE_URL"),
      model: env("AI_MODEL"),
      apiKey: env("AI_API_KEY"),
      timeoutMs: Number(env("AI_TIMEOUT_MS", "20000")) || 20000,
    },
  };
}
