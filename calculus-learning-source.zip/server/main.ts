import { createServer } from "node:http";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { loadConfig } from "./config.ts";
import { openDb } from "./db.ts";
import { loadContent, watchContent } from "./content.ts";
import { createHandler } from "./app.ts";

const __dirname = dirname(fileURLToPath(import.meta.url));
const root = join(__dirname, "..");

async function main(): Promise<void> {
  const config = loadConfig(root);
  const db = openDb(config.dbPath);
  const content = loadContent();
  if (content.problems.length) {
    console.warn(`[content] ${content.problems.length} 个问题：`);
    for (const p of content.problems.slice(0, 50)) console.warn("  -", p);
  } else {
    console.log(`[content] ${content.kps.length} 个知识点，${content.activeQuestion.size} 道题，校验通过`);
  }

  const contentWatcher = watchContent(content, {
    onReload(next, error) {
      if (error) {
        console.error(`[content] 热更新未应用：${error.message}`);
        return;
      }
      if (!next) return;
      console.log(
        `[content] 已热更新：${next.kps.length} 个知识点，${next.activeQuestion.size} 道题，版本 ${next.version}`,
      );
      if (next.problems.length) {
        console.warn(`[content] 当前仍有 ${next.problems.length} 个校验问题：`);
        for (const p of next.problems.slice(0, 10)) console.warn("  -", p);
      }
    },
  });

  const handler = createHandler({ db, content, config, root, webDir: join(root, "web") });
  const server = createServer(handler);

  const host = process.env.ALLOW_LAN === "true" && config.host === "127.0.0.1" ? "0.0.0.0" : config.host;
  server.listen(config.port, host, () => {
    console.log(`\n微积分学习网站已启动：http://${host === "0.0.0.0" ? "localhost" : host}:${config.port}`);
    console.log(`数据库：${config.dbPath}`);
    console.log(`AI：${config.ai.enabled ? "已启用" : "未启用（使用内置讲解与提示）"}`);
    if (host === "0.0.0.0") console.log("局域网访问已开启，请确保只在可信网络中使用。");
  });

  const shutdown = () => {
    console.log("\n正在关闭……");
    contentWatcher.close();
    server.close(() => {
      db.close();
      process.exit(0);
    });
    setTimeout(() => process.exit(0), 3000).unref();
  };
  process.on("SIGINT", shutdown);
  process.on("SIGTERM", shutdown);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
