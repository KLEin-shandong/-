import { scryptSync, randomBytes, timingSafeEqual, createHash } from "node:crypto";
import type { IncomingMessage, ServerResponse } from "node:http";
import type { DB } from "./db.ts";
import { randomId } from "./db.ts";
import { HttpError, parseCookies, setCookie, clearCookie } from "./http.ts";

export const COOKIE_NAME = "cl_session";
const SESSION_DAYS = 30;

export interface UserRow {
  id: string;
  username: string;
  role: string;
  created_at: string;
}

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `scrypt$${salt}$${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [scheme, salt, hash] = stored.split("$");
  if (scheme !== "scrypt" || !salt || !hash) return false;
  const actual = scryptSync(password, salt, 64);
  const expected = Buffer.from(hash, "hex");
  if (actual.length !== expected.length) return false;
  return timingSafeEqual(actual, expected);
}

function sha256(value: string): string {
  return createHash("sha256").update(value).digest("hex");
}

export function createUser(db: DB, username: string, password: string): UserRow {
  const id = randomId("u_");
  const now = new Date().toISOString();
  db.prepare("INSERT INTO users (id, username, password_hash, role, created_at) VALUES (?, ?, ?, 'learner', ?)").run(
    id,
    username,
    hashPassword(password),
    now,
  );
  db.prepare(
    "INSERT INTO user_settings (user_id, classroom_kp_id, default_minutes, timezone, updated_at) VALUES (?, 'limit-approach', 90, 'Asia/Shanghai', ?)",
  ).run(id, now);
  return { id, username, role: "learner", created_at: now };
}

export function findUserByUsername(db: DB, username: string): (UserRow & { password_hash: string }) | null {
  const row = db
    .prepare("SELECT id, username, role, created_at, password_hash FROM users WHERE username = ? COLLATE NOCASE")
    .get(username) as (UserRow & { password_hash: string }) | undefined;
  return row ?? null;
}

export function login(db: DB, res: ServerResponse, user: UserRow, secure = false): void {
  const token = randomBytes(32).toString("base64url");
  const now = new Date();
  const expires = new Date(now.getTime() + SESSION_DAYS * 86400000);
  db.prepare("INSERT INTO auth_sessions (token_hash, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)").run(
    sha256(token),
    user.id,
    now.toISOString(),
    expires.toISOString(),
  );
  db.prepare("DELETE FROM auth_sessions WHERE expires_at < ?").run(now.toISOString());
  setCookie(res, COOKIE_NAME, token, { maxAge: SESSION_DAYS * 86400, secure });
}

export function logout(db: DB, req: IncomingMessage, res: ServerResponse): void {
  const token = parseCookies(req.headers.cookie)[COOKIE_NAME];
  if (token) db.prepare("DELETE FROM auth_sessions WHERE token_hash = ?").run(sha256(token));
  clearCookie(res, COOKIE_NAME);
}

export function currentUser(db: DB, req: IncomingMessage): UserRow | null {
  const token = parseCookies(req.headers.cookie)[COOKIE_NAME];
  if (!token) return null;
  const row = db
    .prepare(
      `SELECT u.id, u.username, u.role, u.created_at, s.expires_at
       FROM auth_sessions s JOIN users u ON u.id = s.user_id
       WHERE s.token_hash = ?`,
    )
    .get(sha256(token)) as (UserRow & { expires_at: string }) | undefined;
  if (!row) return null;
  if (new Date(row.expires_at).getTime() < Date.now()) {
    db.prepare("DELETE FROM auth_sessions WHERE token_hash = ?").run(sha256(token));
    return null;
  }
  return { id: row.id, username: row.username, role: row.role, created_at: row.created_at };
}

export function requireUser(db: DB, req: IncomingMessage): UserRow {
  const user = currentUser(db, req);
  if (!user) throw new HttpError(401, "UNAUTHENTICATED", "请先登录。");
  return user;
}

export function validateCredentials(username: unknown, password: unknown): { username: string; password: string } {
  if (typeof username !== "string" || typeof password !== "string") {
    throw new HttpError(400, "INVALID_REQUEST", "请填写用户名和密码。");
  }
  const u = username.trim();
  if (!/^[\p{L}\p{N}_\-.]{2,32}$/u.test(u)) {
    throw new HttpError(400, "INVALID_USERNAME", "用户名需为 2—32 个字符，可使用中文、字母、数字、下划线。");
  }
  if (password.length < 8 || password.length > 200) {
    throw new HttpError(400, "INVALID_PASSWORD", "密码至少 8 位，最多 200 位。");
  }
  return { username: u, password };
}
