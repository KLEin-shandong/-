import type { IncomingMessage, ServerResponse } from "node:http";
import { readFile, stat } from "node:fs/promises";
import { existsSync } from "node:fs";
import { join, normalize, extname } from "node:path";
import { stripTypeScriptTypes } from "node:module";
import type { DB } from "./db.ts";
import type { ContentBundle } from "./content.ts";
import type { AppConfig } from "./config.ts";
import { Router, HttpError, parseJsonBody, sendError, sendJson } from "./http.ts";
import { registerApi } from "./api.ts";
import { registerAgentApi } from "./agent.ts";

const MIME: Record<string, string> = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".ts": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".ico": "image/x-icon",
  ".woff2": "font/woff2",
  ".yaml": "text/yaml; charset=utf-8",
  ".md": "text/markdown; charset=utf-8",
};

export interface AppDeps {
  db: DB;
  content: ContentBundle;
  config: AppConfig;
  root: string;
  webDir: string;
}

export function buildRouter(deps: AppDeps): Router {
  const router = new Router();
  registerApi(router, { db: deps.db, content: deps.content, config: deps.config });
  registerAgentApi(router, { db: deps.db, content: deps.content });
  return router;
}

export function createHandler(deps: AppDeps) {
  const router = buildRouter(deps);
  const { webDir, root } = deps;

  function securityHeaders(res: ServerResponse): void {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("X-Frame-Options", "DENY");
    res.setHeader("Referrer-Policy", "no-referrer");
    res.setHeader(
      "Content-Security-Policy",
      "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'",
    );
    res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  }

  async function serveStatic(res: ServerResponse, pathname: string): Promise<boolean> {
    let base = webDir;
    let rel = pathname === "/" ? "index.html" : pathname.replace(/^\/+/, "");
    if (pathname.startsWith("/shared/")) {
      base = join(root, "shared");
      rel = pathname.slice("/shared/".length);
    }
    const safe = normalize(rel).replace(/^(\.\.[/\\])+/, "");
    const file = join(base, safe);
    if (!file.startsWith(base)) return false;
    try {
      const info = await stat(file);
      if (!info.isFile()) return false;
      let data: Buffer | string = await readFile(file);
      const ext = extname(file).toLowerCase();
      if (ext === ".ts") {
        data = stripTypeScriptTypes(data.toString("utf8"), { mode: "strip", sourceUrl: pathname });
      }
      res.writeHead(200, {
        "content-type": MIME[ext] ?? "application/octet-stream",
        "cache-control": ext === ".html" || ext === ".ts" ? "no-store" : "public, max-age=300",
      });
      res.end(data);
      return true;
    } catch {
      return false;
    }
  }

  return async function handler(req: IncomingMessage, res: ServerResponse): Promise<void> {
    securityHeaders(res);
    const url = new URL(req.url ?? "/", `http://${req.headers.host ?? "localhost"}`);
    const pathname = decodeURIComponent(url.pathname);
    try {
      if (pathname.startsWith("/api/")) {
        const match = router.match(req.method ?? "GET", pathname);
        if (!match) {
          sendError(res, 404, "NOT_FOUND", "接口不存在。");
          return;
        }
        const body = req.method === "GET" || req.method === "HEAD" ? null : await parseJsonBody(req);
        await match.handler({ req, res, url, params: match.params, body });
        return;
      }

      if (req.method !== "GET" && req.method !== "HEAD") {
        sendError(res, 405, "METHOD_NOT_ALLOWED", "不支持的请求方法。");
        return;
      }

      if (pathname === "/openapi.yaml") {
        const file = join(root, "docs", "openapi.yaml");
        if (existsSync(file)) {
          res.writeHead(200, { "content-type": "text/yaml; charset=utf-8", "cache-control": "no-store" });
          res.end(await readFile(file));
          return;
        }
      }

      if (await serveStatic(res, pathname)) return;

      const index = join(webDir, "index.html");
      res.writeHead(200, { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" });
      res.end(await readFile(index));
    } catch (e) {
      if (e instanceof HttpError) {
        sendError(res, e.status, e.code, e.message);
        return;
      }
      console.error("[server]", e);
      if (!res.headersSent) sendJson(res, 500, { error: { code: "INTERNAL", message: "服务器内部错误。" } });
      else res.end();
    }
  };
}
