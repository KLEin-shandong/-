import type { DB } from "./db.ts";
import { randomId, nowIso } from "./db.ts";
import type {
  AnswerValue,
  Difficulty,
  KnowledgePoint,
  MasteryState,
  Question,
  ReviewItem,
  SessionState,
} from "../shared/types.ts";
import {
  DIFFICULTIES,
  addDays,
  evaluateDifficulty,
  evaluateMastery,
  nextReview,
  recentDistinctFirstAttempts,
  shanghaiDate,
  type AttemptFact,
} from "../shared/learning.ts";
import type { ContentBundle } from "./content.ts";

export interface SettingsRow {
  user_id: string;
  classroom_kp_id: string;
  default_minutes: number;
  timezone: string;
}

export interface KpStateRow {
  user_id: string;
  kp_id: string;
  difficulty: Difficulty;
  mastery: MasteryState;
  pending_since: string | null;
  verified_at: string | null;
  mastered_at: string | null;
  updated_at: string;
}

export function getSettings(db: DB, userId: string) {
  let row = db.prepare("SELECT * FROM user_settings WHERE user_id = ?").get(userId) as SettingsRow | undefined;
  if (!row) {
    db.prepare(
      "INSERT INTO user_settings (user_id, classroom_kp_id, default_minutes, timezone, updated_at) VALUES (?, 'limit-approach', 90, 'Asia/Shanghai', ?)",
    ).run(userId, nowIso());
    row = { user_id: userId, classroom_kp_id: "limit-approach", default_minutes: 90, timezone: "Asia/Shanghai" };
  }
  return row;
}

export function updateSettings(
  db: DB,
  userId: string,
  patch: { classroomKpId?: string; defaultMinutes?: number },
): SettingsRow {
  const s = getSettings(db, userId);
  const minutes = patch.defaultMinutes != null ? Math.max(10, Math.min(90, Math.round(patch.defaultMinutes))) : s.default_minutes;
  const classroom = patch.classroomKpId?.trim() || s.classroom_kp_id;
  db.prepare("UPDATE user_settings SET classroom_kp_id = ?, default_minutes = ?, updated_at = ? WHERE user_id = ?").run(
    classroom,
    minutes,
    nowIso(),
    userId,
  );
  return getSettings(db, userId);
}

export function getKpState(db: DB, userId: string, kpId: string): KpStateRow {
  let row = db.prepare("SELECT * FROM kp_state WHERE user_id = ? AND kp_id = ?").get(userId, kpId) as
    | KpStateRow
    | undefined;
  if (!row) {
    row = {
      user_id: userId,
      kp_id: kpId,
      difficulty: "basic",
      mastery: "not_started",
      pending_since: null,
      verified_at: null,
      mastered_at: null,
      updated_at: nowIso(),
    };
  }
  return row;
}

export function allKpStates(db: DB, userId: string): Map<string, KpStateRow> {
  const rows = db.prepare("SELECT * FROM kp_state WHERE user_id = ?").all(userId) as unknown as KpStateRow[];
  return new Map(rows.map((r) => [r.kp_id, r]));
}

export function saveKpState(db: DB, state: KpStateRow): void {
  db.prepare(
    `INSERT INTO kp_state (user_id, kp_id, difficulty, mastery, pending_since, verified_at, mastered_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)
     ON CONFLICT(user_id, kp_id) DO UPDATE SET
       difficulty = excluded.difficulty, mastery = excluded.mastery,
       pending_since = excluded.pending_since, verified_at = excluded.verified_at,
       mastered_at = excluded.mastered_at, updated_at = excluded.updated_at`,
  ).run(
    state.user_id,
    state.kp_id,
    state.difficulty,
    state.mastery,
    state.pending_since,
    state.verified_at,
    state.mastered_at,
    state.updated_at,
  );
}

export function attemptsForKp(db: DB, userId: string, kpId: string, limit = 200): AttemptFact[] {
  const rows = db
    .prepare(
      `SELECT question_id, kp_id, correct, format_error, independent, first_attempt, hint_level, solution_viewed, created_at
       FROM submissions WHERE user_id = ? AND kp_id = ? ORDER BY created_at ASC LIMIT ?`,
    )
    .all(userId, kpId, limit) as Array<Record<string, unknown>>;
  return rows.map((r) => ({
    questionId: String(r.question_id),
    kpId: String(r.kp_id),
    correct: Boolean(r.correct),
    formatError: Boolean(r.format_error),
    independent: Boolean(r.independent),
    firstAttempt: Boolean(r.first_attempt),
    hintLevel: Number(r.hint_level),
    solutionViewed: Boolean(r.solution_viewed),
    createdAt: String(r.created_at),
  }));
}

export function updateStateAfterSubmission(
  db: DB,
  userId: string,
  kpId: string,
  latest: AttemptFact,
): { difficulty: Difficulty; mastery: MasteryState; moved: string; justMastered: boolean } {
  const state = getKpState(db, userId, kpId);
  const attempts = attemptsForKp(db, userId, kpId);
  const diff = evaluateDifficulty(attempts, state.difficulty);
  const today = shanghaiDate();
  const mastery = evaluateMastery(attempts, state.mastery, state.pending_since, today);

  const next: KpStateRow = {
    ...state,
    difficulty: diff.level,
    mastery: mastery.state,
    pending_since: mastery.pendingSince,
    verified_at: mastery.justMastered ? nowIso() : state.verified_at,
    mastered_at: mastery.justMastered ? nowIso() : state.mastered_at,
    updated_at: nowIso(),
  };
  if (mastery.state === "needs_review") next.pending_since = null;
  saveKpState(db, next);

  // 首次作答错误：若已有该知识点的复习任务，回退到第 1 天
  if (latest.firstAttempt && !latest.correct && !latest.formatError) {
    const item = db
      .prepare("SELECT * FROM review_items WHERE user_id = ? AND target_kind = 'kp' AND target_id = ?")
      .get(userId, kpId) as ReviewRow | undefined;
    if (item) {
      db.prepare("UPDATE review_items SET stage = 0, due_date = ?, last_result = 'bad', updated_at = ? WHERE id = ?").run(
        addDays(today, 1),
        nowIso(),
        item.id,
      );
    }
  }

  return { difficulty: diff.level, mastery: mastery.state, moved: diff.reason, justMastered: mastery.justMastered };
}

export interface ReviewRow {
  id: string;
  user_id: string;
  target_kind: "kp" | "formula";
  target_id: string;
  stage: number;
  due_date: string;
  last_result: string | null;
  created_at: string;
  updated_at: string;
}

export function upsertReview(
  db: DB,
  userId: string,
  kind: "kp" | "formula",
  targetId: string,
  opts: { stage?: number; dueDate?: string; result?: "good" | "fuzzy" | "bad" } = {},
): ReviewRow {
  const existing = db
    .prepare("SELECT * FROM review_items WHERE user_id = ? AND target_kind = ? AND target_id = ?")
    .get(userId, kind, targetId) as ReviewRow | undefined;
  if (existing) {
    if (opts.stage != null || opts.dueDate || opts.result) {
      db.prepare("UPDATE review_items SET stage = ?, due_date = ?, last_result = ?, updated_at = ? WHERE id = ?").run(
        opts.stage ?? existing.stage,
        opts.dueDate ?? existing.due_date,
        opts.result ?? existing.last_result,
        nowIso(),
        existing.id,
      );
    }
    return db.prepare("SELECT * FROM review_items WHERE id = ?").get(existing.id) as unknown as ReviewRow;
  }
  const id = randomId("r_");
  db.prepare(
    "INSERT INTO review_items (id, user_id, target_kind, target_id, stage, due_date, last_result, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
  ).run(
    id,
    userId,
    kind,
    targetId,
    opts.stage ?? 0,
    opts.dueDate ?? addDays(shanghaiDate(), 1),
    opts.result ?? null,
    nowIso(),
    nowIso(),
  );
  return db.prepare("SELECT * FROM review_items WHERE id = ?").get(id) as unknown as ReviewRow;
}

export function dueReviews(db: DB, userId: string, today = shanghaiDate()): ReviewRow[] {
  return db
    .prepare(
      "SELECT * FROM review_items WHERE user_id = ? AND due_date <= ? ORDER BY due_date ASC, created_at ASC",
    )
    .all(userId, today) as unknown as ReviewRow[];
}

export function applyReviewResult(
  db: DB,
  userId: string,
  item: ReviewRow,
  result: "good" | "fuzzy" | "bad",
): ReviewRow {
  const outcome = nextReview(item.stage, result);
  db.prepare("UPDATE review_items SET stage = ?, due_date = ?, last_result = ?, updated_at = ? WHERE id = ?").run(
    outcome.stage,
    outcome.dueDate,
    result,
    nowIso(),
    item.id,
  );
  if (item.target_kind === "formula") {
    db.prepare("INSERT INTO formula_reviews (id, user_id, formula_id, result, created_at) VALUES (?, ?, ?, ?, ?)").run(
      randomId("fr_"),
      userId,
      item.target_id,
      result,
      nowIso(),
    );
  }
  return db.prepare("SELECT * FROM review_items WHERE id = ?").get(item.id) as unknown as ReviewRow;
}

export function reviewResultFromSession(attempts: AttemptFact[]): "good" | "fuzzy" | "bad" {
  if (attempts.length === 0) return "fuzzy";
  const valid = attempts.filter((a) => !a.formatError && a.firstAttempt);
  if (valid.length === 0) return "fuzzy";
  if (valid.some((a) => !a.correct)) return "bad";
  if (valid.some((a) => a.hintLevel > 0 || a.solutionViewed || !a.independent)) return "fuzzy";
  return "good";
}

export function questionSelection(
  content: ContentBundle,
  kpId: string,
  difficulty: Difficulty,
  limit = 6,
): Question[] {
  const pool = (content.questionsByKp.get(kpId) ?? []).filter((q) => !q.tags?.includes("placement"));
  if (pool.length === 0) return [];
  const target = DIFFICULTIES.indexOf(difficulty);
  const diffs = DIFFICULTIES.map((d, i) => ({ d, dist: Math.abs(i - target), i }))
    .sort((a, b) => a.dist - b.dist || a.i - b.i)
    .map((x) => x.d);
  const chosen: Question[] = [];
  const roles = ["concept", "step", "independent"] as const;
  const take = (q: Question | undefined) => {
    if (q && !chosen.some((x) => x.id === q.id)) chosen.push(q);
  };
  // 先按“最近难度”各取一个角色，再取下一层，形成 6 题（每难度 3 角色）
  for (const d of diffs) {
    for (const role of roles) {
      take(pool.find((q) => q.difficulty === d && q.role === role && !chosen.some((x) => x.id === q.id)));
    }
    if (chosen.length >= limit) break;
  }
  if (chosen.length < Math.min(limit, pool.length)) {
    const rest = pool
      .map((q) => ({ q, dist: Math.abs(DIFFICULTIES.indexOf(q.difficulty) - target) }))
      .sort((a, b) => a.dist - b.dist || a.q.id.localeCompare(b.q.id));
    for (const item of rest) {
      if (chosen.length >= limit) break;
      take(item.q);
    }
  }
  const order = { concept: 0, step: 1, independent: 2 };
  return chosen.slice(0, limit).sort((a, b) => order[a.role] - order[b.role] || a.id.localeCompare(b.id));
}

export function sessionState(row: Record<string, unknown>): SessionState {
  return {
    id: String(row.id),
    userId: String(row.user_id),
    kpId: String(row.kp_id),
    status: row.status as SessionState["status"],
    questionIds: JSON.parse(String(row.question_ids)) as string[],
    position: Number(row.position),
    drafts: JSON.parse(String(row.drafts)) as Record<string, AnswerValue | null>,
    revision: Number(row.revision),
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at),
  };
}

export function getSession(db: DB, userId: string, id: string): Record<string, unknown> | null {
  const row = db.prepare("SELECT * FROM study_sessions WHERE id = ? AND user_id = ?").get(id, userId) as
    | Record<string, unknown>
    | undefined;
  return row ?? null;
}

export function sessionPayload(
  db: DB,
  content: ContentBundle,
  userId: string,
  row: Record<string, unknown>,
) {
  const state = sessionState(row);
  const kp = content.kpById.get(state.kpId);
  const questions = state.questionIds
    .map((id) => content.activeQuestion.get(id))
    .filter((q): q is Question => Boolean(q));
  const events = db
    .prepare("SELECT question_id, hint_level, solution_viewed FROM question_events WHERE session_id = ?")
    .all(state.id) as Array<Record<string, unknown>>;
  const eventMap = new Map(events.map((e) => [String(e.question_id), e]));
  const submissions = db
    .prepare("SELECT question_id, correct, format_error, first_attempt FROM submissions WHERE session_id = ?")
    .all(state.id) as Array<Record<string, unknown>>;
  const firstByQ = new Map<string, { correct: boolean; formatError: boolean }>();
  for (const s of submissions) {
    if (Boolean(s.first_attempt)) {
      firstByQ.set(String(s.question_id), { correct: Boolean(s.correct), formatError: Boolean(s.format_error) });
    }
  }
  const publicQs = questions.map((q) => {
    const ev = eventMap.get(q.id);
    return {
      id: q.id,
      version: q.version,
      kpId: q.kpId,
      difficulty: q.difficulty,
      type: q.type,
      role: q.role,
      prompt: q.prompt,
      options: q.options,
      formatHint: q.formatHint,
      stepLabels: q.answer.kind === "steps" ? q.answer.steps.map((s) => s.label) : undefined,
      hintLevel: Number(ev?.hint_level ?? 0),
      hints: q.hints.slice(0, Number(ev?.hint_level ?? 0)),
      solutionViewed: Boolean(ev?.solution_viewed),
      solution: ev?.solution_viewed ? q.solution : undefined,
      answered: firstByQ.has(q.id),
      correct: firstByQ.get(q.id)?.correct ?? null,
      formatError: firstByQ.get(q.id)?.formatError ?? null,
    };
  });
  return {
    session: state,
    kp: kp
      ? {
          id: kp.id,
          title: kp.title,
          subtitle: kp.subtitle,
          module: kp.module,
          minutes: kp.minutes,
          summary: kp.summary,
          formulaIds: kp.formulaIds,
        }
      : null,
    questions: publicQs,
    mode: String(row.mode ?? "learn"),
  };
}

export function statsForUser(db: DB, content: ContentBundle, userId: string) {
  const rows = db
    .prepare(
      `SELECT kp_id,
        SUM(CASE WHEN first_attempt = 1 AND format_error = 0 THEN 1 ELSE 0 END) AS firsts,
        SUM(CASE WHEN first_attempt = 1 AND independent = 1 THEN 1 ELSE 0 END) AS independent,
        SUM(CASE WHEN first_attempt = 1 AND correct = 1 AND hint_level > 0 THEN 1 ELSE 0 END) AS hinted,
        SUM(CASE WHEN first_attempt = 1 AND correct = 0 AND format_error = 0 THEN 1 ELSE 0 END) AS wrong,
        MAX(created_at) AS last
       FROM submissions WHERE user_id = ? GROUP BY kp_id`,
    )
    .all(userId) as Array<Record<string, unknown>>;
  const states = allKpStates(db, userId);
  const byKp = new Map(rows.map((r) => [String(r.kp_id), r]));
  return content.kps.map((kp) => {
    const r = byKp.get(kp.id);
    const st = states.get(kp.id);
    return {
      kpId: kp.id,
      title: kp.title,
      module: kp.module,
      firstAttempts: Number(r?.firsts ?? 0),
      independentCorrect: Number(r?.independent ?? 0),
      hintedCorrect: Number(r?.hinted ?? 0),
      wrong: Number(r?.wrong ?? 0),
      lastAt: r?.last ? String(r.last) : null,
      difficulty: st?.difficulty ?? "basic",
      mastery: st?.mastery ?? "not_started",
    };
  });
}

export function kpSummary(
  db: DB,
  content: ContentBundle,
  userId: string,
  kp: KnowledgePoint,
  state: KpStateRow | undefined,
  review: ReviewRow | undefined,
) {
  return {
    id: kp.id,
    module: kp.module,
    order: kp.order,
    title: kp.title,
    subtitle: kp.subtitle,
    minutes: kp.minutes,
    prereqs: kp.prereqs,
    prereqTitles: kp.prereqs.map((p) => content.kpById.get(p)?.title ?? p),
    mastery: state?.mastery ?? "not_started",
    difficulty: state?.difficulty ?? "basic",
    pendingSince: state?.pending_since ?? null,
    verifiedAt: state?.verified_at ?? null,
    masteredAt: state?.mastered_at ?? null,
    reviewDue: review ? review.due_date : null,
    reviewStage: review?.stage ?? null,
    formulaCount: kp.formulaIds?.length ?? 0,
    questionCount: (content.questionsByKp.get(kp.id) ?? []).length,
  };
}

export function publicKnowledgePoint(content: ContentBundle, kp: KnowledgePoint) {
  return {
    id: kp.id,
    module: kp.module,
    order: kp.order,
    title: kp.title,
    subtitle: kp.subtitle,
    version: kp.version,
    minutes: kp.minutes,
    prereqs: kp.prereqs,
    prereqTitles: kp.prereqs.map((p) => content.kpById.get(p)?.title ?? p),
    source: kp.source,
    objectives: kp.objectives,
    blocks: kp.blocks,
    summary: kp.summary,
    formulaIds: kp.formulaIds,
    formulas: (kp.formulaIds ?? [])
      .map((id) => content.formulaById.get(id))
      .filter(Boolean)
      .map((f) => ({ id: f!.id, name: f!.name, tex: f!.tex, conditions: f!.conditions })),
  };
}

export function findWrongNotebook(db: DB, content: ContentBundle, userId: string) {
  const rows = db
    .prepare(
      `SELECT s.* FROM submissions s
       WHERE s.user_id = ? AND s.first_attempt = 1 AND s.correct = 0 AND s.format_error = 0
       ORDER BY s.created_at DESC`,
    )
    .all(userId) as Array<Record<string, unknown>>;
  const items = new Map<string, Record<string, unknown>>();
  for (const r of rows) {
    const qid = String(r.question_id);
    if (!items.has(qid)) items.set(qid, r);
  }
  const out = [];
  for (const [qid, first] of items) {
    const version = Number(first.question_version);
    const q = content.questionVersions.get(`${qid}@${version}`) ?? content.activeQuestion.get(qid);
    if (!q) continue;
    const history = db
      .prepare(
        `SELECT id, answer, correct, format_error, hint_level, solution_viewed, first_attempt, created_at
         FROM submissions WHERE user_id = ? AND question_id = ? ORDER BY created_at DESC LIMIT 20`,
      )
      .all(userId, qid) as Array<Record<string, unknown>>;
    const review = db
      .prepare("SELECT due_date, stage FROM review_items WHERE user_id = ? AND target_kind = 'kp' AND target_id = ?")
      .get(userId, q.kpId) as { due_date: string; stage: number } | undefined;
    out.push({
      questionId: qid,
      version,
      kpId: q.kpId,
      kpTitle: content.kpById.get(q.kpId)?.title ?? q.kpId,
      module: content.kpById.get(q.kpId)?.module ?? "limits",
      difficulty: q.difficulty,
      type: q.type,
      role: q.role,
      prompt: q.prompt,
      options: q.options,
      formatHint: q.formatHint,
      hints: q.hints,
      solution: q.solution,
      source: q.source,
      lastAnswer: JSON.parse(String(first.answer)),
      lastAt: first.created_at,
      hintLevel: Number(first.hint_level),
      solutionViewed: Boolean(first.solution_viewed),
      attempts: history.map((h) => ({
        id: h.id,
        answer: JSON.parse(String(h.answer)),
        correct: Boolean(h.correct),
        formatError: Boolean(h.format_error),
        hintLevel: Number(h.hint_level),
        solutionViewed: Boolean(h.solution_viewed),
        firstAttempt: Boolean(h.first_attempt),
        createdAt: h.created_at,
      })),
      reviewDue: review?.due_date ?? null,
    });
  }
  return out;
}
