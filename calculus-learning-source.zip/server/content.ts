import { readFileSync, readdirSync, existsSync, watch, type FSWatcher } from "node:fs";
import { createHash } from "node:crypto";
import { join, dirname, relative, sep } from "node:path";
import { fileURLToPath } from "node:url";
import type { FormulaCard, KnowledgePoint, ModuleId, Question } from "../shared/types.ts";

const __dirname = dirname(fileURLToPath(import.meta.url));
export const CONTENT_DIR = join(__dirname, "..", "content");

export interface ModuleInfo {
  id: ModuleId;
  title: string;
  description: string;
  order: number;
}

export interface ContentBundle {
  modules: ModuleInfo[];
  kps: KnowledgePoint[];
  kpById: Map<string, KnowledgePoint>;
  questions: Question[];
  questionsByKp: Map<string, Question[]>;
  /** 同一题目的所有历史版本，key 为 `${id}@${version}` */
  questionVersions: Map<string, Question>;
  activeQuestion: Map<string, Question>;
  formulas: FormulaCard[];
  formulaById: Map<string, FormulaCard>;
  problems: string[];
  version: string;
}

export const MODULES: ModuleInfo[] = [
  { id: "func", title: "函数基础", description: "符号、运算、定义域与图像，为极限做准备", order: 1 },
  { id: "limits", title: "极限与连续", description: "从“趋近”到极限计算、连续与间断", order: 2 },
  { id: "derivatives", title: "导数入门", description: "变化率、切线、求导法则与经济含义", order: 3 },
];

function readJson<T>(file: string, onRaw?: (raw: string) => void): T {
  let raw: string;
  try {
    raw = readFileSync(file, "utf8");
  } catch (e) {
    throw new Error(`${file}: ${(e as Error).message}`);
  }
  onRaw?.(raw);
  try {
    return JSON.parse(raw) as T;
  } catch (e) {
    throw new Error(`${file}: ${(e as Error).message}`);
  }
}

function listJson(dir: string): string[] {
  if (!existsSync(dir)) return [];
  return readdirSync(dir)
    .filter((f) => f.endsWith(".json") && !f.startsWith("."))
    .sort()
    .map((f) => join(dir, f));
}

export function loadContent(dir = CONTENT_DIR): ContentBundle {
  const signature = createHash("sha256");
  const read = <T>(file: string): T =>
    readJson<T>(file, (raw) => {
      signature.update(relative(dir, file).split(sep).join("/"));
      signature.update("\0");
      signature.update(raw);
      signature.update("\0");
    });

  const problems: string[] = [];
  const kps: KnowledgePoint[] = [];
  const kpById = new Map<string, KnowledgePoint>();

  for (const file of listJson(join(dir, "knowledge-points"))) {
    let item: KnowledgePoint;
    try {
      item = read<KnowledgePoint>(file);
    } catch (e) {
      problems.push((e as Error).message);
      continue;
    }
    if (!item.id) {
      problems.push(`${file}: 缺少 id`);
      continue;
    }
    if (kpById.has(item.id)) problems.push(`知识点编号重复：${item.id}`);
    kps.push(item);
    kpById.set(item.id, item);
  }
  kps.sort((a, b) => {
    const ma = MODULES.find((m) => m.id === a.module)?.order ?? 9;
    const mb = MODULES.find((m) => m.id === b.module)?.order ?? 9;
    return ma - mb || a.order - b.order;
  });

  const questions: Question[] = [];
  const questionVersions = new Map<string, Question>();
  const activeQuestion = new Map<string, Question>();
  for (const dirName of ["questions", "archive"]) {
    for (const file of listJson(join(dir, dirName))) {
      let items: Question[];
      try {
        const raw = read<Question[] | Question>(file);
        items = Array.isArray(raw) ? raw : [raw];
      } catch (e) {
        problems.push((e as Error).message);
        continue;
      }
      for (const q of items) {
        if (!q.id || !q.version) {
          problems.push(`${file}: 题目缺少 id 或 version`);
          continue;
        }
        const key = `${q.id}@${q.version}`;
        if (questionVersions.has(key)) problems.push(`题目版本重复：${key}`);
        questionVersions.set(key, q);
        const prev = activeQuestion.get(q.id);
        if (!prev || prev.version < q.version) activeQuestion.set(q.id, q);
        if (!kpById.has(q.kpId)) problems.push(`题目 ${q.id} 引用了不存在的知识点 ${q.kpId}`);
        questions.push(q);
      }
    }
  }

  const questionsByKp = new Map<string, Question[]>();
  for (const q of activeQuestion.values()) {
    if (q.tags?.includes("placement")) continue;
    const arr = questionsByKp.get(q.kpId) ?? [];
    arr.push(q);
    questionsByKp.set(q.kpId, arr);
  }
  for (const arr of questionsByKp.values()) {
    arr.sort((a, b) => {
      const order = { concept: 0, step: 1, independent: 2 };
      return order[a.role] - order[b.role] || a.difficulty.localeCompare(b.difficulty) || a.id.localeCompare(b.id);
    });
  }

  const formulas: FormulaCard[] = [];
  const formulaById = new Map<string, FormulaCard>();
  const fFile = join(dir, "formulas.json");
  if (existsSync(fFile)) {
    try {
      const raw = read<FormulaCard[] | { formulas: FormulaCard[] }>(fFile);
      const list = Array.isArray(raw) ? raw : raw.formulas;
      for (const f of list) {
        if (formulaById.has(f.id)) problems.push(`公式编号重复：${f.id}`);
        formulas.push(f);
        formulaById.set(f.id, f);
      }
    } catch (e) {
      problems.push((e as Error).message);
    }
  }

  // 引用检查
  for (const kp of kps) {
    for (const p of kp.prereqs) if (!kpById.has(p)) problems.push(`知识点 ${kp.id} 的前置 ${p} 不存在`);
    for (const fid of kp.formulaIds ?? []) if (!formulaById.has(fid)) problems.push(`知识点 ${kp.id} 引用的公式 ${fid} 不存在`);
    const qs = questionsByKp.get(kp.id) ?? [];
    if (qs.length < 6) problems.push(`知识点 ${kp.id} 的题目不足 6 道（当前 ${qs.length}）`);
    const roles = new Set(qs.map((q) => q.role));
    for (const r of ["concept", "step", "independent"] as const) {
      if (!roles.has(r)) problems.push(`知识点 ${kp.id} 缺少 ${r} 类型练习`);
    }
  }

  // 版本取内容原文摘要：即使编辑者忘记提升 version，任何文本改动也会触发前端刷新。
  const version = createHash("sha256")
    .update([...questionVersions.keys()].sort().join("|"))
    .update("#")
    .update(kps.map((k) => `${k.id}@${k.version}`).sort().join("|"))
    .update("\0")
    .update(signature.digest())
    .digest("base64url")
    .slice(0, 16);

  return {
    modules: MODULES,
    kps,
    kpById,
    questions,
    questionsByKp,
    questionVersions,
    activeQuestion,
    formulas,
    formulaById,
    problems,
    version: Buffer.from(version).toString("base64url").slice(0, 16),
  };
}

export function questionFor(c: ContentBundle, id: string, version: number): Question | null {
  return c.questionVersions.get(`${id}@${version}`) ?? c.activeQuestion.get(id) ?? null;
}

export interface ContentWatcher {
  /** 立即重新载入一次（用于测试或手动触发）。 */
  reloadNow(): void;
  close(): void;
}

export interface WatchContentOptions {
  dir?: string;
  debounceMs?: number;
  onReload?: (next: ContentBundle | null, error?: Error) => void;
}

/**
 * 监听内容目录并原地替换 ContentBundle，使已注册的接口立即使用新内容。
 * 新内容出现更多校验问题时保留旧内容，避免一次误保存把站点改坏。
 */
export function watchContent(content: ContentBundle, options: WatchContentOptions = {}): ContentWatcher {
  const dir = options.dir ?? CONTENT_DIR;
  let timer: ReturnType<typeof setTimeout> | null = null;
  let closed = false;
  let watcher: FSWatcher | null = null;

  const apply = (): void => {
    if (closed) return;
    try {
      const next = loadContent(dir);
      const known = new Set(content.problems);
      const introduced = next.problems.filter((p) => !known.has(p));
      if (introduced.length) {
        options.onReload?.(
          null,
          new Error(`新内容引入了 ${introduced.length} 个校验问题（例如：${introduced[0]}），已保留旧内容。`),
        );
        return;
      }
      Object.assign(content, next);
      options.onReload?.(next);
    } catch (e) {
      options.onReload?.(null, e instanceof Error ? e : new Error(String(e)));
    }
  };

  const schedule = (): void => {
    if (closed) return;
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => {
      timer = null;
      apply();
    }, options.debounceMs ?? 300);
    timer.unref?.();
  };

  try {
    watcher = watch(dir, { recursive: true }, (_event, filename) => {
      if (!filename || filename.toLowerCase().endsWith(".json")) schedule();
    });
    watcher.on("error", (e) => console.error("[content] 内容目录监听出错：", e));
    watcher.unref?.();
  } catch (e) {
    console.error(`[content] 无法监听内容目录 ${dir}：`, e);
  }

  return {
    reloadNow(): void {
      if (timer) {
        clearTimeout(timer);
        timer = null;
      }
      apply();
    },
    close(): void {
      closed = true;
      if (timer) {
        clearTimeout(timer);
        timer = null;
      }
      watcher?.close();
      watcher = null;
    },
  };
}
