#Requires -RunAsAdministrator
[CmdletBinding()]
param(
    [string]$ProjectDir = "",
    [string]$TaskName = "CalculusLearning",
    [int]$Port = 3102
)

$ErrorActionPreference = "Stop"

if (-not $ProjectDir) {
    $ProjectDir = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
}

$mainFile = Join-Path $ProjectDir "server\main.ts"
$envFile = Join-Path $ProjectDir ".env"
if (-not (Test-Path $mainFile)) {
    throw "server/main.ts not found under $ProjectDir"
}
if (-not (Test-Path $envFile)) {
    throw ".env not found. Copy .env.example to .env and fill it in first."
}

$node = (Get-Command node.exe -ErrorAction Stop).Source

$existing = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
if ($existing) {
    Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
    for ($i = 0; $i -lt 20; $i++) {
        $listener = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
        if (-not $listener) { break }
        Start-Sleep -Milliseconds 250
    }
}

$listener = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
if ($listener) {
    throw "Port $Port is already in use. Stop the current server before installing the scheduled task."
}

$action = New-ScheduledTaskAction `
    -Execute $node `
    -Argument "--disable-warning=ExperimentalWarning server/main.ts" `
    -WorkingDirectory $ProjectDir

$trigger = New-ScheduledTaskTrigger -AtStartup

$settings = New-ScheduledTaskSettingsSet `
    -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries `
    -StartWhenAvailable `
    -RestartCount 3 `
    -RestartInterval (New-TimeSpan -Minutes 1) `
    -ExecutionTimeLimit ([TimeSpan]::Zero)

$principal = New-ScheduledTaskPrincipal `
    -UserId "SYSTEM" `
    -LogonType ServiceAccount `
    -RunLevel Highest

Register-ScheduledTask `
    -TaskName $TaskName `
    -Action $action `
    -Trigger $trigger `
    -Settings $settings `
    -Principal $principal `
    -Description "Calculus learning web app" `
    -Force | Out-Null

Start-ScheduledTask -TaskName $TaskName
Start-Sleep -Seconds 2

Get-ScheduledTask -TaskName $TaskName | Select-Object TaskName, State

try {
    $health = Invoke-WebRequest -UseBasicParsing -Uri "http://127.0.0.1:$Port/api/health" -TimeoutSec 5
    Write-Host "Health: $($health.Content)"
} catch {
    Write-Warning "Task installed, but the health check failed: $($_.Exception.Message)"
}
