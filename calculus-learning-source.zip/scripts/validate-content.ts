import { existsSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { loadContent } from "../server/content.ts";
import { expressionsEqual } from "../shared/expr.ts";
import type { Block, Question, KnowledgePoint } from "../shared/types.ts";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const errors: string[] = [];
const warnings: string[] = [];
const content = loadContent();
errors.push(...content.problems);

const SUPPORTED_TEX = new Set([
  "frac", "dfrac", "tfrac", "sqrt", "text", "textrm", "mathrm", "operatorname", "mathbb",
  "overline", "bar", "underline", "vec", "hat", "left", "right", "big", "Big", "bigl", "bigr",
  "Bigl", "Bigr", "bigg", "Bigg", "displaystyle", "textstyle", "limits", "nolimits", "quad", "qquad",
  "langle", "rangle", "lfloor", "rfloor", "lceil", "rceil", "lim",
  "sin", "cos", "tan", "cot", "sec", "csc", "arcsin", "arccos", "arctan", "ln", "log", "lg", "exp",
  "max", "min", "sup", "inf", "det",
  "to", "rightarrow", "leftarrow", "Rightarrow", "Leftarrow", "Leftrightarrow", "leftrightarrow",
  "infty", "cdot", "times", "div", "pm", "mp", "le", "leq", "ge", "geq", "ne", "neq", "approx",
  "equiv", "sim", "propto", "Delta", "delta", "varepsilon", "epsilon", "alpha", "beta", "gamma",
  "theta", "lambda", "mu", "sigma", "phi", "omega", "partial", "sum", "prod", "int", "in", "notin",
  "subset", "subseteq", "cup", "cap", "emptyset", "forall", "exists", "cdots", "ldots", "dots",
  "circ", "angle", "perp", "parallel", "triangle", "checkmark", "degree", "prime", "therefore",
  "because", "cong", "lt", "gt",
]);

function checkTex(tex: string, where: string): void {
  if (!tex || !tex.trim()) {
    errors.push(`${where}: 空公式`);
    return;
  }
  const re = /\\([a-zA-Z]+)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(tex))) {
    if (!SUPPORTED_TEX.has(m[1])) warnings.push(`${where}: 未渲染的 TeX 命令 \\${m[1]}`);
  }
  const braces = (tex.match(/{/g) ?? []).length - (tex.match(/}/g) ?? []).length;
  if (braces !== 0) errors.push(`${where}: 花括号不配对`);
}

function checkMd(md: string, where: string): void {
  if (typeof md !== "string" || !md.trim()) {
    errors.push(`${where}: 空文本`);
    return;
  }
  const dollars = (md.match(/\$/g) ?? []).length;
  if (dollars % 2 !== 0) errors.push(`${where}: 行内公式 $ 未配对`);
  if (/TODO|待补|占位|xxx|XXX|显然|易知/.test(md)) warnings.push(`${where}: 含占位或应避免的措辞`);
}

function checkBlocks(blocks: Block[] | undefined, where: string): void {
  if (!Array.isArray(blocks) || blocks.length === 0) {
    errors.push(`${where}: 缺少内容块`);
    return;
  }
  blocks.forEach((b, i) => {
    const w = `${where}[${i}]`;
    switch (b.t) {
      case "p": checkMd(b.md, w); break;
      case "h": checkMd(b.text, w); break;
      case "math": checkTex(b.tex, w); break;
      case "example":
        checkMd(b.title, w);
        if (!b.steps?.length) errors.push(`${w}: 例题缺少步骤`);
        b.steps?.forEach((s, j) => checkMd(s, `${w}.steps[${j}]`));
        if (b.answer) checkMd(b.answer, `${w}.answer`);
        break;
      case "pitfall": if (b.title) checkMd(b.title, w); checkMd(b.md, w); break;
      case "callout": if (b.title) checkMd(b.title, w); checkMd(b.md, w); break;
      case "table":
        if (!b.head?.length || !b.rows?.length) errors.push(`${w}: 表格为空`);
        b.rows.forEach((r, j) => {
          if (r.length !== b.head.length) errors.push(`${w}.rows[${j}]: 列数不一致`);
          r.forEach((c, k) => checkMd(c, `${w}.rows[${j}][${k}]`));
        });
        break;
      case "figure":
        if (!b.spec?.kind) errors.push(`${w}: 图像缺少 kind`);
        if (b.spec?.kind === "graph" && !b.spec.fn) errors.push(`${w}: 函数图像缺少 fn`);
        if (b.spec?.kind === "table" && !b.spec.table) errors.push(`${w}: 表格图像缺少 table`);
        break;
      case "list": b.items?.forEach((s, j) => checkMd(s, `${w}.items[${j}]`)); break;
      case "link":
        if (!content.kpById.has(b.kpId)) errors.push(`${w}: 链接到不存在的知识点 ${b.kpId}`);
        checkMd(b.text, w);
        break;
      case "formula":
        if (!content.formulaById.has(b.id)) errors.push(`${w}: 引用不存在的公式 ${b.id}`);
        break;
      default:
        errors.push(`${w}: 未知内容块类型 ${(b as { t: string }).t}`);
    }
  });
}

function checkKp(kp: KnowledgePoint): void {
  if (!kp.id || !kp.title || !kp.subtitle) errors.push(`知识点 ${kp.id}: 缺少标题或副标题`);
  if (!kp.objectives || kp.objectives.length < 3) errors.push(`知识点 ${kp.id}: 目标少于 3 条`);
  if (!kp.summary || kp.summary.length < 2) errors.push(`知识点 ${kp.id}: 小结少于 2 条`);
  if (!kp.formulaIds?.length) warnings.push(`知识点 ${kp.id}: 没有公式卡`);
  checkBlocks(kp.blocks, `kp:${kp.id}`);
  for (const s of kp.source) {
    if (s.kind === "course") {
      const f = join(root, "..", s.file);
      if (!existsSync(f)) errors.push(`知识点 ${kp.id}: 来源文件不存在 ${s.file}`);
      if (!s.pages) warnings.push(`知识点 ${kp.id}: 来源 ${s.file} 未标页码`);
    }
  }
}

function checkQuestion(q: Question): void {
  const w = `题目 ${q.id}@${q.version}`;
  if (!["choice", "fill", "steps", "calc"].includes(q.type)) errors.push(`${w}: 题型不合法`);
  if (!["basic", "standard", "advanced"].includes(q.difficulty)) errors.push(`${w}: 难度不合法`);
  if (!["concept", "step", "independent"].includes(q.role)) errors.push(`${w}: 角色不合法`);
  if (!content.kpById.has(q.kpId)) errors.push(`${w}: 知识点不存在`);
  if (![1, 2, 3].every((n) => typeof q.hints?.[n - 1] === "string" && q.hints[n - 1].trim())) {
    errors.push(`${w}: 必须有三条非空提示`);
  }
  q.hints?.forEach((h, i) => checkMd(h, `${w}.hint${i + 1}`));
  if (!q.solution?.length) errors.push(`${w}: 缺少完整解析`);
  checkBlocks(q.prompt, `${w}.prompt`);
  checkBlocks(q.solution, `${w}.solution`);
  if (q.type === "choice") {
    if (!q.options || q.options.length < 2) errors.push(`${w}: 选择题选项不足`);
    const ids = new Set(q.options?.map((o) => o.id));
    if (q.answer.kind !== "choice" || !ids.has(q.answer.value)) errors.push(`${w}: 选择题答案与选项不匹配`);
    q.options?.forEach((o, i) => checkMd(o.md, `${w}.option${i}`));
  }
  switch (q.answer.kind) {
    case "number":
      if (!Number.isFinite(q.answer.value)) errors.push(`${w}: 数值答案不合法`);
      if (q.answer.tolerance != null && q.answer.tolerance <= 0) errors.push(`${w}: 容差必须为正`);
      break;
    case "fraction":
      if (!Number.isInteger(q.answer.numerator) || !Number.isInteger(q.answer.denominator)) errors.push(`${w}: 分数答案必须为整数`);
      if (q.answer.denominator === 0) errors.push(`${w}: 分母为 0`);
      if (q.answer.denominator < 0) errors.push(`${w}: 分母应为正`);
      break;
    case "expression":
      if (!q.answer.accept?.length) errors.push(`${w}: 表达式答案缺少等价形式`);
      q.answer.accept?.forEach((a) => {
        try { expressionsEqual(a, a); } catch { errors.push(`${w}: 表达式无法解析：${a}`); }
      });
      break;
    case "steps": {
      const labels = q.answer.steps.map((s) => s.label);
      if (new Set(labels).size !== labels.length) errors.push(`${w}: 分步标签重复`);
      if (labels.length < 2) errors.push(`${w}: 分步题至少需要 2 步`);
      break;
    }
    case "choice": break;
    case "symbol":
      if (!["infinity", "-infinity", "dne", "zero"].includes(q.answer.value)) errors.push(`${w}: 符号答案不合法`);
      break;
  }
  if (q.source.kind === "course" && q.source.ref && !/\.pdf/.test(q.source.ref)) warnings.push(`${w}: 课件来源未写 PDF 文件名`);
}

const kpIds = new Set<string>();
for (const kp of content.kps) {
  if (kpIds.has(kp.id)) errors.push(`知识点编号重复：${kp.id}`);
  kpIds.add(kp.id);
  checkKp(kp);
}

const byKp = new Map<string, Question[]>();
for (const q of content.activeQuestion.values()) {
  checkQuestion(q);
  const arr = byKp.get(q.kpId) ?? [];
  arr.push(q);
  byKp.set(q.kpId, arr);
}

for (const kp of content.kps) {
  const qs = byKp.get(kp.id) ?? [];
  if (qs.length < 6) errors.push(`知识点 ${kp.id}: 题目少于 6 道（${qs.length}）`);
  else if (qs.length < 9) warnings.push(`知识点 ${kp.id}: 目前 ${qs.length} 道题，建议 9 道（每难度 3 道）`);
  for (const role of ["concept", "step", "independent"] as const) {
    const n = qs.filter((q) => q.role === role).length;
    if (n < 2) errors.push(`知识点 ${kp.id}: ${role} 类型少于 2 道`);
  }
  for (const d of ["basic", "standard", "advanced"] as const) {
    const level = qs.filter((q) => q.difficulty === d);
    if (!level.length) errors.push(`知识点 ${kp.id}: 缺少 ${d} 难度`);
    for (const role of ["concept", "step", "independent"] as const) {
      if (!level.some((q) => q.role === role)) errors.push(`知识点 ${kp.id}: ${d} 难度缺少 ${role} 类型`);
    }
  }
}

// 前置关系环检查
const state = new Map<string, number>();
function visit(id: string, stack: string[]): void {
  if (state.get(id) === 2) return;
  if (state.get(id) === 1) {
    errors.push(`前置关系存在环：${[...stack, id].join(" → ")}`);
    return;
  }
  state.set(id, 1);
  const kp = content.kpById.get(id);
  for (const p of kp?.prereqs ?? []) if (content.kpById.has(p)) visit(p, [...stack, id]);
  state.set(id, 2);
}
for (const kp of content.kps) visit(kp.id, []);

const unique = [...new Set(errors)];
const uniqueWarn = [...new Set(warnings)];
console.log(`知识点：${content.kps.length}，题目：${content.activeQuestion.size}，公式：${content.formulas.length}`);
console.log(`模块：${content.modules.map((m) => `${m.title}(${content.kps.filter((k) => k.module === m.id).length})`).join("，")}`);
if (uniqueWarn.length) {
  console.log(`\n警告 ${uniqueWarn.length} 条：`);
  for (const w of uniqueWarn.slice(0, 60)) console.log("  ⚠", w);
  if (uniqueWarn.length > 60) console.log(`  …另有 ${uniqueWarn.length - 60} 条`);
}
if (unique.length) {
  console.error(`\n错误 ${unique.length} 条：`);
  for (const e of unique) console.error("  ✗", e);
  process.exit(1);
}
console.log("\n内容校验通过。");
