import type { AnswerSpec, AnswerValue, GradeResult, Question } from "./types.ts";
import {
  ExprError,
  expressionsEqual,
  numericEquals,
  parseExpression,
  parseNumericAnswer,
  rationalValue,
} from "./expr.ts";

const SYMBOL_ALIASES: Record<string, string> = {
  "∞": "infinity",
  "+∞": "infinity",
  inf: "infinity",
  infinity: "infinity",
  "无穷": "infinity",
  "无穷大": "infinity",
  "正无穷": "infinity",
  "正无穷大": "infinity",
  "-∞": "-infinity",
  "-inf": "-infinity",
  "-infinity": "-infinity",
  "负无穷": "-infinity",
  "负无穷大": "-infinity",
  "不存在": "dne",
  "极限不存在": "dne",
  "无极限": "dne",
  dne: "dne",
  "0": "zero",
  "零": "zero",
};

function gradeValue(spec: AnswerSpec, raw: string): GradeResult {
  const value = (raw ?? "").trim();
  if (!value) return { correct: false, formatError: true, message: "请先填写答案。" };

  switch (spec.kind) {
    case "choice": {
      return { correct: value.toUpperCase() === spec.value.toUpperCase() };
    }
    case "number": {
      let r;
      try {
        r = parseNumericAnswer(value);
      } catch (e) {
        return { correct: false, formatError: true, message: (e as Error).message };
      }
      const actual = rationalValue(r);
      if (spec.tolerance == null) {
        let expected;
        try {
          expected = parseNumericAnswer(String(spec.value));
        } catch {
          return { correct: false, formatError: true, message: "题目答案配置有误。" };
        }
        return { correct: numericEquals(r, expected) };
      }
      if (spec.toleranceKind === "relative") {
        const base = Math.abs(spec.value) || 1;
        return { correct: Math.abs(actual - spec.value) <= spec.tolerance * base };
      }
      return { correct: Math.abs(actual - spec.value) <= spec.tolerance + 1e-12 };
    }
    case "fraction": {
      let r;
      try {
        r = parseNumericAnswer(value);
      } catch (e) {
        return { correct: false, formatError: true, message: (e as Error).message };
      }
      const expected = { n: spec.numerator, d: spec.denominator };
      return { correct: numericEquals(r, expected) };
    }
    case "symbol": {
      const normalized = SYMBOL_ALIASES[value.toLowerCase()] ?? SYMBOL_ALIASES[value] ?? null;
      if (!normalized) {
        return {
          correct: false,
          formatError: true,
          message: "无法识别。可填写：∞、-∞、不存在。",
        };
      }
      return { correct: normalized === spec.value };
    }
    case "expression": {
      try {
        parseExpression(value);
      } catch (e) {
        if (e instanceof ExprError) return { correct: false, formatError: true, message: e.message };
        return { correct: false, formatError: true, message: "表达式格式有误。" };
      }
      for (const form of spec.accept) {
        if (expressionsEqual(value, form)) return { correct: true };
      }
      return { correct: false };
    }
    case "steps": {
      const detail = spec.steps.map((s) => {
        const v = raw[s.label] ?? "";
        const r = gradeValue(s.answer, v);
        return { label: s.label, correct: r.correct, message: r.formatError ? r.message : undefined };
      });
      const formatError = detail.some((d) => d.message != null);
      return {
        correct: !formatError && detail.every((d) => d.correct),
        formatError,
        message: formatError ? "有步骤格式不正确，请检查后再提交。" : undefined,
        detail,
      };
    }
  }
}

export function gradeAnswer(spec: AnswerSpec, value: AnswerValue): GradeResult {
  if (spec.kind === "steps") {
    if (value.kind !== "steps") return { correct: false, formatError: true, message: "答案格式不符。" };
    const detail = spec.steps.map((s) => {
      const raw = value.values[s.label] ?? "";
      const r = gradeValue(s.answer, raw);
      return { label: s.label, correct: r.correct, message: r.formatError ? r.message : undefined };
    });
    const formatError = detail.some((d) => d.message != null);
    return {
      correct: !formatError && detail.every((d) => d.correct),
      formatError,
      message: formatError ? "有步骤格式不正确，请检查后再提交。" : undefined,
      detail,
    };
  }
  if (value.kind === "steps") return { correct: false, formatError: true, message: "答案格式不符。" };
  return gradeValue(spec, value.value);
}

/** 独立答对的唯一口径：首次有效提交、未用提示、未看解析、判分正确。 */
export function isIndependent(params: {
  correct: boolean;
  formatError: boolean;
  firstAttempt: boolean;
  hintLevel: number;
  solutionViewed: boolean;
}): boolean {
  return (
    params.correct &&
    !params.formatError &&
    params.firstAttempt &&
    params.hintLevel === 0 &&
    !params.solutionViewed
  );
}

/** 前端题目视图：绝不包含答案、解析与判分规则。 */
export function publicQuestion(q: Question) {
  return {
    id: q.id,
    version: q.version,
    kpId: q.kpId,
    difficulty: q.difficulty,
    type: q.type,
    prompt: q.prompt,
    options: q.options,
    formatHint: q.formatHint,
    role: q.role,
    stepLabels: q.answer.kind === "steps" ? q.answer.steps.map((s) => s.label) : undefined,
    steps: q.answer.kind === "steps" ? q.answer.steps.map((s) => ({ label: s.label })) : undefined,
    source: { kind: q.source.kind },
    tags: q.tags,
  };
}
