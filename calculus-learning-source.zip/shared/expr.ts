// 受限数学表达式解析与判等。不使用 eval。
// 支持：整数/小数/分数、单变量、+ - * / ^、括号、sqrt/sin/cos/tan/ln/log/exp/abs、pi/e。
// 判等策略：
//  1. 多项式与有理函数使用精确有理数系数展开，交叉相乘比较，严格等价；
//  2. 含超越函数的表达式只做结构规范化比较，并允许题目预先审核的等价形式。
// 不使用“随机点取值相等”作为判等依据。

export class ExprError extends Error {}

interface Rational {
  n: number; // 分子（含符号）
  d: number; // 分母，恒正
}

function gcd(a: number, b: number): number {
  a = Math.abs(a);
  b = Math.abs(b);
  while (b) {
    const t = a % b;
    a = b;
    b = t;
  }
  return a || 1;
}

function rat(n: number, d = 1): Rational {
  if (d === 0) throw new ExprError("分母不能为 0");
  if (!Number.isInteger(n) || !Number.isInteger(d)) throw new ExprError("内部错误：非整数有理数");
  if (d < 0) {
    n = -n;
    d = -d;
  }
  const g = gcd(n, d);
  return { n: n / g, d: d / g };
}

const R0 = rat(0);
const R1 = rat(1);

function rAdd(a: Rational, b: Rational): Rational {
  return rat(a.n * b.d + b.n * a.d, a.d * b.d);
}
function rSub(a: Rational, b: Rational): Rational {
  return rAdd(a, rat(-b.n, b.d));
}
function rMul(a: Rational, b: Rational): Rational {
  return rat(a.n * b.n, a.d * b.d);
}
function rDiv(a: Rational, b: Rational): Rational {
  if (b.n === 0) throw new ExprError("不能除以 0");
  return rat(a.n * b.d, a.d * b.n);
}
function rIsZero(a: Rational): boolean {
  return a.n === 0;
}
function rEq(a: Rational, b: Rational): boolean {
  return a.n === b.n && a.d === b.d;
}
export function rationalToString(a: Rational): string {
  if (a.d === 1) return String(a.n);
  return `${a.n}/${a.d}`;
}

export type Node =
  | { k: "num"; r: Rational }
  | { k: "var"; name: string }
  | { k: "add"; args: Node[] }
  | { k: "mul"; args: Node[] }
  | { k: "pow"; base: Node; exp: Node }
  | { k: "neg"; arg: Node }
  | { k: "fn"; name: string; arg: Node };

const FUNCS = new Set(["sqrt", "sin", "cos", "tan", "ln", "log", "exp", "abs"]);
const CONSTS = new Set(["pi", "e"]);

type Token =
  | { t: "num"; v: string }
  | { t: "id"; v: string }
  | { t: "op"; v: string }
  | { t: "lp" }
  | { t: "rp" };

export function normalizeInput(input: string): string {
  return input
    .replace(/[，,]/g, "")
    .replace(/[−–—]/g, "-")
    .replace(/[×·⋅]/g, "*")
    .replace(/÷/g, "/")
    .replace(/[（]/g, "(")
    .replace(/[）]/g, ")")
    .replace(/√/g, "sqrt")
    .replace(/π/g, "pi")
    .replace(/[＋]/g, "+")
    .replace(/[＝]/g, "=")
    .trim();
}

function tokenize(src: string): Token[] {
  const s = normalizeInput(src);
  const out: Token[] = [];
  let i = 0;
  while (i < s.length) {
    const c = s[i];
    if (/\s/.test(c)) {
      i++;
      continue;
    }
    if (/[0-9.]/.test(c)) {
      let j = i;
      while (j < s.length && /[0-9.]/.test(s[j])) j++;
      const v = s.slice(i, j);
      if ((v.match(/\./g) || []).length > 1) throw new ExprError("数字格式有误");
      out.push({ t: "num", v });
      i = j;
      continue;
    }
    if (/[a-zA-Z]/.test(c)) {
      let j = i;
      while (j < s.length && /[a-zA-Z]/.test(s[j])) j++;
      let word = s.slice(i, j).toLowerCase();
      // 允许 sinx 这类写法拆成 sin x
      while (word.length > 3 && !FUNCS.has(word) && !CONSTS.has(word)) {
        const prefix = [...FUNCS].find((f) => word.startsWith(f) && word.length > f.length);
        if (!prefix) break;
        out.push({ t: "id", v: prefix });
        word = word.slice(prefix.length);
      }
      out.push({ t: "id", v: word });
      i = j;
      continue;
    }
    if (c === "(") {
      out.push({ t: "lp" });
      i++;
      continue;
    }
    if (c === ")") {
      out.push({ t: "rp" });
      i++;
      continue;
    }
    if ("+-*/^".includes(c)) {
      out.push({ t: "op", v: c });
      i++;
      continue;
    }
    if (c === "=") throw new ExprError("请只填写表达式本身，不要写等号");
    if (/[一-鿿]/.test(c)) throw new ExprError("表达式中不能包含中文，请改用数字和字母");
    throw new ExprError(`无法识别的字符：${c}`);
  }
  return out;
}

class Parser {
  private toks: Token[];
  private pos = 0;
  constructor(toks: Token[]) {
    this.toks = toks;
  }
  peek(): Token | undefined {
    return this.toks[this.pos];
  }
  next(): Token {
    const t = this.toks[this.pos];
    if (!t) throw new ExprError("表达式不完整");
    this.pos++;
    return t;
  }
  parse(): Node {
    if (this.toks.length === 0) throw new ExprError("请填写答案");
    const n = this.parseAdd();
    if (this.pos < this.toks.length) throw new ExprError("表达式末尾有多余内容");
    return n;
  }
  parseAdd(): Node {
    let left = this.parseMul();
    for (;;) {
      const t = this.peek();
      if (t && t.t === "op" && (t.v === "+" || t.v === "-")) {
        this.next();
        const right = this.parseMul();
        left = { k: "add", args: [left, t.v === "-" ? { k: "neg", arg: right } : right] };
      } else break;
    }
    return left;
  }
  parseMul(): Node {
    let left = this.parseUnary();
    for (;;) {
      const t = this.peek();
      if (t && t.t === "op" && (t.v === "*" || t.v === "/")) {
        this.next();
        const right = this.parseUnary();
        left = t.v === "*" ? { k: "mul", args: [left, right] } : { k: "mul", args: [left, { k: "pow", base: right, exp: { k: "num", r: rat(-1) } }] };
      } else if (
        t &&
        (t.t === "num" ||
          t.t === "id" ||
          t.t === "lp")
      ) {
        // 隐式乘法：2x、3(x+1)、(x+1)(x-1)、x sin(x) 之外的常见写法
        const right = this.parseUnary();
        left = { k: "mul", args: [left, right] };
      } else break;
    }
    return left;
  }
  parseUnary(): Node {
    const t = this.peek();
    if (t && t.t === "op" && t.v === "-") {
      this.next();
      return { k: "neg", arg: this.parseUnary() };
    }
    if (t && t.t === "op" && t.v === "+") {
      this.next();
      return this.parseUnary();
    }
    return this.parsePow();
  }
  parsePow(): Node {
    const base = this.parseAtom();
    const t = this.peek();
    if (t && t.t === "op" && t.v === "^") {
      this.next();
      const exp = this.parseUnary(); // 右结合，且允许负指数
      return { k: "pow", base, exp };
    }
    return base;
  }
  parseAtom(): Node {
    const t = this.next();
    if (t.t === "num") {
      return parseNumericLiteral(t.v);
    }
    if (t.t === "lp") {
      const n = this.parseAdd();
      const close = this.next();
      if (close.t !== "rp") throw new ExprError("缺少右括号");
      return n;
    }
    if (t.t === "id") {
      if (FUNCS.has(t.v)) {
        // 函数必须跟括号；也接受 sqrt2 这类紧邻写法
        if (this.peek()?.t === "lp") {
          this.next();
          const arg = this.parseAdd();
          const close = this.next();
          if (close.t !== "rp") throw new ExprError("缺少右括号");
          return { k: "fn", name: t.v, arg };
        }
        const arg = this.parseUnary();
        return { k: "fn", name: t.v, arg };
      }
      if (t.v === "x") return { k: "var", name: "x" };
      if (t.v === "pi" || t.v === "e") return { k: "var", name: t.v };
      throw new ExprError(`未知符号：${t.v}（变量请用 x）`);
    }
    throw new ExprError("表达式格式有误");
  }
}

function parseNumericLiteral(v: string): Node {
  if (v === ".") throw new ExprError("数字格式有误");
  if (v.includes(".")) {
    const [a, b] = v.split(".");
    const frac = b || "";
    const den = 10 ** frac.length;
    return { k: "num", r: rat(Number(a || "0") * den + Number(frac || "0"), den) };
  }
  return { k: "num", r: rat(Number(v)) };
}

export function parseExpression(src: string): Node {
  return new Parser(tokenize(src)).parse();
}

// ---------- 精确多项式 / 有理函数 ----------

type Poly = Map<number, Rational>; // 指数 -> 系数

function pAdd(a: Poly, b: Poly): Poly {
  const m = new Map(a);
  for (const [e, c] of b) {
    const old = m.get(e) ?? R0;
    const v = rAdd(old, c);
    if (rIsZero(v)) m.delete(e);
    else m.set(e, v);
  }
  return m;
}
function pNeg(a: Poly): Poly {
  const m: Poly = new Map();
  for (const [e, c] of a) m.set(e, rat(-c.n, c.d));
  return m;
}
function pMul(a: Poly, b: Poly): Poly {
  const m: Poly = new Map();
  for (const [e1, c1] of a) {
    for (const [e2, c2] of b) {
      const e = e1 + e2;
      const v = rAdd(m.get(e) ?? R0, rMul(c1, c2));
      if (rIsZero(v)) m.delete(e);
      else m.set(e, v);
    }
  }
  return m;
}
function pPow(a: Poly, n: number): Poly {
  let out: Poly = new Map([[0, R1]]);
  for (let i = 0; i < n; i++) out = pMul(out, a);
  return out;
}
function pIsZero(a: Poly): boolean {
  return a.size === 0;
}
function pConst(a: Poly): Rational | null {
  if (a.size === 0) return R0;
  if (a.size === 1 && a.has(0)) return a.get(0)!;
  return null;
}
function polyToString(p: Poly): string {
  const entries = [...p.entries()].sort((x, y) => y[0] - x[0]);
  if (entries.length === 0) return "0";
  const parts: string[] = [];
  for (const [e, c] of entries) {
    const sign = c.n < 0 ? "-" : "+";
    const abs = rat(Math.abs(c.n), c.d);
    let coeff = "";
    if (e === 0) coeff = rationalToString(abs);
    else if (rEq(abs, R1)) coeff = "";
    else coeff = rationalToString(abs);
    const varPart = e === 0 ? "" : e === 1 ? "x" : `x^${e}`;
    parts.push(`${sign}${coeff}${varPart}`);
  }
  let s = parts.join("");
  if (s.startsWith("+")) s = s.slice(1);
  return s;
}

interface RatFn {
  num: Poly;
  den: Poly;
}

function ratFn(num: Poly, den: Poly = new Map([[0, R1]])): RatFn {
  if (pIsZero(den)) throw new ExprError("分母不能为 0");
  return { num, den };
}

function toRatFn(n: Node): RatFn | null {
  switch (n.k) {
    case "num":
      return ratFn(new Map([[0, n.r]]));
    case "var":
      if (n.name === "x") return ratFn(new Map([[1, R1]]));
      return null;
    case "neg": {
      const a = toRatFn(n.arg);
      return a ? ratFn(pNeg(a.num), a.den) : null;
    }
    case "add": {
      let acc = ratFn(new Map());
      for (const arg of n.args) {
        const a = toRatFn(arg);
        if (!a) return null;
        // acc.num/acc.den + a.num/a.den
        const num = pAdd(pMul(acc.num, a.den), pMul(a.num, acc.den));
        const den = pMul(acc.den, a.den);
        acc = ratFn(num, den);
      }
      return acc;
    }
    case "mul": {
      let acc = ratFn(new Map([[0, R1]]));
      for (const arg of n.args) {
        const a = toRatFn(arg);
        if (!a) return null;
        acc = ratFn(pMul(acc.num, a.num), pMul(acc.den, a.den));
      }
      return acc;
    }
    case "pow": {
      const a = toRatFn(n.base);
      const expConst = toRatFn(n.exp);
      if (!a || !expConst) return null;
      const numC = pConst(expConst.num);
      const denC = pConst(expConst.den);
      if (!numC || !denC || rIsZero(denC)) return null;
      const kRat = rDiv(numC, denC);
      if (kRat.d !== 1) return null;
      const k = kRat.n;
      if (k >= 0) return ratFn(pPow(a.num, k), pPow(a.den, k));
      return ratFn(pPow(a.den, -k), pPow(a.num, -k));
    }
    case "fn":
      return null;
  }
}

function exprStructure(n: Node): string {
  switch (n.k) {
    case "num":
      return rationalToString(n.r);
    case "var":
      return n.name;
    case "neg": {
      const inner = exprStructure(n.arg);
      return inner.startsWith("-") ? inner.slice(1) : `-${inner}`;
    }
    case "add": {
      const flat: Node[] = [];
      for (const a of n.args) {
        if (a.k === "add") flat.push(...a.args);
        else flat.push(a);
      }
      const parts = flat.map(exprStructure).sort();
      return parts.join("+").replace(/\+-/g, "-");
    }
    case "mul": {
      const flat: Node[] = [];
      for (const a of n.args) {
        if (a.k === "mul") flat.push(...a.args);
        else flat.push(a);
      }
      const parts = flat.map(exprStructure).sort();
      return parts.join("*");
    }
    case "pow":
      return `(${exprStructure(n.base)})^(${exprStructure(n.exp)})`;
    case "fn":
      return `${n.name}(${exprStructure(n.arg)})`;
  }
}

export function canonicalForm(src: string): { kind: "rational" | "structural"; form: string } {
  const node = parseExpression(src);
  const rf = toRatFn(node);
  if (rf) {
    // 约去公因子仅做到“交叉相乘比较”层面，这里输出 num/den
    return { kind: "rational", form: `${polyToString(rf.num)}/${polyToString(rf.den)}` };
  }
  return { kind: "structural", form: exprStructure(node) };
}

/** 严格判等：有理式交叉相乘；含超越函数时比较结构规范化结果。 */
export function expressionsEqual(a: string, b: string): boolean {
  let na: Node;
  let nb: Node;
  try {
    na = parseExpression(a);
    nb = parseExpression(b);
  } catch {
    return false;
  }
  const ra = toRatFn(na);
  const rb = toRatFn(nb);
  if (ra && rb) {
    // a.num/a.den == b.num/b.den  <=> a.num*b.den == b.num*a.den
    const left = pMul(ra.num, rb.den);
    const right = pMul(rb.num, ra.den);
    return polyToString(pAdd(left, pNeg(right))) === "0";
  }
  return exprStructure(na) === exprStructure(nb);
}

export function evaluateExpression(src: string, x: number): number {
  const n = parseExpression(src);
  return evalNode(n, x);
}

function evalNode(n: Node, x: number): number {
  switch (n.k) {
    case "num":
      return n.r.n / n.r.d;
    case "var":
      if (n.name === "x") return x;
      if (n.name === "pi") return Math.PI;
      if (n.name === "e") return Math.E;
      throw new ExprError("未知符号");
    case "add":
      return n.args.reduce((s, a) => s + evalNode(a, x), 0);
    case "mul":
      return n.args.reduce((p, a) => p * evalNode(a, x), 1);
    case "neg":
      return -evalNode(n.arg, x);
    case "pow":
      return Math.pow(evalNode(n.base, x), evalNode(n.exp, x));
    case "fn": {
      const v = evalNode(n.arg, x);
      switch (n.name) {
        case "sqrt":
          if (v < 0) return NaN;
          return Math.sqrt(v);
        case "sin":
          return Math.sin(v);
        case "cos":
          return Math.cos(v);
        case "tan":
          return Math.tan(v);
        case "ln":
          return v > 0 ? Math.log(v) : NaN;
        case "log":
          return v > 0 ? Math.log10(v) : NaN;
        case "exp":
          return Math.exp(v);
        case "abs":
          return Math.abs(v);
      }
      throw new ExprError("未知函数");
    }
  }
}

/** 解析用户填写的数值：支持整数、有限小数、分数（a/b）。 */
export function parseNumericAnswer(src: string): Rational {
  const s = normalizeInput(src).replace(/\s/g, "");
  if (!s) throw new ExprError("请填写答案");
  const m = s.match(/^([+-]?\d+(?:\.\d+)?)(?:\/([+-]?\d+(?:\.\d+)?))?$/);
  if (!m) throw new ExprError("请填写一个数，例如 2、0.5 或 1/2");
  const toRat = (v: string): Rational => {
    if (v.includes(".")) {
      const [a, b] = v.split(".");
      const den = 10 ** b.length;
      return rat(Number(a) * den + Number(b) * Math.sign(Number(a) || 1), den);
    }
    return rat(Number(v));
  };
  const n = toRat(m[1]);
  if (m[2] === undefined) return n;
  const d = toRat(m[2]);
  if (rIsZero(d)) throw new ExprError("分母不能为 0");
  return rDiv(n, d);
}

export function numericEquals(a: Rational, b: Rational): boolean {
  return rEq(a, b);
}
export function rationalValue(a: Rational): number {
  return a.n / a.d;
}
