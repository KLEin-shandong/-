// 全站共享类型。仅使用可擦除的 TypeScript 语法，便于浏览器端直接剥离类型。

export type ModuleId = "func" | "limits" | "derivatives";
export type Difficulty = "basic" | "standard" | "advanced";
export type MasteryState =
  | "not_started"
  | "learning"
  | "needs_review"
  | "pending_verify"
  | "mastered";

export type SourceKind = "course" | "supplement" | "original";

export interface SourceRef {
  /** 原始课件文件名，例如 1-2.pdf；补充内容写 supplement */
  file: string;
  /** PDF 页码（从 1 开始）；补充内容可省略 */
  pages?: string;
  kind: SourceKind;
  /** 对应讲义或笔记，便于回查 */
  note?: string;
}

export interface FigureSpec {
  kind: "graph" | "table" | "numberline" | "piecewise" | "none";
  /** 函数图像：用受限表达式写在 fn 中；窗口与标注由服务端/前端共同理解 */
  fn?: string;
  xMin?: number;
  xMax?: number;
  yMin?: number;
  yMax?: number;
  points?: Array<{ x: number; y: number; label?: string; open?: boolean }>;
  lines?: Array<{ x?: number; y?: number; label?: string; dashed?: boolean }>;
  table?: { head: string[]; rows: string[][] };
  segments?: Array<{ from: number; to: number; fn: string; openLeft?: boolean; openRight?: boolean; label?: string }>;
  caption?: string;
}

export type Block =
  | { t: "p"; md: string }
  | { t: "h"; text: string }
  | { t: "math"; tex: string }
  | { t: "example"; title: string; steps: string[]; answer?: string }
  | { t: "pitfall"; title?: string; md: string }
  | { t: "callout"; tone?: "info" | "warn" | "good"; title?: string; md: string }
  | { t: "table"; head: string[]; rows: string[][]; caption?: string }
  | { t: "figure"; spec: FigureSpec }
  | { t: "list"; items: string[]; ordered?: boolean }
  | { t: "link"; kpId: string; text: string }
  | { t: "formula"; id: string };

export interface FormulaCard {
  id: string;
  name: string;
  tex: string;
  conditions: string;
  example: string;
  misuse: string;
  kpIds: string[];
  version: number;
}

export interface KnowledgePoint {
  id: string;
  module: ModuleId;
  order: number;
  title: string;
  subtitle: string;
  version: number;
  /** 预计单节学习分钟数 */
  minutes: number;
  prereqs: string[];
  source: SourceRef[];
  objectives: string[];
  blocks: Block[];
  summary: string[];
  formulaIds: string[];
  /** 基础补救入口的优先级，数字越小越优先；没有则 99 */
  remediationPriority?: number;
}

export interface ChoiceOption {
  id: string;
  md: string;
}

export interface NumberAnswer {
  kind: "number";
  value: number;
  /** 题目明确要求的误差；不填表示要求精确值 */
  tolerance?: number;
  toleranceKind?: "absolute" | "relative";
  unit?: string;
}

export interface FractionAnswer {
  kind: "fraction";
  numerator: number;
  denominator: number;
}

export interface ChoiceAnswer {
  kind: "choice";
  value: string;
}

export interface SymbolAnswer {
  kind: "symbol";
  /** 专用选项：无穷大、负无穷大、不存在 */
  value: "infinity" | "-infinity" | "dne" | "zero";
}

export interface ExpressionAnswer {
  kind: "expression";
  /** 审核过的等价形式（规范字符串） */
  accept: string[];
  /** 变量名，默认 x */
  variable?: string;
  /** 仅用于服务端自检，不发给前端 */
  verifyPoints?: Array<{ x: number; y: number }>;
}

export interface StepAnswer {
  label: string;
  answer: ChoiceAnswer | NumberAnswer | FractionAnswer | SymbolAnswer | ExpressionAnswer;
}

export interface StepsAnswer {
  kind: "steps";
  steps: StepAnswer[];
}

export type AnswerSpec =
  | ChoiceAnswer
  | NumberAnswer
  | FractionAnswer
  | SymbolAnswer
  | ExpressionAnswer
  | StepsAnswer;

export interface Question {
  id: string;
  version: number;
  kpId: string;
  difficulty: Difficulty;
  /** choice 单选；fill 单空；steps 分步填空；calc 计算（单空，但按计算题展示） */
  type: "choice" | "fill" | "steps" | "calc";
  prompt: Block[];
  options?: ChoiceOption[];
  answer: AnswerSpec;
  hints: [string, string, string];
  solution: Block[];
  /** 作答格式说明，例如“填分数，如 1/2” */
  formatHint?: string;
  source: { kind: SourceKind; ref: string };
  /** 概念/方法辨认、分步、独立作答 */
  role: "concept" | "step" | "independent";
  tags?: string[];
}

export type AnswerValue =
  | { kind: "choice"; value: string }
  | { kind: "number"; value: string }
  | { kind: "fraction"; value: string }
  | { kind: "symbol"; value: string }
  | { kind: "expression"; value: string }
  | { kind: "steps"; values: Record<string, string> };

export interface GradeResult {
  correct: boolean;
  /** 格式错误不计入答错统计 */
  formatError: boolean;
  message?: string;
  detail?: Array<{ label: string; correct: boolean; message?: string }>;
}

export interface HintPayload {
  level: 1 | 2 | 3;
  content: string;
}

export interface SubmissionRecord {
  id: string;
  clientId: string;
  userId: string;
  sessionId: string;
  questionId: string;
  questionVersion: number;
  answer: AnswerValue;
  result: GradeResult;
  correct: boolean;
  independent: boolean;
  hintLevel: number;
  solutionViewed: boolean;
  firstAttempt: boolean;
  createdAt: string;
}

export interface SessionState {
  id: string;
  userId: string;
  kpId: string;
  status: "active" | "paused" | "completed";
  questionIds: string[];
  position: number;
  drafts: Record<string, AnswerValue | null>;
  revision: number;
  createdAt: string;
  updatedAt: string;
}

export interface ReviewItem {
  id: string;
  userId: string;
  targetKind: "kp" | "formula";
  targetId: string;
  stage: number;
  dueDate: string;
  lastResult?: "good" | "fuzzy" | "bad";
  createdAt: string;
  updatedAt: string;
}

export interface UserSettings {
  classroomKpId: string;
  defaultMinutes: number;
  timezone: string;
}
