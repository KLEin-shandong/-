import type { Difficulty, MasteryState } from "./types.ts";

export const TZ = "Asia/Shanghai";
export const REVIEW_INTERVALS = [1, 3, 7, 14] as const;
export const DIFFICULTIES: Difficulty[] = ["basic", "standard", "advanced"];

/** 返回某时刻在上海时区的自然日，格式 YYYY-MM-DD。 */
export function shanghaiDate(at: Date | string = new Date()): string {
  const d = typeof at === "string" ? new Date(at) : at;
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: TZ,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(d);
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? "00";
  return `${get("year")}-${get("month")}-${get("day")}`;
}

export function addDays(date: string, days: number): string {
  const [y, m, d] = date.split("-").map(Number);
  const base = new Date(Date.UTC(y, m - 1, d));
  base.setUTCDate(base.getUTCDate() + days);
  return base.toISOString().slice(0, 10);
}

export function daysBetween(a: string, b: string): number {
  const toUtc = (s: string) => {
    const [y, m, d] = s.split("-").map(Number);
    return Date.UTC(y, m - 1, d);
  };
  return Math.round((toUtc(b) - toUtc(a)) / 86400000);
}

export interface AttemptFact {
  questionId: string;
  kpId: string;
  correct: boolean;
  formatError: boolean;
  independent: boolean;
  firstAttempt: boolean;
  hintLevel: number;
  solutionViewed: boolean;
  createdAt: string;
}

/** 从首次有效提交中取“最近 n 道不同题”。 */
export function recentDistinctFirstAttempts(attempts: AttemptFact[], n: number): AttemptFact[] {
  const seen = new Set<string>();
  const picked: AttemptFact[] = [];
  for (let i = attempts.length - 1; i >= 0; i--) {
    const a = attempts[i];
    if (!a.firstAttempt || a.formatError) continue;
    if (seen.has(a.questionId)) continue;
    seen.add(a.questionId);
    picked.push(a);
    if (picked.length >= n) break;
  }
  return picked.reverse();
}

export function evaluateMastery(
  attempts: AttemptFact[],
  current: MasteryState,
  pendingSince: string | null,
  today: string,
): { state: MasteryState; pendingSince: string | null; justMastered: boolean } {
  const recent = recentDistinctFirstAttempts(attempts, 5);
  const independentCorrect = recent.filter((a) => a.independent).length;
  const enough = recent.length >= 5 && independentCorrect >= 4;

  // 已掌握后答错同知识点复习题 -> 需要巩固
  if (current === "mastered") {
    const last = recent[recent.length - 1];
    if (last && !last.correct && !last.formatError) {
      return { state: "needs_review", pendingSince: null, justMastered: false };
    }
    return { state: "mastered", pendingSince: null, justMastered: false };
  }

  if (enough) {
    // 最近一次独立答对发生在待验证之后的下一个自然日 -> 已掌握
    if (pendingSince && daysBetween(pendingSince, today) >= 1) {
      const latest = recent[recent.length - 1];
      if (latest?.independent && shanghaiDate(latest.createdAt) === today) {
        return { state: "mastered", pendingSince: null, justMastered: true };
      }
    }
    return {
      state: "pending_verify",
      pendingSince: pendingSince ?? today,
      justMastered: false,
    };
  }

  if (current === "needs_review" || current === "learning" || current === "pending_verify") {
    const last = recent[recent.length - 1];
    if (last && !last.correct) return { state: "needs_review", pendingSince: null, justMastered: false };
    return { state: "learning", pendingSince: null, justMastered: false };
  }

  return { state: current, pendingSince, justMastered: false };
}

export type DifficultyMove = "up" | "down" | "hold";

export function evaluateDifficulty(
  attempts: AttemptFact[],
  current: Difficulty,
): { level: Difficulty; move: DifficultyMove; reason: string } {
  const recent3 = recentDistinctFirstAttempts(attempts, 3);
  if (recent3.length === 3 && recent3.every((a) => a.independent)) {
    const idx = DIFFICULTIES.indexOf(current);
    if (idx < DIFFICULTIES.length - 1) {
      return { level: DIFFICULTIES[idx + 1], move: "up", reason: "最近 3 道不同题独立答对" };
    }
    return { level: current, move: "hold", reason: "已在最高难度" };
  }

  const recent2 = recentDistinctFirstAttempts(attempts, 2);
  if (recent2.length === 2) {
    const bothWrong = recent2.every((a) => !a.correct && !a.formatError);
    const bothSolved = recent2.every((a) => a.solutionViewed);
    if (bothWrong || bothSolved) {
      const idx = DIFFICULTIES.indexOf(current);
      if (idx > 0) {
        return {
          level: DIFFICULTIES[idx - 1],
          move: "down",
          reason: bothWrong ? "连续 2 道首次作答错误" : "连续 2 题查看完整解析后才作答",
        };
      }
      return { level: current, move: "hold", reason: "基础级仍连续出错，建议补前置基础" };
    }
  }
  return { level: current, move: "hold", reason: "保持当前难度" };
}

export interface ReviewOutcome {
  stage: number;
  dueDate: string;
  lastResult: "good" | "fuzzy" | "bad";
}

/** 复习间隔：1、3、7、14 天；答错回第 1 天；模糊维持阶段并次日再复习。 */
export function nextReview(
  stage: number,
  result: "good" | "fuzzy" | "bad",
  today = shanghaiDate(),
): ReviewOutcome {
  const s = Math.max(0, Math.min(stage, REVIEW_INTERVALS.length - 1));
  if (result === "bad") {
    return { stage: 0, dueDate: addDays(today, REVIEW_INTERVALS[0]), lastResult: result };
  }
  if (result === "fuzzy") {
    return { stage: s, dueDate: addDays(today, 1), lastResult: result };
  }
  const nextStage = Math.min(s + 1, REVIEW_INTERVALS.length - 1);
  return {
    stage: nextStage,
    dueDate: addDays(today, REVIEW_INTERVALS[nextStage]),
    lastResult: result,
  };
}

export function dueLabel(dueDate: string, today = shanghaiDate()): string {
  const diff = daysBetween(today, dueDate);
  if (diff < 0) return `逾期 ${-diff} 天`;
  if (diff === 0) return "今天";
  if (diff === 1) return "明天";
  return `${diff} 天后`;
}
