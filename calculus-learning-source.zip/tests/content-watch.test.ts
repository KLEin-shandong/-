import test from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, mkdirSync, rmSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { loadContent, watchContent, type ContentBundle, type ContentWatcher } from "../server/content.ts";

function writeFixture(dir: string, title: string): { kpFile: string } {
  mkdirSync(join(dir, "knowledge-points"), { recursive: true });
  mkdirSync(join(dir, "questions"), { recursive: true });
  const kpFile = join(dir, "knowledge-points", "kp.json");
  writeFileSync(
    kpFile,
    JSON.stringify({
      id: "k1",
      version: 1,
      module: "func",
      order: 1,
      title,
      subtitle: "",
      minutes: 5,
      objectives: [],
      prereqs: [],
      blocks: [],
      summary: [],
      source: [],
      formulaIds: [],
    }),
  );
  writeFileSync(
    join(dir, "questions", "q.json"),
    JSON.stringify(
      ["concept", "concept", "step", "step", "independent", "independent"].map((role, i) => ({
        id: `q${i}`,
        version: 1,
        kpId: "k1",
        role,
        difficulty: "basic",
        tags: [],
      })),
    ),
  );
  writeFileSync(join(dir, "formulas.json"), "[]");
  return { kpFile };
}

async function waitFor(predicate: () => boolean, timeoutMs = 3000): Promise<void> {
  const started = Date.now();
  while (!predicate()) {
    if (Date.now() - started > timeoutMs) throw new Error("等待内容监听回调超时");
    await new Promise((resolve) => setTimeout(resolve, 25));
  }
}

test("内容文件保存后热更新，即使 version 未变也会更新内容版本", async (t) => {
  const dir = mkdtempSync(join(tmpdir(), "calc-content-"));
  let watcher: ContentWatcher | null = null;
  t.after(() => {
    watcher?.close();
    rmSync(dir, { recursive: true, force: true });
  });

  const { kpFile } = writeFixture(dir, "旧标题");
  const live = loadContent(dir);
  const before = live.version;
  const reloads: ContentBundle[] = [];
  const errors: Error[] = [];
  watcher = watchContent(live, {
    dir,
    debounceMs: 30,
    onReload(next, error) {
      if (next) reloads.push(next);
      if (error) errors.push(error);
    },
  });

  writeFixture(dir, "新标题");
  await waitFor(() => reloads.length > 0 || errors.length > 0);

  assert.deepEqual(errors, []);
  assert.equal(live.kpById.get("k1")?.title, "新标题");
  assert.notEqual(live.version, before);
  assert.equal((live.kpById.get("k1") as { version?: number } | undefined)?.version, 1);
  assert.equal(reloads[0].version, live.version);
});

test("新内容 JSON 损坏时保留旧内容", async (t) => {
  const dir = mkdtempSync(join(tmpdir(), "calc-content-"));
  let watcher: ContentWatcher | null = null;
  t.after(() => {
    watcher?.close();
    rmSync(dir, { recursive: true, force: true });
  });

  const { kpFile } = writeFixture(dir, "稳定标题");
  const live = loadContent(dir);
  const before = live.version;
  const errors: Error[] = [];
  watcher = watchContent(live, {
    dir,
    debounceMs: 30,
    onReload(_next, error) {
      if (error) errors.push(error);
    },
  });

  writeFileSync(kpFile, "{ 这不是合法 JSON");
  await waitFor(() => errors.length > 0);

  assert.match(errors[0].message, /保留旧内容/);
  assert.equal(live.kpById.get("k1")?.title, "稳定标题");
  assert.equal(live.version, before);
});
