import test from "node:test";
import assert from "node:assert/strict";
import {
  addDays,
  daysBetween,
  evaluateDifficulty,
  evaluateMastery,
  nextReview,
  recentDistinctFirstAttempts,
  shanghaiDate,
  type AttemptFact,
} from "../shared/learning.ts";

function attempt(over: Partial<AttemptFact>): AttemptFact {
  return {
    questionId: "q1",
    kpId: "kp",
    correct: true,
    formatError: false,
    independent: true,
    firstAttempt: true,
    hintLevel: 0,
    solutionViewed: false,
    createdAt: "2026-11-07T02:00:00.000Z",
    ...over,
  };
}

test("上海时区自然日", () => {
  assert.equal(shanghaiDate("2026-11-07T15:59:00.000Z"), "2026-11-07");
  assert.equal(shanghaiDate("2026-11-07T16:00:00.000Z"), "2026-11-08");
  assert.equal(addDays("2026-11-07", 1), "2026-11-08");
  assert.equal(addDays("2026-12-31", 1), "2027-01-01");
  assert.equal(daysBetween("2026-11-07", "2026-11-10"), 3);
});

test("难度：连续 3 道不同题独立答对升一级", () => {
  const a = [attempt({ questionId: "a" }), attempt({ questionId: "b" }), attempt({ questionId: "c" })];
  assert.equal(evaluateDifficulty(a, "basic").level, "standard");
  assert.equal(evaluateDifficulty(a, "standard").level, "advanced");
  assert.equal(evaluateDifficulty(a, "advanced").move, "hold");
});

test("难度：连续 2 道首次错误降一级，基础级保持", () => {
  const a = [
    attempt({ questionId: "a", correct: false, independent: false }),
    attempt({ questionId: "b", correct: false, independent: false }),
  ];
  assert.equal(evaluateDifficulty(a, "standard").level, "basic");
  assert.equal(evaluateDifficulty(a, "advanced").level, "standard");
  assert.equal(evaluateDifficulty(a, "basic").move, "hold");
});

test("难度：连续 2 题看解析后作答降一级", () => {
  const a = [
    attempt({ questionId: "a", correct: true, independent: false, solutionViewed: true }),
    attempt({ questionId: "b", correct: true, independent: false, solutionViewed: true }),
  ];
  assert.equal(evaluateDifficulty(a, "advanced").level, "standard");
});

test("同题反复作答不能刷成 3 道不同题", () => {
  const a = [attempt({ questionId: "a" }), attempt({ questionId: "a" }), attempt({ questionId: "a" })];
  assert.equal(recentDistinctFirstAttempts(a, 3).length, 1);
  assert.equal(evaluateDifficulty(a, "basic").level, "basic");
});

test("掌握：5 道不同题中 4 道独立答对 -> 待复习验证", () => {
  const a = [
    attempt({ questionId: "a" }),
    attempt({ questionId: "b" }),
    attempt({ questionId: "c" }),
    attempt({ questionId: "d" }),
    attempt({ questionId: "e", correct: false, independent: false }),
  ];
  const r = evaluateMastery(a, "learning", null, "2026-11-07");
  assert.equal(r.state, "pending_verify");
  assert.equal(r.pendingSince, "2026-11-07");
});

test("掌握：次日独立答对复习题才转为已掌握", () => {
  const a = [
    attempt({ questionId: "a" }),
    attempt({ questionId: "b" }),
    attempt({ questionId: "c" }),
    attempt({ questionId: "d" }),
    attempt({ questionId: "e" }),
  ];
  const sameDay = evaluateMastery(a, "pending_verify", "2026-11-07", "2026-11-07");
  assert.equal(sameDay.state, "pending_verify");
  const nextDayAttempts = [
    ...a,
    attempt({ questionId: "f", createdAt: "2026-11-08T02:00:00.000Z" }),
  ];
  const nextDay = evaluateMastery(nextDayAttempts, "pending_verify", "2026-11-07", "2026-11-08");
  assert.equal(nextDay.state, "mastered");
});

test("掌握：已掌握后复习答错 -> 需要巩固", () => {
  const a = [
    attempt({ questionId: "a" }),
    attempt({ questionId: "b" }),
    attempt({ questionId: "c" }),
    attempt({ questionId: "d" }),
    attempt({ questionId: "e", correct: false, independent: false }),
  ];
  const r = evaluateMastery(a, "mastered", null, "2026-11-10");
  assert.equal(r.state, "needs_review");
});

test("复习间隔：1、3、7、14 天与回退", () => {
  assert.deepEqual(nextReview(0, "good", "2026-11-07"), { stage: 1, dueDate: "2026-11-10", lastResult: "good" });
  assert.deepEqual(nextReview(1, "good", "2026-11-07"), { stage: 2, dueDate: "2026-11-14", lastResult: "good" });
  assert.deepEqual(nextReview(2, "good", "2026-11-07"), { stage: 3, dueDate: "2026-11-21", lastResult: "good" });
  assert.deepEqual(nextReview(3, "good", "2026-11-07"), { stage: 3, dueDate: "2026-11-21", lastResult: "good" });
  assert.deepEqual(nextReview(2, "bad", "2026-11-07"), { stage: 0, dueDate: "2026-11-08", lastResult: "bad" });
  assert.deepEqual(nextReview(2, "fuzzy", "2026-11-07"), { stage: 2, dueDate: "2026-11-08", lastResult: "fuzzy" });
});
