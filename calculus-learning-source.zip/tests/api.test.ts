import test from "node:test";
import assert from "node:assert/strict";
import { startApp, TestClient, register, correctAnswer, wrongAnswer, newClientId, type TestApp } from "./helpers.ts";

let app: TestApp;

test("API 集成测试", async (t) => {
  app = await startApp();
  t.after(async () => { await app.close(); });

  await t.test("未登录被拒绝，注册后可读取首页", async () => {
    const anon = new TestClient(app.url);
    assert.equal((await anon.get("/api/bootstrap")).status, 401);
    const c = new TestClient(app.url);
    await register(c, "alice");
    const boot = await c.get("/api/bootstrap");
    assert.equal(boot.status, 200);
    assert.equal(boot.data.user.username, "alice");
    assert.equal(boot.data.settings.defaultMinutes, 90);
    assert.ok(Array.isArray(boot.data.kps));
    const dup = new TestClient(app.url);
    assert.equal((await dup.post("/api/auth/register", { username: "ALICE", password: "password123" })).status, 409);
  });

  await t.test("学习会话、提示、解析与独立答对口径", async () => {
    const c = new TestClient(app.url);
    await register(c, "learner1");
    const created = await c.post("/api/sessions", { kpId: "limit-approach" });
    assert.equal(created.status, 201);
    assert.equal(created.data.questions.length, 6);
    const sid = created.data.session.id;
    const q = created.data.questions[0];
    const qFull = app.content.activeQuestion.get(q.id)!;

    const hint = await c.post(`/api/sessions/${sid}/hint`, { questionId: q.id, level: 1 });
    assert.equal(hint.status, 200);
    assert.equal(hint.data.source, "builtin");
    assert.ok(hint.data.content.length > 0);
    assert.equal((await c.post(`/api/sessions/${sid}/hint`, { questionId: q.id, level: 9 })).status, 400);

    const sub = await c.post("/api/submissions", {
      clientId: newClientId(),
      sessionId: sid,
      questionId: q.id,
      questionVersion: q.version,
      answer: correctAnswer(qFull),
    });
    assert.equal(sub.status, 200);
    assert.equal(sub.data.correct, true);
    assert.equal(sub.data.independent, false, "用了提示不应算独立答对");
    assert.equal(sub.data.firstAttempt, true);

    const created2 = await c.post("/api/sessions", { kpId: "limit-approach", forceNew: true });
    const q2 = created2.data.questions[0];
    const q2Full = app.content.activeQuestion.get(q2.id)!;
    await c.post(`/api/sessions/${created2.data.session.id}/solution`, { questionId: q2.id });
    const sub2 = await c.post("/api/submissions", {
      clientId: newClientId(),
      sessionId: created2.data.session.id,
      questionId: q2.id,
      questionVersion: q2.version,
      answer: correctAnswer(q2Full),
    });
    assert.equal(sub2.data.correct, true);
    assert.equal(sub2.data.independent, false, "看了完整解析不应算独立答对");
  });

  await t.test("同一提交编号重试不重复计分", async () => {
    const c = new TestClient(app.url);
    await register(c, "idem");
    const s = await c.post("/api/sessions", { kpId: "limit-approach" });
    const q = s.data.questions[0];
    const body = {
      clientId: newClientId(),
      sessionId: s.data.session.id,
      questionId: q.id,
      questionVersion: q.version,
      answer: correctAnswer(app.content.activeQuestion.get(q.id)!),
    };
    const first = await c.post("/api/submissions", body);
    const second = await c.post("/api/submissions", body);
    assert.equal(first.data.correct, true);
    assert.equal(second.data.replayed, true);
    const exp = await c.get("/api/export");
    assert.equal(exp.data.submissions.length, 1);
    assert.ok(exp.data.submissions[0].question_snapshot.includes(q.id));
  });

  await t.test("格式错误不计入答错，也不产生首次有效提交", async () => {
    const c = new TestClient(app.url);
    await register(c, "format");
    const s = await c.post("/api/sessions", { kpId: "limit-approach" });
    const fill = s.data.questions.find((q: any) => q.type !== "choice");
    if (!fill) {
      assert.ok(true);
      return;
    }
    const res = await c.post("/api/submissions", {
      clientId: newClientId(),
      sessionId: s.data.session.id,
      questionId: fill.id,
      questionVersion: fill.version,
      answer: { kind: "number", value: "这不是数" },
    });
    assert.equal(res.data.formatError, true);
    assert.equal(res.data.correct, false);
    const exp = await c.get("/api/export");
    assert.equal(exp.data.submissions[0].first_attempt, 0);
  });

  await t.test("会话修订号冲突返回 409，且不覆盖云端", async () => {
    const c = new TestClient(app.url);
    await register(c, "conflict");
    const s = await c.post("/api/sessions", { kpId: "limit-approach" });
    const sid = s.data.session.id;
    const r1 = await c.post(`/api/sessions/${sid}/state`, { revision: 1, position: 1, drafts: {} });
    assert.equal(r1.status, 200);
    assert.equal(r1.data.session.revision, 2);
    const stale = await c.post(`/api/sessions/${sid}/state`, { revision: 1, position: 3, drafts: {} });
    assert.equal(stale.status, 409);
    assert.equal(stale.data.error.code, "REVISION_CONFLICT");
    assert.equal(stale.data.session.session.position, 1);
    const fork = await c.post(`/api/sessions/${sid}/fork`, { position: 3, drafts: {} });
    assert.equal(fork.status, 201);
    assert.notEqual(fork.data.session.id, sid);
    assert.equal(fork.data.session.position, 3);
  });

  await t.test("用户之间不能访问彼此会话", async () => {
    const a = new TestClient(app.url);
    const b = new TestClient(app.url);
    await register(a, "owner");
    await register(b, "other");
    const s = await a.post("/api/sessions", { kpId: "limit-approach" });
    const res = await b.get(`/api/sessions/${s.data.session.id}`);
    assert.equal(res.status, 404);
  });

  await t.test("连续独立答对提升难度，连续错误降低难度；5 题后待复习验证", async () => {
    const c = new TestClient(app.url);
    await register(c, "difficulty");
    const s = await c.post("/api/sessions", { kpId: "limit-approach" });
    const sid = s.data.session.id;
    const qs = s.data.questions.slice(0, 5);
    for (const q of qs) {
      const res = await c.post("/api/submissions", {
        clientId: newClientId(),
        sessionId: sid,
        questionId: q.id,
        questionVersion: q.version,
        answer: correctAnswer(app.content.activeQuestion.get(q.id)!),
      });
      assert.equal(res.data.correct, true);
      assert.equal(res.data.independent, true);
    }
    const boot = await c.get("/api/bootstrap");
    const kp = boot.data.kps.find((k: any) => k.id === "limit-approach");
    assert.equal(kp.mastery, "pending_verify");
    assert.equal(kp.difficulty, "advanced");

    const s2 = await c.post("/api/sessions", { kpId: "limit-approach", forceNew: true });
    for (const q of s2.data.questions.slice(0, 2)) {
      await c.post("/api/submissions", {
        clientId: newClientId(),
        sessionId: s2.data.session.id,
        questionId: q.id,
        questionVersion: q.version,
        answer: wrongAnswer(app.content.activeQuestion.get(q.id)!),
      });
    }
    const boot2 = await c.get("/api/bootstrap");
    const kp2 = boot2.data.kps.find((k: any) => k.id === "limit-approach");
    assert.equal(kp2.difficulty, "standard");
  });

  await t.test("同题反复作答不能刷成多道不同题", async () => {
    const c = new TestClient(app.url);
    await register(c, "repeat");
    for (let i = 0; i < 5; i++) {
      const s = await c.post("/api/sessions", { kpId: "limit-approach", forceNew: true });
      const q = s.data.questions[0];
      await c.post("/api/submissions", {
        clientId: newClientId(),
        sessionId: s.data.session.id,
        questionId: q.id,
        questionVersion: q.version,
        answer: correctAnswer(app.content.activeQuestion.get(q.id)!),
      });
    }
    const boot = await c.get("/api/bootstrap");
    const kp = boot.data.kps.find((k: any) => k.id === "limit-approach");
    assert.notEqual(kp.mastery, "pending_verify");
    assert.notEqual(kp.mastery, "mastered");
  });

  await t.test("完成学习会话后安排复习；公式自评推进间隔", async () => {
    const c = new TestClient(app.url);
    await register(c, "review");
    const s = await c.post("/api/sessions", { kpId: "limit-approach" });
    const done = await c.post(`/api/sessions/${s.data.session.id}/complete`, { revision: s.data.session.revision });
    assert.equal(done.status, 200);
    assert.ok(done.data.nextReview);
    const reviews = await c.get("/api/reviews");
    assert.ok(reviews.data.upcoming.some((r: any) => r.kind === "kp" && r.targetId === "limit-approach"));
    const fr = await c.post("/api/formulas/limit-notation/result", { result: "good" });
    assert.equal(fr.status, 200);
    assert.equal(fr.data.review.stage, 1);
    const bad = await c.post("/api/formulas/limit-notation/result", { result: "bad" });
    assert.equal(bad.data.review.stage, 0);
  });

  await t.test("导出不含密码或令牌摘要", async () => {
    const c = new TestClient(app.url);
    await register(c, "export");
    const exp = await c.get("/api/export");
    assert.equal(exp.status, 200);
    assert.ok(!exp.text.includes("password_hash"));
    assert.ok(!exp.text.includes("token_hash"));
    assert.equal(exp.data.app, "calculus-learning");
  });

  await t.test("AI 未配置时返回内置内容", async () => {
    const c = new TestClient(app.url);
    await register(c, "ai");
    const status = await c.get("/api/ai/status");
    assert.equal(status.data.enabled, false);
    const res = await c.post("/api/ai/tasks", { task: "explain", kpId: "limit-approach" });
    assert.equal(res.status, 200);
    assert.equal(res.data.source, "builtin");
    assert.ok(res.data.content.length > 0);
    assert.equal((await c.post("/api/ai/tasks", { task: "hint", kpId: "limit-approach" })).status, 400);
    assert.equal((await c.post("/api/ai/tasks", { task: "nope", kpId: "limit-approach" })).status, 400);
  });

  await t.test("Agent 令牌：读取、分页、建议、只读限制与撤销", async () => {
    const c = new TestClient(app.url);
    await register(c, "agent-user");
    const before = await c.get("/api/stats");
    const created = await c.post("/api/agent-tokens", {
      name: "test agent",
      scopes: ["learning:read", "suggestions:write"],
    });
    assert.equal(created.status, 201);
    const token = created.data.token;
    const agent = new TestClient(app.url);
    const ctx = await agent.request("/api/agent/v1/context", { headers: { authorization: `Bearer ${token}` } });
    assert.equal(ctx.status, 200);
    assert.ok(ctx.data.classroom.kpId);

    const page = await agent.request("/api/agent/v1/knowledge-points?limit=2", { headers: { authorization: `Bearer ${token}` } });
    assert.equal(page.status, 200);
    assert.equal(page.data.items.length, Math.min(2, page.data.total));
    assert.ok(page.data.nextCursor === null || typeof page.data.nextCursor === "string");

    const bankBefore = app.content.activeQuestion.size;
    const sug = await agent.request("/api/agent/v1/suggestions", {
      method: "POST",
      headers: { authorization: `Bearer ${token}` },
      body: {
        kind: "review_recommendation",
        content: { text: "明天先复习左右极限，再做分段连续性。", kpIds: ["limit-approach"] },
      },
    });
    assert.equal(sug.status, 201);
    assert.equal(sug.data.status, "pending");

    const after = await c.get("/api/stats");
    assert.deepEqual(after.data.totals, before.data.totals, "Agent 读取不应改变学习进度");
    assert.equal(app.content.activeQuestion.size, bankBefore, "候选建议不应直接进入正式题库");

    const readOnly = await c.post("/api/agent-tokens", { name: "read only", scopes: ["learning:read"] });
    const ro = await agent.request("/api/agent/v1/suggestions", {
      method: "POST",
      headers: { authorization: `Bearer ${readOnly.data.token}` },
      body: { kind: "review_recommendation", content: { text: "只读令牌不应能提交建议。" } },
    });
    assert.equal(ro.status, 403);

    const revoked = await c.post("/api/agent-tokens", { name: "to revoke", scopes: ["learning:read"] });
    assert.equal((await c.delete(`/api/agent-tokens/${revoked.data.tokenId}`)).status, 200);
    const afterRevoke = await agent.request("/api/agent/v1/context", {
      headers: { authorization: `Bearer ${revoked.data.token}` },
    });
    assert.equal(afterRevoke.status, 401);
    assert.equal(afterRevoke.data.error.code, "TOKEN_REVOKED");
  });

  await t.test("Agent 每令牌每分钟 60 次限制", async () => {
    const c = new TestClient(app.url);
    await register(c, "ratelimit");
    const created = await c.post("/api/agent-tokens", { name: "rate", scopes: ["learning:read"] });
    const agent = new TestClient(app.url);
    let last = 0;
    for (let i = 0; i < 61; i++) {
      const r = await agent.request("/api/agent/v1/context", { headers: { authorization: `Bearer ${created.data.token}` } });
      last = r.status;
    }
    assert.equal(last, 429);
  });

  await t.test("访问其他用户记录与无效令牌被拒绝", async () => {
    const c = new TestClient(app.url);
    await register(c, "privacy");
    const s = await c.post("/api/sessions", { kpId: "limit-approach" });
    const other = new TestClient(app.url);
    await register(other, "privacy2");
    assert.equal((await other.get(`/api/sessions/${s.data.session.id}`)).status, 404);
    const agent = new TestClient(app.url);
    assert.equal((await agent.request("/api/agent/v1/context", { headers: { authorization: "Bearer not-a-real-token-1234567890" } })).status, 401);
  });
});
