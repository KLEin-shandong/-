import { createServer, type Server } from "node:http";
import type { AddressInfo } from "node:net";
import { join } from "node:path";
import { openDb, type DB } from "../server/db.ts";
import { loadContent, type ContentBundle } from "../server/content.ts";
import { createHandler } from "../server/app.ts";
import type { AppConfig } from "../server/config.ts";
import type { AnswerSpec, AnswerValue, Question } from "../shared/types.ts";

export interface TestApp {
  url: string;
  server: Server;
  db: DB;
  content: ContentBundle;
  close: () => Promise<void>;
}

export async function startApp(): Promise<TestApp> {
  const db = openDb(":memory:");
  const content = loadContent();
  const root = join(process.cwd());
  const config: AppConfig = {
    port: 0,
    host: "127.0.0.1",
    dataDir: join(root, "data"),
    dbPath: ":memory:",
    sessionSecret: "test-secret",
    signupCode: "",
    allowRegistration: true,
    ai: { enabled: false, baseUrl: "", model: "", apiKey: "", timeoutMs: 1000 },
  };
  const handler = createHandler({ db, content, config, root, webDir: join(root, "web") });
  const server = createServer(handler);
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  const port = (server.address() as AddressInfo).port;
  return {
    url: `http://127.0.0.1:${port}`,
    server,
    db,
    content,
    close: async () => {
      await new Promise<void>((resolve) => server.close(() => resolve()));
      db.close();
    },
  };
}

export class TestClient {
  cookie = "";
  base: string;
  constructor(base: string) {
    this.base = base;
  }

  async request(
    path: string,
    options: { method?: string; body?: unknown; headers?: Record<string, string> } = {},
  ): Promise<{ status: number; data: any; text: string }> {
    const headers: Record<string, string> = { ...(options.headers ?? {}) };
    if (this.cookie) headers.cookie = this.cookie;
    let body: string | undefined;
    if (options.body !== undefined) {
      headers["content-type"] = "application/json";
      body = JSON.stringify(options.body);
    }
    const res = await fetch(this.base + path, { method: options.method ?? "GET", headers, body });
    const setCookies = typeof (res.headers as any).getSetCookie === "function"
      ? (res.headers as any).getSetCookie() as string[]
      : (res.headers.get("set-cookie") ? [res.headers.get("set-cookie")!] : []);
    for (const c of setCookies) {
      const pair = c.split(";")[0];
      if (pair.startsWith("cl_session=")) this.cookie = pair;
    }
    const text = await res.text();
    let data: any = null;
    try { data = text ? JSON.parse(text) : null; } catch { data = null; }
    return { status: res.status, data, text };
  }
  get(path: string) { return this.request(path); }
  post(path: string, body?: unknown) { return this.request(path, { method: "POST", body }); }
  delete(path: string) { return this.request(path, { method: "DELETE" }); }
}

export async function register(client: TestClient, username = `u${Math.random().toString(36).slice(2, 10)}`) {
  const res = await client.post("/api/auth/register", { username, password: "password123" });
  if (res.status !== 201) throw new Error(`register failed: ${res.status} ${res.text}`);
  return username;
}

export function answerValueString(spec: AnswerSpec): string {
  switch (spec.kind) {
    case "choice": return spec.value;
    case "number": return String(spec.value);
    case "fraction": return `${spec.numerator}/${spec.denominator}`;
    case "symbol":
      return spec.value === "infinity" ? "∞" : spec.value === "-infinity" ? "-∞" : spec.value === "dne" ? "不存在" : "0";
    case "expression": return spec.accept[0];
    case "steps": return "";
  }
}

export function correctAnswer(q: Question): AnswerValue {
  const a = q.answer;
  if (a.kind === "steps") {
    const values: Record<string, string> = {};
    for (const s of a.steps) values[s.label] = answerValueString(s.answer);
    return { kind: "steps", values };
  }
  if (a.kind === "choice") return { kind: "choice", value: a.value };
  if (a.kind === "number") return { kind: "number", value: String(a.value) };
  if (a.kind === "fraction") return { kind: "fraction", value: `${a.numerator}/${a.denominator}` };
  if (a.kind === "symbol") return { kind: "symbol", value: answerValueString(a) };
  return { kind: "expression", value: a.accept[0] };
}

export function wrongAnswer(q: Question): AnswerValue {
  const a = q.answer;
  if (a.kind === "choice") {
    const other = q.options?.find((o) => o.id !== a.value)?.id ?? "Z";
    return { kind: "choice", value: other };
  }
  if (a.kind === "number") return { kind: "number", value: String(a.value + 17) };
  if (a.kind === "fraction") return { kind: "fraction", value: `${a.numerator + 1}/${a.denominator}` };
  if (a.kind === "symbol") return { kind: "symbol", value: a.value === "infinity" ? "-∞" : "∞" };
  if (a.kind === "expression") return { kind: "expression", value: "x+12345" };
  const values: Record<string, string> = {};
  for (const s of a.steps) values[s.label] = "99999";
  return { kind: "steps", values };
}

export function newClientId(): string {
  return crypto.randomUUID();
}
