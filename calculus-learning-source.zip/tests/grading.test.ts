import test from "node:test";
import assert from "node:assert/strict";
import { gradeAnswer, isIndependent } from "../shared/grading.ts";
import { expressionsEqual, parseNumericAnswer, rationalValue } from "../shared/expr.ts";

test("分数按约分后的有理数值比较", () => {
  const spec = { kind: "fraction" as const, numerator: 1, denominator: 2 };
  assert.equal(gradeAnswer(spec, { kind: "fraction", value: "2/4" }).correct, true);
  assert.equal(gradeAnswer(spec, { kind: "fraction", value: "0.5" }).correct, true);
  assert.equal(gradeAnswer(spec, { kind: "fraction", value: "-1/2" }).correct, false);
});

test("负数、零与有限小数", () => {
  assert.equal(gradeAnswer({ kind: "number", value: -3 }, { kind: "number", value: "-3.0" }).correct, true);
  assert.equal(gradeAnswer({ kind: "number", value: 0 }, { kind: "number", value: "0" }).correct, true);
  assert.equal(gradeAnswer({ kind: "number", value: 0.25 }, { kind: "number", value: "1/4" }).correct, true);
  assert.equal(gradeAnswer({ kind: "number", value: 0.1 }, { kind: "number", value: "0.1" }).correct, true);
  assert.equal(gradeAnswer({ kind: "number", value: 0.1 }, { kind: "number", value: "0.2" }).correct, false);
});

test("近似答案的容差边界", () => {
  const spec = { kind: "number" as const, value: 1, tolerance: 0.01, toleranceKind: "absolute" as const };
  assert.equal(gradeAnswer(spec, { kind: "number", value: "1.01" }).correct, true);
  assert.equal(gradeAnswer(spec, { kind: "number", value: "1.0101" }).correct, false);
  assert.equal(gradeAnswer(spec, { kind: "number", value: "0.99" }).correct, true);
  assert.equal(gradeAnswer(spec, { kind: "number", value: "0.989" }).correct, false);
  const rel = { kind: "number" as const, value: 100, tolerance: 0.02, toleranceKind: "relative" as const };
  assert.equal(gradeAnswer(rel, { kind: "number", value: "102" }).correct, true);
  assert.equal(gradeAnswer(rel, { kind: "number", value: "103" }).correct, false);
});

test("无穷、负无穷与极限不存在必须区分", () => {
  const inf = { kind: "symbol" as const, value: "infinity" as const };
  assert.equal(gradeAnswer(inf, { kind: "symbol", value: "∞" }).correct, true);
  assert.equal(gradeAnswer(inf, { kind: "symbol", value: "-∞" }).correct, false);
  assert.equal(gradeAnswer(inf, { kind: "symbol", value: "不存在" }).correct, false);
  assert.equal(gradeAnswer({ kind: "symbol", value: "dne" }, { kind: "symbol", value: "不存在" }).correct, true);
});

test("格式错误不计为数学错误", () => {
  const r = gradeAnswer({ kind: "number", value: 2 }, { kind: "number", value: "二" });
  assert.equal(r.correct, false);
  assert.equal(r.formatError, true);
  const e = gradeAnswer({ kind: "expression", accept: ["2x+2"] }, { kind: "expression", value: "2x+" });
  assert.equal(e.formatError, true);
});

test("表达式精确等价：多项式与有理式", () => {
  assert.equal(expressionsEqual("2x+2", "2(x+1)"), true);
  assert.equal(expressionsEqual("x^2-1", "(x-1)(x+1)"), true);
  assert.equal(expressionsEqual("1/(x+1)", "(x-1)/(x^2-1)"), true);
  assert.equal(expressionsEqual("2x+2", "2x+3"), false);
  assert.equal(expressionsEqual("x/x", "1"), true);
  assert.equal(expressionsEqual("sin(x)/x", "sin(x)/x"), true);
  assert.equal(expressionsEqual("sin(x)/x", "1"), false);
});

test("数值输入解析：分数与小数", () => {
  assert.equal(rationalValue(parseNumericAnswer("3/4")), 0.75);
  assert.equal(rationalValue(parseNumericAnswer("-1.5")), -1.5);
  assert.throws(() => parseNumericAnswer("1/0"));
  assert.throws(() => parseNumericAnswer("abc"));
});

test("独立答对口径：首次、未提示、未看解析", () => {
  const base = { correct: true, formatError: false, firstAttempt: true, hintLevel: 0, solutionViewed: false };
  assert.equal(isIndependent(base), true);
  assert.equal(isIndependent({ ...base, hintLevel: 1 }), false);
  assert.equal(isIndependent({ ...base, solutionViewed: true }), false);
  assert.equal(isIndependent({ ...base, firstAttempt: false }), false);
  assert.equal(isIndependent({ ...base, correct: false }), false);
});
