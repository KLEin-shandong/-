import { api } from "./api.ts";

const POLL_MS = 15_000;

let timer: number | null = null;
let version = "";
let busy = false;
let handler: ((nextVersion: string) => Promise<string | void> | string | void) | null = null;

function onVisible(): void {
  if (document.visibilityState === "visible") void poll();
}

function onOnline(): void {
  void poll();
}

/**
 * 轮询服务端内容版本。内容文件更新后，handler 负责刷新数据并返回实际载入的版本。
 */
export function startContentWatch(
  currentVersion: string,
  onUpdate: (nextVersion: string) => Promise<string | void> | string | void,
): void {
  version = currentVersion;
  handler = onUpdate;
  if (timer !== null) return;
  timer = window.setInterval(() => void poll(), POLL_MS);
  document.addEventListener("visibilitychange", onVisible);
  window.addEventListener("online", onOnline);
  void poll();
}

export function stopContentWatch(): void {
  if (timer !== null) {
    window.clearInterval(timer);
    timer = null;
  }
  handler = null;
  document.removeEventListener("visibilitychange", onVisible);
  window.removeEventListener("online", onOnline);
}

async function poll(): Promise<void> {
  if (busy || timer === null || document.visibilityState === "hidden") return;
  busy = true;
  try {
    const health = await api.get<{ contentVersion?: string }>("/api/health");
    if (!health.contentVersion || health.contentVersion === version) return;
    const applied = await handler?.(health.contentVersion);
    version = typeof applied === "string" ? applied : health.contentVersion;
  } catch {
    /* 网络中断时保持现状，下一次轮询再试。 */
  } finally {
    busy = false;
  }
}
