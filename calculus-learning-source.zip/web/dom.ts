export function esc(value: unknown): string {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

export function el(html: string): HTMLElement {
  const t = document.createElement("template");
  t.innerHTML = html.trim();
  const node = t.content.firstElementChild;
  if (!node) throw new Error("empty template");
  return node as HTMLElement;
}

export function qs<T extends Element = HTMLElement>(root: ParentNode, selector: string): T {
  const node = root.querySelector(selector);
  if (!node) throw new Error(`missing ${selector}`);
  return node as T;
}

export function qsa<T extends Element = HTMLElement>(root: ParentNode, selector: string): T[] {
  return [...root.querySelectorAll(selector)] as T[];
}

let toastTimer: number | undefined;
export function toast(message: string, ms = 2600): void {
  const node = document.getElementById("toast");
  if (!node) return;
  node.textContent = message;
  node.classList.add("show");
  if (toastTimer) window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => node.classList.remove("show"), ms);
}

export interface ModalAction {
  label: string;
  kind?: "primary" | "danger" | "ghost";
  onClick: () => void | Promise<void>;
}

export function modal(options: { title: string; body: string; actions?: ModalAction[] }): void {
  const dialog = document.getElementById("modal") as HTMLDialogElement | null;
  if (!dialog) return;
  dialog.innerHTML = `
    <div class="modal-inner">
      <h2>${esc(options.title)}</h2>
      <div class="mt-2">${options.body}</div>
      <div class="row end mt-3" id="modal-actions"></div>
    </div>`;
  const actions = dialog.querySelector("#modal-actions") as HTMLElement;
  const list = options.actions?.length ? options.actions : [{ label: "知道了", kind: "primary" as const, onClick: () => {} }];
  for (const a of list) {
    const btn = document.createElement("button");
    btn.className = `btn ${a.kind ?? "primary"}`;
    btn.textContent = a.label;
    btn.addEventListener("click", async () => {
      await a.onClick();
      dialog.close();
    });
    actions.appendChild(btn);
  }
  dialog.showModal();
  dialog.addEventListener("click", (e) => {
    if (e.target === dialog) dialog.close();
  }, { once: true });
}

export function confirmDialog(title: string, body: string, okLabel = "确定"): Promise<boolean> {
  return new Promise((resolve) => {
    let done = false;
    modal({
      title,
      body,
      actions: [
        { label: okLabel, kind: "primary", onClick: () => { done = true; resolve(true); } },
        { label: "取消", kind: "ghost", onClick: () => { done = true; resolve(false); } },
      ],
    });
    const dialog = document.getElementById("modal") as HTMLDialogElement | null;
    dialog?.addEventListener("close", () => { if (!done) resolve(false); }, { once: true });
  });
}

export const MASTERY_LABEL: Record<string, string> = {
  not_started: "未开始",
  learning: "正在学习",
  needs_review: "需要巩固",
  pending_verify: "待复习验证",
  mastered: "已掌握",
};
export const MASTERY_CLASS: Record<string, string> = {
  not_started: "line",
  learning: "blue",
  needs_review: "amber",
  pending_verify: "amber",
  mastered: "green",
};
export const DIFFICULTY_LABEL: Record<string, string> = {
  basic: "基础",
  standard: "标准",
  advanced: "提高",
};
export const ROLE_LABEL: Record<string, string> = {
  concept: "概念",
  step: "分步",
  independent: "独立作答",
};

export function fmtDate(iso: string | null | undefined): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return String(iso);
  return new Intl.DateTimeFormat("zh-CN", { month: "numeric", day: "numeric", hour: "2-digit", minute: "2-digit" }).format(d);
}

export function fmtDay(date: string | null | undefined): string {
  if (!date) return "—";
  return date;
}

export function answerToText(value: unknown): string {
  if (value == null) return "（空）";
  if (typeof value === "string") return value;
  if (typeof value === "object") {
    const o = value as Record<string, unknown>;
    if (o.kind === "steps") {
      const values = (o.values ?? {}) as Record<string, string>;
      return Object.entries(values).map(([k, v]) => `${k}：${v || "（空）"}`).join("；");
    }
    if (typeof o.value === "string") return o.value;
  }
  return JSON.stringify(value);
}

export function initials(name: string): string {
  return [...name].slice(0, 1).join("").toUpperCase() || "学";
}
