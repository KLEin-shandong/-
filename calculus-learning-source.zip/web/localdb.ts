// IndexedDB：暂存草稿与未同步提交。切换账号时清理旧账号数据。

const DB_NAME = "calculus-learning";
const DB_VERSION = 1;

let dbPromise: Promise<IDBDatabase> | null = null;

function open(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains("kv")) db.createObjectStore("kv", { keyPath: "key" });
      if (!db.objectStoreNames.contains("outbox")) {
        const store = db.createObjectStore("outbox", { keyPath: "id" });
        store.createIndex("userId", "userId", { unique: false });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return dbPromise;
}

async function tx<T>(store: string, mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  const db = await open();
  return new Promise((resolve, reject) => {
    const t = db.transaction(store, mode);
    const req = fn(t.objectStore(store));
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export interface OutboxItem {
  id: string;
  userId: string;
  kind: "submission" | "state";
  payload: Record<string, unknown>;
  createdAt: string;
}

export async function setKV(key: string, value: unknown): Promise<void> {
  await tx("kv", "readwrite", (s) => s.put({ key, value }));
}
export async function getKV<T>(key: string): Promise<T | null> {
  const row = await tx<{ key: string; value: T } | undefined>("kv", "readonly", (s) => s.get(key) as IDBRequest<{ key: string; value: T } | undefined>);
  return row ? row.value : null;
}
export async function delKV(key: string): Promise<void> {
  await tx("kv", "readwrite", (s) => s.delete(key));
}

export async function clearUserData(userId: string): Promise<void> {
  const keys = await tx<IDBValidKey[]>("kv", "readonly", (s) => s.getAllKeys());
  const db = await open();
  await new Promise<void>((resolve, reject) => {
    const t = db.transaction(["kv", "outbox"], "readwrite");
    const kv = t.objectStore("kv");
    for (const key of keys) {
      if (String(key).includes(`:${userId}:`)) kv.delete(key);
    }
    const outbox = t.objectStore("outbox");
    const idx = outbox.index("userId");
    const req = idx.getAllKeys(userId);
    req.onsuccess = () => {
      for (const id of req.result) outbox.delete(id);
    };
    t.oncomplete = () => resolve();
    t.onerror = () => reject(t.error);
  });
}

export async function enqueue(item: OutboxItem): Promise<void> {
  await tx("outbox", "readwrite", (s) => s.put(item));
}
export async function listOutbox(userId: string): Promise<OutboxItem[]> {
  const db = await open();
  return new Promise((resolve, reject) => {
    const t = db.transaction("outbox", "readonly");
    const req = t.objectStore("outbox").index("userId").getAll(userId);
    req.onsuccess = () => resolve((req.result as OutboxItem[]).sort((a, b) => a.createdAt.localeCompare(b.createdAt)));
    req.onerror = () => reject(req.error);
  });
}
export async function removeOutbox(id: string): Promise<void> {
  await tx("outbox", "readwrite", (s) => s.delete(id));
}

export function draftKey(userId: string, sessionId: string): string {
  return `draft:${userId}:${sessionId}`;
}
export function sessionKey(userId: string, sessionId: string): string {
  return `session:${userId}:${sessionId}`;
}
export async function setLastUser(userId: string): Promise<void> {
  await setKV("lastUser", userId);
}
export async function getLastUser(): Promise<string | null> {
  return getKV<string>("lastUser");
}
export async function clearAllForUserSwitch(newUserId: string | null): Promise<void> {
  const last = await getLastUser();
  if (last && last !== newUserId) await clearUserData(last);
  if (newUserId) await setLastUser(newUserId);
  else await delKV("lastUser");
}
