import { evaluateExpression } from "../shared/expr.ts";
import type { FigureSpec } from "../shared/types.ts";
import { esc } from "./dom.ts";
import { md } from "./markdown.ts";

const W = 640;
const H = 360;
const PAD = 42;

function xScale(x: number, min: number, max: number): number {
  return PAD + ((x - min) / (max - min || 1)) * (W - PAD * 2);
}
function yScale(y: number, min: number, max: number): number {
  return H - PAD - ((y - min) / (max - min || 1)) * (H - PAD * 2);
}

function samplePath(fn: string, xMin: number, xMax: number, yMin: number, yMax: number, step = 2): string {
  const parts: string[] = [];
  let pen = false;
  for (let px = PAD; px <= W - PAD; px += step) {
    const x = xMin + ((px - PAD) / (W - PAD * 2)) * (xMax - xMin);
    let y: number;
    try {
      y = evaluateExpression(fn, x);
    } catch {
      pen = false;
      continue;
    }
    if (!Number.isFinite(y) || y < yMin - (yMax - yMin) * 2 || y > yMax + (yMax - yMin) * 2) {
      pen = false;
      continue;
    }
    const py = yScale(y, yMin, yMax);
    parts.push(`${pen ? "L" : "M"}${px.toFixed(1)},${py.toFixed(1)}`);
    pen = true;
  }
  return parts.join(" ");
}

export function renderFigure(spec: FigureSpec): string {
  if (spec.kind === "table" && spec.table) {
    const head = spec.table.head.map((h) => `<th>${esc(h)}</th>`).join("");
    const rows = spec.table.rows
      .map((r) => `<tr>${r.map((c) => `<td>${esc(c)}</td>`).join("")}</tr>`)
      .join("");
    return `<figure class="figure"><table class="lesson-table"><thead><tr>${head}</tr></thead><tbody>${rows}</tbody></table>${spec.caption ? `<figcaption>${md(spec.caption)}</figcaption>` : ""}</figure>`;
  }

  const xMin = spec.xMin ?? -5;
  const xMax = spec.xMax ?? 5;
  const yMin = spec.yMin ?? -5;
  const yMax = spec.yMax ?? 5;
  const pieces: string[] = [];

  pieces.push(`<defs><clipPath id="plotclip"><rect x="${PAD}" y="${PAD}" width="${W - PAD * 2}" height="${H - PAD * 2}"/></clipPath></defs>`);
  pieces.push(`<rect x="${PAD}" y="${PAD}" width="${W - PAD * 2}" height="${H - PAD * 2}" fill="#fbfaf5" stroke="#e3ded2"/>`);

  // 网格与刻度
  const ticks = 5;
  for (let k = 0; k <= ticks; k++) {
    const xv = xMin + ((xMax - xMin) * k) / ticks;
    const yv = yMin + ((yMax - yMin) * k) / ticks;
    const px = xScale(xv, xMin, xMax);
    const py = yScale(yv, yMin, yMax);
    pieces.push(`<line x1="${px}" y1="${PAD}" x2="${px}" y2="${H - PAD}" stroke="#eee9dd" stroke-width="1"/>`);
    pieces.push(`<line x1="${PAD}" y1="${py}" x2="${W - PAD}" y2="${py}" stroke="#eee9dd" stroke-width="1"/>`);
    pieces.push(`<text x="${px}" y="${H - PAD + 16}" font-size="11" text-anchor="middle" fill="#8a8f89">${esc(fmt(xv))}</text>`);
    pieces.push(`<text x="${PAD - 8}" y="${py + 4}" font-size="11" text-anchor="end" fill="#8a8f89">${esc(fmt(yv))}</text>`);
  }

  // 坐标轴
  if (xMin <= 0 && xMax >= 0) {
    const px = xScale(0, xMin, xMax);
    pieces.push(`<line x1="${px}" y1="${PAD}" x2="${px}" y2="${H - PAD}" stroke="#9a9f99" stroke-width="1.3"/>`);
  }
  if (yMin <= 0 && yMax >= 0) {
    const py = yScale(0, yMin, yMax);
    pieces.push(`<line x1="${PAD}" y1="${py}" x2="${W - PAD}" y2="${py}" stroke="#9a9f99" stroke-width="1.3"/>`);
  }

  // 函数曲线
  const groups: Array<{ fn: string; from: number; to: number }> = [];
  if (spec.fn) groups.push({ fn: spec.fn, from: xMin, to: xMax });
  for (const seg of spec.segments ?? []) groups.push({ fn: seg.fn, from: seg.from, to: seg.to });
  for (const g of groups) {
    const d = samplePath(g.fn, g.from, g.to, yMin, yMax);
    if (d) pieces.push(`<path d="${d}" fill="none" stroke="#2f6b57" stroke-width="2.4" clip-path="url(#plotclip)" stroke-linecap="round"/>`);
  }

  // 辅助虚线
  for (const line of spec.lines ?? []) {
    if (line.x != null) {
      const px = xScale(line.x, xMin, xMax);
      pieces.push(`<line x1="${px}" y1="${PAD}" x2="${px}" y2="${H - PAD}" stroke="#b9b1a0" stroke-width="1.2" stroke-dasharray="${line.dashed ? "5 4" : "0"}"/>`);
    }
    if (line.y != null) {
      const py = yScale(line.y, yMin, yMax);
      pieces.push(`<line x1="${PAD}" y1="${py}" x2="${W - PAD}" y2="${py}" stroke="#b9b1a0" stroke-width="1.2" stroke-dasharray="${line.dashed ? "5 4" : "0"}"/>`);
    }
    if (line.label) {
      const px = line.x != null ? xScale(line.x, xMin, xMax) + 6 : PAD + 6;
      const py = line.y != null ? yScale(line.y, yMin, yMax) - 6 : PAD + 14;
      pieces.push(`<text x="${px}" y="${py}" font-size="12" fill="#6b716c">${esc(line.label)}</text>`);
    }
  }

  // 标注点
  for (const pt of spec.points ?? []) {
    const px = xScale(pt.x, xMin, xMax);
    const py = yScale(pt.y, yMin, yMax);
    pieces.push(
      pt.open
        ? `<circle cx="${px}" cy="${py}" r="4.5" fill="#fffdf8" stroke="#2f6b57" stroke-width="2"/>`
        : `<circle cx="${px}" cy="${py}" r="4.5" fill="#2f6b57"/>`,
    );
    if (pt.label) {
      pieces.push(`<text x="${px + 9}" y="${py - 9}" font-size="12.5" fill="#1f2421">${esc(pt.label)}</text>`);
    }
  }

  return `<figure class="figure"><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(spec.caption ?? "函数图像")}">${pieces.join("")}</svg>${spec.caption ? `<figcaption>${md(spec.caption)}</figcaption>` : ""}</figure>`;
}

function fmt(v: number): string {
  if (Math.abs(v) < 1e-9) return "0";
  return Number(v.toFixed(2)).toString();
}
