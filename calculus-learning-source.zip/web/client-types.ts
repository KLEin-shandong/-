import type { Block, FigureSpec, FormulaCard, ModuleId } from "../shared/types.ts";

export interface KpSummary {
  id: string;
  module: ModuleId;
  order: number;
  title: string;
  subtitle: string;
  minutes: number;
  prereqs: string[];
  prereqTitles: string[];
  mastery: string;
  difficulty: string;
  pendingSince: string | null;
  verifiedAt: string | null;
  masteredAt: string | null;
  reviewDue: string | null;
  reviewStage: number | null;
  formulaCount: number;
  questionCount: number;
}

export interface ReviewView {
  id: string;
  kind: "kp" | "formula";
  targetId: string;
  title: string;
  stage: number;
  dueDate: string;
  lastResult: string | null;
  kpId: string | null;
  formula: FormulaCard | null;
}

export interface Bootstrap {
  user: { id: string; username: string };
  settings: { classroomKpId: string; defaultMinutes: number; timezone: string };
  modules: Array<{ id: ModuleId; title: string; description: string; order: number }>;
  kps: KpSummary[];
  dueReviewCount: number;
  dueReviews: ReviewView[];
  lastSession: null | { id: string; kpId: string; status: string; updatedAt: string; position: number; mode: string };
  placement: null | { score: number; skipped: number; created_at: string };
  contentVersion: string;
  aiEnabled: boolean;
  pendingSuggestions: number;
}

export interface PublicQuestion {
  id: string;
  version: number;
  kpId: string;
  difficulty: string;
  type: string;
  role: string;
  prompt: Block[];
  options?: Array<{ id: string; md: string }>;
  formatHint?: string;
  stepLabels?: string[];
  hintLevel: number;
  hints?: string[];
  solution?: Block[];
  solutionViewed: boolean;
  answered: boolean;
  correct: boolean | null;
  formatError: boolean | null;
}

export interface SessionPayload {
  session: {
    id: string;
    userId: string;
    kpId: string;
    status: string;
    questionIds: string[];
    position: number;
    drafts: Record<string, unknown>;
    revision: number;
    createdAt: string;
    updatedAt: string;
  };
  kp: null | {
    id: string;
    title: string;
    subtitle: string;
    module: ModuleId;
    minutes: number;
    summary: string[];
    formulaIds: string[];
  };
  questions: PublicQuestion[];
  mode: "learn" | "review";
}

export interface KnowledgePointDetail {
  kp: {
    id: string;
    module: ModuleId;
    order: number;
    title: string;
    subtitle: string;
    version: number;
    minutes: number;
    prereqs: string[];
    prereqTitles: string[];
    source: Array<{ file: string; pages?: string; kind: string; note?: string }>;
    objectives: string[];
    blocks: Block[];
    summary: string[];
    formulaIds: string[];
    formulas: Array<{ id: string; name: string; tex: string; conditions: string }>;
  };
  state: { difficulty: string; mastery: string; pendingSince: string | null; verifiedAt: string | null; masteredAt: string | null };
  review: ReviewView | null;
  questionCount: number;
  remediation: Array<{ id: string; title: string }>;
}

export interface NotebookItem {
  questionId: string;
  version: number;
  kpId: string;
  kpTitle: string;
  module: ModuleId;
  difficulty: string;
  type: string;
  role: string;
  prompt: Block[];
  options?: Array<{ id: string; md: string }>;
  formatHint?: string;
  hints: string[];
  solution: Block[];
  source: { kind: string; ref?: string };
  lastAnswer: unknown;
  lastAt: string;
  hintLevel: number;
  solutionViewed: boolean;
  attempts: Array<{
    id: string;
    answer: unknown;
    correct: boolean;
    formatError: boolean;
    hintLevel: number;
    solutionViewed: boolean;
    firstAttempt: boolean;
    createdAt: string;
  }>;
  reviewDue: string | null;
}

export interface GradeResponse {
  replayed?: boolean;
  submissionId?: string;
  correct: boolean;
  formatError: boolean;
  message?: string;
  detail?: Array<{ label: string; correct: boolean; message?: string }>;
  independent: boolean;
  firstAttempt: boolean;
  state: null | { difficulty: string; mastery: string; moved: string; justMastered: boolean };
}

export interface FigureBlockSpec {
  spec: FigureSpec;
}
