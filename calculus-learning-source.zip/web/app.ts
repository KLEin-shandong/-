import { api, ApiError, onUnauthorized } from "./api.ts";
import type { Bootstrap } from "./client-types.ts";
import { esc, initials, toast } from "./dom.ts";
import { currentPath, errorHtml, loadingHtml } from "./nav.ts";
import { clearAllForUserSwitch } from "./localdb.ts";
import { startContentWatch, stopContentWatch } from "./content-watch.ts";
import { renderLogin } from "./views/login.ts";
import { renderHome } from "./views/home.ts";
import { renderMap } from "./views/map.ts";
import { renderLesson } from "./views/lesson.ts";
import { renderPractice } from "./views/practice.ts";
import { renderNotebook } from "./views/notebook.ts";
import { renderReview } from "./views/review.ts";
import { renderStats } from "./views/stats.ts";
import { renderSettings } from "./views/settings.ts";
import { renderPlacement } from "./views/placement.ts";
import { renderAgentDocs } from "./views/agent.ts";

const app = document.getElementById("app") as HTMLElement;
let bootstrap: Bootstrap | null = null;
let booting = false;

onUnauthorized(() => {
  stopContentWatch();
  bootstrap = null;
  showLogin();
});

function showLogin(): void {
  renderLogin(app);
}

async function loadBootstrap(): Promise<Bootstrap> {
  const data = await api.get<Bootstrap>("/api/bootstrap");
  bootstrap = data;
  startContentWatch(data.contentVersion, handleContentUpdate);
  return data;
}

async function handleContentUpdate(): Promise<string> {
  const path = currentPath();
  const interactive =
    path.startsWith("/practice") ||
    path.startsWith("/review-practice") ||
    path.startsWith("/session") ||
    path.startsWith("/placement") ||
    path.startsWith("/settings");
  const data = await loadBootstrap();
  if (interactive) {
    toast("课程内容已更新，将在下次进入时使用。");
    return data.contentVersion;
  }
  toast("课程内容已更新，页面已刷新。");
  await route();
  return data.contentVersion;
}

async function boot(): Promise<void> {
  if (booting) return;
  booting = true;
  try {
    app.innerHTML = loadingHtml();
    const me = await api.get<{ user: null | { id: string; username: string } }>("/api/auth/me");
    if (!me.user) {
      stopContentWatch();
      await clearAllForUserSwitch(null);
      showLogin();
      return;
    }
    await clearAllForUserSwitch(me.user.id);
    await loadBootstrap();
    renderShell();
    await route();
  } catch (e) {
    if (e instanceof ApiError && e.status === 401) {
      showLogin();
    } else {
      app.innerHTML = errorHtml(e instanceof Error ? e.message : "无法连接服务器。");
    }
  } finally {
    booting = false;
  }
}

function renderShell(): void {
  if (!bootstrap) return;
  app.innerHTML = `
  <header class="topbar">
    <div class="topbar-inner">
      <a class="brand" href="#/home">
        <span class="brand-mark">∫</span>
        <span>微积分 · 一步一步<small>CALCULUS, STEP BY STEP</small></span>
      </a>
      <nav class="nav" id="top-nav">
        <a href="#/home" data-nav="home">首页</a>
        <a href="#/map" data-nav="map">课程地图</a>
        <a href="#/review" data-nav="review">复习</a>
        <a href="#/notebook" data-nav="notebook">错题本</a>
        <a href="#/stats" data-nav="stats">记录</a>
      </nav>
      <div class="topbar-right">
        <a class="user-chip" href="#/settings" title="设置">
          <span class="avatar">${esc(initials(bootstrap.user.username))}</span>
          <span class="name">${esc(bootstrap.user.username)}</span>
        </a>
        <button class="btn sm ghost" id="top-logout" title="退出登录">退出</button>
      </div>
    </div>
  </header>
  <main class="main" id="view"></main>
  <nav class="bottom-nav" id="bottom-nav">
    <a href="#/home" data-nav="home"><span class="ico">⌂</span>首页</a>
    <a href="#/map" data-nav="map"><span class="ico">◇</span>地图</a>
    <a href="#/review" data-nav="review"><span class="ico">↻</span>复习</a>
    <a href="#/notebook" data-nav="notebook"><span class="ico">✎</span>错题</a>
    <a href="#/stats" data-nav="stats"><span class="ico">◫</span>记录</a>
  </nav>`;

  app.querySelector("#top-logout")?.addEventListener("click", async () => {
    try {
      await api.post("/api/auth/logout");
    } catch {
      /* 忽略网络错误 */
    }
    stopContentWatch();
    await clearAllForUserSwitch(null);
    bootstrap = null;
    showLogin();
    toast("已退出登录。");
  });
}

function syncNav(path: string): void {
  let key = "home";
  if (path.startsWith("/map") || path.startsWith("/kp") || path.startsWith("/practice")) key = "map";
  if (path.startsWith("/review")) key = "review";
  if (path.startsWith("/notebook")) key = "notebook";
  if (path.startsWith("/stats")) key = "stats";
  if (path === "/home" || path === "/") key = "home";
  app.querySelectorAll<HTMLElement>("[data-nav]").forEach((a) => {
    a.classList.toggle("active", a.dataset.nav === key);
  });
}

async function route(): Promise<void> {
  const path = currentPath();
  if (path === "/login") {
    showLogin();
    return;
  }
  if (!bootstrap) {
    try {
      await loadBootstrap();
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) {
        showLogin();
        return;
      }
      app.innerHTML = errorHtml("无法载入学习数据，请检查服务器是否运行。");
      return;
    }
  }
  // 每次导航刷新状态；练习页自行管理会话
  if (!path.startsWith("/practice") && !path.startsWith("/session")) {
    try {
      await loadBootstrap();
    } catch {
      /* 保留旧数据，页面仍可显示 */
    }
  }
  if (!bootstrap) return;
  const view = app.querySelector("#view") as HTMLElement | null;
  if (!view) {
    renderShell();
    return route();
  }
  syncNav(path);
  view.innerHTML = loadingHtml();
  const parts = path.split("/").filter(Boolean);
  try {
    if (path === "/" || path === "/home" || parts[0] === "home") {
      renderHome(view, bootstrap);
    } else if (parts[0] === "map") {
      renderMap(view, bootstrap);
    } else if (parts[0] === "kp" && parts[1]) {
      await renderLesson(view, decodeURIComponent(parts[1]), bootstrap);
    } else if (parts[0] === "practice" && parts[1]) {
      await renderPractice(view, bootstrap, { kpId: decodeURIComponent(parts[1]), mode: "learn" });
    } else if (parts[0] === "review-practice" && parts[1]) {
      await renderPractice(view, bootstrap, { kpId: decodeURIComponent(parts[1]), mode: "review" });
    } else if (parts[0] === "session" && parts[1]) {
      await renderPractice(view, bootstrap, { sessionId: decodeURIComponent(parts[1]) });
    } else if (parts[0] === "notebook") {
      await renderNotebook(view, bootstrap);
    } else if (parts[0] === "review") {
      await renderReview(view, bootstrap);
    } else if (parts[0] === "stats") {
      await renderStats(view, bootstrap);
    } else if (parts[0] === "settings") {
      await renderSettings(view, bootstrap);
    } else if (parts[0] === "placement") {
      await renderPlacement(view, bootstrap);
    } else if (parts[0] === "agent") {
      renderAgentDocs(view);
    } else {
      renderHome(view, bootstrap);
    }
    if (!path.startsWith("/practice") && !path.startsWith("/session")) window.scrollTo({ top: 0 });
  } catch (e) {
    view.innerHTML = errorHtml(e instanceof Error ? e.message : "页面加载失败。");
  }
}

window.addEventListener("hashchange", () => { void route(); });
window.addEventListener("cl:auth-changed", () => { void boot(); });
window.addEventListener("cl:refresh-bootstrap", () => {
  void loadBootstrap().then(() => {
    const path = currentPath();
    if (path === "/" || path === "/home" || path === "/map" || path === "/stats" || path === "/settings") {
      void route();
    }
  }).catch(() => {});
});

void boot();
