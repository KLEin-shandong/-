import type { Block, FormulaCard } from "../shared/types.ts";
import { md } from "./markdown.ts";
import { renderTex } from "./tex.ts";
import { renderFigure } from "./figure.ts";
import { esc } from "./dom.ts";

export function renderBlocks(blocks: Block[] | undefined, formulas?: Map<string, FormulaCard>): string {
  if (!blocks?.length) return "";
  return blocks.map((b) => renderBlock(b, formulas)).join("");
}

function renderBlock(b: Block, formulas?: Map<string, FormulaCard>): string {
  switch (b.t) {
    case "p":
      return `<p class="prose">${md(b.md)}</p>`;
    case "h":
      return `<h3 class="mt-3">${md(b.text)}</h3>`;
    case "math":
      return `<div class="math-block">${renderTex(b.tex, true)}</div>`;
    case "example":
      return `<div class="example"><h3>${md(b.title)}</h3><ol>${b.steps.map((s) => `<li>${md(s)}</li>`).join("")}</ol>${b.answer ? `<div class="answer">${md(b.answer)}</div>` : ""}</div>`;
    case "pitfall":
      return `<div class="pitfall">${b.title ? `<h3>${md(b.title)}</h3>` : ""}<div class="prose">${md(b.md)}</div></div>`;
    case "callout":
      return `<div class="callout ${b.tone ?? "info"}">${b.title ? `<h3>${md(b.title)}</h3>` : ""}<div class="prose">${md(b.md)}</div></div>`;
    case "table": {
      const head = b.head.map((h) => `<th>${md(h)}</th>`).join("");
      const rows = b.rows.map((r) => `<tr>${r.map((c) => `<td>${md(c)}</td>`).join("")}</tr>`).join("");
      return `<div class="table-scroll"><table class="lesson-table"><thead><tr>${head}</tr></thead><tbody>${rows}</tbody></table></div>${b.caption ? `<p class="tiny muted" style="text-align:center">${md(b.caption)}</p>` : ""}`;
    }
    case "figure":
      return renderFigure(b.spec);
    case "list": {
      const tag = b.ordered ? "ol" : "ul";
      return `<${tag} class="prose">${b.items.map((i) => `<li>${md(i)}</li>`).join("")}</${tag}>`;
    }
    case "link":
      return `<p><a class="btn soft sm" href="#/kp/${encodeURIComponent(b.kpId)}">${esc(b.text)}</a></p>`;
    case "formula": {
      const f = formulas?.get(b.id);
      if (!f) return "";
      return `<div class="summary-card"><h3 style="font-size:14px;color:var(--muted)">公式卡 · ${md(f.name)}</h3><div class="math-block" style="margin-top:8px">${renderTex(f.tex, true)}</div><p class="small muted mt-1">${md(f.conditions)}</p></div>`;
    }
    default:
      return "";
  }
}
