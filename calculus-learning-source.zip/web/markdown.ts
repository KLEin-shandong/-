import { renderTex } from "./tex.ts";

function esc(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

/** 渲染一段受限 Markdown：$...$ 数学、**粗体**、`代码`、[[kp:id|文字]] 内部链接。 */
export function md(text: string): string {
  const source = String(text ?? "");
  let out = "";
  let i = 0;
  let buffer = "";

  const flush = () => {
    if (buffer) {
      out += inlineText(buffer);
      buffer = "";
    }
  };

  while (i < source.length) {
    const c = source[i];
    if (c === "$") {
      // 行内数学；不配对时按普通字符处理
      let j = i + 1;
      let found = -1;
      while (j < source.length) {
        if (source[j] === "$" && source[j - 1] !== "\\") {
          found = j;
          break;
        }
        j++;
      }
      if (found > i + 1) {
        flush();
        const tex = source.slice(i + 1, found);
        out += renderTex(tex);
        i = found + 1;
        continue;
      }
    }
    buffer += c;
    i++;
  }
  flush();
  return out;
}

function inlineText(text: string): string {
  let s = esc(text);
  // 内部链接 [[kp:id]] / [[kp:id|文字]]
  s = s.replace(/\[\[([^\]|]+)(?:\|([^\]]+))?\]\]/g, (_m, id: string, label?: string) => {
    const clean = String(id).trim();
    const href = clean.startsWith("kp:") ? `#/kp/${encodeURIComponent(clean.slice(3))}` : `#/kp/${encodeURIComponent(clean)}`;
    return `<a href="${href}">${label ? esc(label) : esc(clean.replace(/^kp:/, ""))}</a>`;
  });
  // 粗体
  s = s.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  // 行内代码
  s = s.replace(/`([^`]+)`/g, "<code>$1</code>");
  return s;
}
