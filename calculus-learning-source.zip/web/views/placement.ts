import { api, ApiError } from "../api.ts";
import type { Bootstrap } from "../client-types.ts";
import type { Block, Question } from "../../shared/types.ts";
import { renderBlocks } from "../blocks.ts";
import { md } from "../markdown.ts";
import { esc, toast } from "../dom.ts";
import { loadingHtml, errorHtml, navigate, refreshBootstrap } from "../nav.ts";

interface PlacementQuestion {
  id: string;
  kpId: string;
  type: string;
  prompt: Block[];
  options?: Array<{ id: string; md: string }>;
  formatHint?: string;
  tags?: string[];
}

export async function renderPlacement(root: HTMLElement, data: Bootstrap): Promise<void> {
  root.innerHTML = loadingHtml("正在准备摸底题……");
  let res: { questions: PlacementQuestion[]; areas: string[] };
  try {
    res = await api.get("/api/placement");
  } catch (e) {
    root.innerHTML = errorHtml(e instanceof ApiError ? e.message : "无法载入摸底。");
    return;
  }
  if (!res.questions.length) {
    root.innerHTML = `<div class="card"><h2>摸底题尚未配置</h2><p class="muted mt-1">可以先从课程地图开始学习。</p><a class="btn primary mt-3" href="#/map">去课程地图</a></div>`;
    return;
  }

  root.innerHTML = `
  <div class="page-head">
    <div>
      <div class="eyebrow">可选摸底</div>
      <h1>先看看基础在哪里</h1>
      <p class="sub">${res.questions.length} 道小题，不计时、不排名。只影响推荐，不阻挡课程；随时可以跳过。</p>
    </div>
    <button class="btn ghost" id="skip-btn">跳过摸底</button>
  </div>
  <form id="placement-form" class="stack" style="max-width:760px">
    ${res.questions.map((q, i) => `
      <section class="card">
        <div class="row between"><span class="badge line">第 ${i + 1} 题</span><span class="tiny muted">${esc(res.areas[i] ?? "")}</span></div>
        <div class="q-prompt mt-2">${renderBlocks(q.prompt)}</div>
        ${q.type === "choice" && q.options
          ? `<div class="q-options">${q.options.map((o) => `<label class="q-option"><input type="radio" name="${esc(q.id)}" value="${esc(o.id)}" /><span class="opt-id">${esc(o.id)}</span><span>${md(o.md)}</span></label>`).join("")}</div>`
          : `<div class="q-input-row"><input class="input" name="${esc(q.id)}" autocomplete="off" placeholder="填写答案" /></div>`}
        ${q.formatHint ? `<p class="help mt-1">格式：${esc(q.formatHint)}</p>` : ""}
      </section>`).join("")}
    <div class="row end">
      <button class="btn" type="button" id="skip-btn-2">以后再说</button>
      <button class="btn primary" type="submit">提交摸底</button>
    </div>
  </form>`;

  async function skip() {
    try {
      await api.post("/api/placement", { skipped: true });
      toast("已跳过摸底，推荐不会阻挡课程。");
      refreshBootstrap();
      navigate("/home");
    } catch {
      toast("暂时无法保存，稍后再试。");
    }
  }
  root.querySelector("#skip-btn")?.addEventListener("click", skip);
  root.querySelector("#skip-btn-2")?.addEventListener("click", skip);

  const form = root.querySelector("#placement-form") as HTMLFormElement;
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const fd = new FormData(form);
    const answers: Record<string, string> = {};
    for (const q of res.questions) {
      const v = fd.get(q.id);
      answers[q.id] = typeof v === "string" ? v : "";
    }
    const submit = form.querySelector("button[type=submit]") as HTMLButtonElement;
    submit.disabled = true;
    submit.textContent = "判分中……";
    try {
      const result = await api.post<{ score: number; total: number; detail: Array<{ questionId: string; correct: boolean; kpId: string }> }>("/api/placement", { answers });
      const weak = [...new Set(result.detail.filter((d) => !d.correct).map((d) => d.kpId))]
        .map((id) => data.kps.find((k) => k.id === id)?.title ?? id)
        .slice(0, 4);
      root.innerHTML = `
      <div class="practice-wrap">
        <div class="card finish-card">
          <div class="big">${result.score}/${result.total}</div>
          <h2>摸底完成</h2>
          <p class="muted">这只用于调整推荐，不会限制你打开任何课程。</p>
          ${weak.length ? `<p class="mt-2">建议先补：${weak.map((t) => `<span class="badge line">${esc(t)}</span>`).join(" ")}</p>` : `<p class="mt-2">基础覆盖不错，可以直接从「极限概念与基本计算」开始。</p>`}
          <div class="row mt-3" style="justify-content:center">
            <a class="btn primary" href="#/home">回到首页</a>
            <a class="btn" href="#/map">课程地图</a>
          </div>
        </div>
      </div>`;
      refreshBootstrap();
    } catch (err) {
      toast(err instanceof ApiError ? err.message : "提交失败。");
      submit.disabled = false;
      submit.textContent = "提交摸底";
    }
  });
}
