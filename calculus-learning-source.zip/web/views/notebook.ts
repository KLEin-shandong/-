import { api, ApiError } from "../api.ts";
import type { Bootstrap, NotebookItem, SessionPayload } from "../client-types.ts";
import { renderBlocks } from "../blocks.ts";
import { answerToText, DIFFICULTY_LABEL, esc, fmtDate, ROLE_LABEL, toast } from "../dom.ts";
import { md } from "../markdown.ts";
import { loadingHtml, errorHtml, navigate } from "../nav.ts";

export async function renderNotebook(root: HTMLElement, data: Bootstrap): Promise<void> {
  root.innerHTML = loadingHtml("正在整理错题……");
  let items: NotebookItem[];
  try {
    const res = await api.get<{ items: NotebookItem[] }>("/api/notebook");
    items = res.items;
  } catch (e) {
    root.innerHTML = errorHtml(e instanceof ApiError ? e.message : "无法载入错题本。");
    return;
  }

  const kps = data.kps;
  root.innerHTML = `
  <div class="page-head">
    <div>
      <div class="eyebrow">错题本</div>
      <h1>把错误留在这里，而不是留在心里</h1>
      <p class="sub">记录首次作答错误、使用过的提示和正确过程。掌握之后历史仍保留。</p>
    </div>
    <span class="badge amber">${items.length} 道待巩固</span>
  </div>
  <div class="filter-bar">
    <select class="select" id="f-module">
      <option value="">全部模块</option>
      ${data.modules.map((m) => `<option value="${m.id}">${esc(m.title)}</option>`).join("")}
    </select>
    <select class="select" id="f-kp">
      <option value="">全部知识点</option>
      ${kps.map((k) => `<option value="${k.id}">${esc(k.title)}</option>`).join("")}
    </select>
    <select class="select" id="f-review">
      <option value="">全部状态</option>
      <option value="due">已到期复习</option>
      <option value="notdue">未到期</option>
    </select>
    <select class="select" id="f-type">
      <option value="">全部题型</option>
      <option value="choice">选择题</option>
      <option value="fill">填空</option>
      <option value="steps">分步</option>
      <option value="calc">计算</option>
    </select>
  </div>
  <div id="wrong-list"></div>`;

  const list = root.querySelector("#wrong-list") as HTMLElement;
  const fModule = root.querySelector("#f-module") as HTMLSelectElement;
  const fKp = root.querySelector("#f-kp") as HTMLSelectElement;
  const fReview = root.querySelector("#f-review") as HTMLSelectElement;
  const fType = root.querySelector("#f-type") as HTMLSelectElement;

  function filtered(): NotebookItem[] {
    const today = new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Shanghai" });
    return items.filter((it) => {
      if (fModule.value && it.module !== fModule.value) return false;
      if (fKp.value && it.kpId !== fKp.value) return false;
      if (fType.value && it.type !== fType.value) return false;
      if (fReview.value === "due" && !(it.reviewDue && it.reviewDue <= today)) return false;
      if (fReview.value === "notdue" && it.reviewDue && it.reviewDue <= today) return false;
      return true;
    });
  }

  function draw() {
    const rows = filtered();
    if (rows.length === 0) {
      list.innerHTML = `<div class="card" style="text-align:center;padding:40px"><p class="muted">这里暂时没有符合条件的错题。</p><p class="small muted mt-1">做错的题会自动进入这里；也可以先去<a href="#/map">课程地图</a>继续练习。</p></div>`;
      return;
    }
    list.innerHTML = rows.map(card).join("");
    list.querySelectorAll<HTMLButtonElement>("[data-redo]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        btn.disabled = true;
        btn.textContent = "准备中……";
        try {
          const res = await api.post<SessionPayload>("/api/sessions/focus", { questionId: btn.dataset.redo });
          navigate(`/session/${res.session.id}`);
        } catch (e) {
          toast(e instanceof ApiError ? e.message : "暂时无法重做。");
          btn.disabled = false;
          btn.textContent = "重做此题";
        }
      });
    });
  }

  [fModule, fKp, fReview, fType].forEach((s) => s.addEventListener("change", draw));
  draw();
}

function card(it: NotebookItem): string {
  const lastAnswer = answerToText(it.lastAnswer);
  const hintText = it.hintLevel > 0 ? `用了 ${it.hintLevel} 级提示` : "未用提示";
  return `
  <article class="card wrong-card" style="margin-bottom:14px">
    <div class="q-head">
      <div>
        <div class="q-title">${esc(it.kpTitle)} · 第 ${it.version} 版</div>
        <div class="row mt-1">
          <span class="badge line">${DIFFICULTY_LABEL[it.difficulty] ?? it.difficulty}</span>
          <span class="badge line">${ROLE_LABEL[it.role] ?? it.role}</span>
          <span class="badge amber">${hintText}</span>
          ${it.solutionViewed ? `<span class="badge blue">看过解析</span>` : ""}
          ${it.reviewDue ? `<span class="badge line">复习 ${esc(it.reviewDue)}</span>` : ""}
        </div>
      </div>
      <span class="tiny muted">${fmtDate(it.lastAt)}</span>
    </div>
    <div class="mt-2 q-prompt">${renderBlocks(it.prompt)}</div>
    <div class="answers">
      <div class="answer-box bad"><div class="lbl">当时的答案</div><div>${esc(lastAnswer)}</div></div>
      <div class="answer-box good"><div class="lbl">正确过程</div><div>${renderBlocks(it.solution)}</div></div>
    </div>
    <details>
      <summary>提示（按层级）与历次练习（${it.attempts.length} 次）</summary>
      <div class="hint-stack">${it.hints.map((h, i) => `<div class="hint-item"><div class="hint-label">第 ${i + 1} 级</div><div>${md(h)}</div></div>`).join("")}</div>
      <div class="attempts">
        ${it.attempts.map((a) => `<div>${fmtDate(a.createdAt)} · ${a.correct ? "正确" : a.formatError ? "格式错误" : "错误"}${a.firstAttempt ? " · 首次" : ""}${a.hintLevel ? ` · 提示 ${a.hintLevel} 级` : ""}${a.solutionViewed ? " · 看过解析" : ""}</div>`).join("")}
      </div>
    </details>
    <div class="practice-actions">
      <button class="btn primary sm" data-redo="${esc(it.questionId)}">重做此题</button>
      <a class="btn sm" href="#/review-practice/${encodeURIComponent(it.kpId)}">做同类题</a>
      <a class="btn ghost sm" href="#/kp/${encodeURIComponent(it.kpId)}">回看讲解</a>
    </div>
  </article>`;
}
