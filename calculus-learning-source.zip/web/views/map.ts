import type { Bootstrap, KpSummary } from "../client-types.ts";
import { MASTERY_LABEL, MASTERY_CLASS, DIFFICULTY_LABEL, esc } from "../dom.ts";

export function renderMap(root: HTMLElement, data: Bootstrap): void {
  root.innerHTML = `
  <div class="page-head">
    <div>
      <div class="eyebrow">课程地图</div>
      <h1>从函数基础到导数入门</h1>
      <p class="sub">可以打开任何知识点。基础不足时会建议先补前置课，但不强制锁定。</p>
    </div>
    <div class="row">
      <span class="badge green"><span class="dot"></span>已掌握</span>
      <span class="badge amber"><span class="dot"></span>待验证 / 需巩固</span>
      <span class="badge blue"><span class="dot"></span>正在学习</span>
    </div>
  </div>

  ${data.modules.map((m) => {
    const kps = data.kps.filter((k) => k.module === m.id);
    const done = kps.filter((k) => k.mastery === "mastered").length;
    return `
    <section class="module-block">
      <div class="module-head">
        <h2>${esc(m.title)}</h2>
        <span>${esc(m.description)} · ${done}/${kps.length} 已掌握</span>
      </div>
      <div class="kp-list">
        ${kps.map((kp) => line(kp, kp.id === data.settings.classroomKpId)).join("")}
      </div>
    </section>`;
  }).join("")}

  <p class="tiny muted mt-4">状态说明：「待复习验证」表示最近 5 道不同题中已有 4 道独立答对；在之后的自然日独立答对一道复习题，才标为「已掌握」。</p>`;
}

function line(kp: KpSummary, current: boolean): string {
  const idx = String(kp.order).padStart(2, "0");
  const stateClass = kp.mastery === "mastered" ? "done" : kp.mastery === "needs_review" || kp.mastery === "pending_verify" ? "todo" : "";
  return `
  <a class="kp-line ${stateClass}" href="#/kp/${encodeURIComponent(kp.id)}">
    <span class="kp-index">${idx}</span>
    <span style="min-width:0">
      <h3>${esc(kp.title)} ${current ? `<span class="badge green" style="font-size:10.5px">课堂位置</span>` : ""}</h3>
      <p>${esc(kp.subtitle)}</p>
      <span class="badges">
        <span class="badge ${MASTERY_CLASS[kp.mastery] ?? "line"}">${MASTERY_LABEL[kp.mastery] ?? kp.mastery}</span>
        <span class="badge line">${DIFFICULTY_LABEL[kp.difficulty] ?? kp.difficulty}</span>
        ${pre(prereqsOf(kp))}
        ${kp.reviewDue ? `<span class="badge amber">待复习</span>` : ""}
      </span>
    </span>
  </a>`;
}

function prereqsOf(kp: KpSummary): string {
  return kp.prereqTitles.length ? `前置：${kp.prereqTitles.join("、")}` : "";
}

function pre(text: string): string {
  return text ? `<span class="badge line" style="font-weight:400">${esc(text)}</span>` : "";
}
