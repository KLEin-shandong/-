import { api, ApiError } from "../api.ts";
import type { Bootstrap, ReviewView } from "../client-types.ts";
import type { FormulaCard } from "../../shared/types.ts";
import { renderTex } from "../tex.ts";
import { md } from "../markdown.ts";
import { esc, toast } from "../dom.ts";
import { loadingHtml, errorHtml, refreshBootstrap } from "../nav.ts";

interface FormulaView extends FormulaCard {
  kpTitles: string[];
  review: ReviewView | null;
}

export async function renderReview(root: HTMLElement, data: Bootstrap): Promise<void> {
  root.innerHTML = loadingHtml("正在整理复习……");
  let reviews: { today: string; due: ReviewView[]; upcoming: ReviewView[] };
  let formulas: FormulaView[];
  try {
    [reviews, formulas] = await Promise.all([
      api.get<{ today: string; due: ReviewView[]; upcoming: ReviewView[] }>("/api/reviews"),
      api.get<{ formulas: FormulaView[] }>("/api/formulas").then((r) => r.formulas),
    ]);
  } catch (e) {
    root.innerHTML = errorHtml(e instanceof ApiError ? e.message : "无法载入复习。");
    return;
  }

  const dueKp = reviews.due.filter((r) => r.kind === "kp");
  const dueFormula = reviews.due.filter((r) => r.kind === "formula");
  const formulaIds = new Set(dueFormula.map((r) => r.targetId));
  const order = [...formulas].sort((a, b) => {
    const ad = formulaIds.has(a.id) ? 0 : 1;
    const bd = formulaIds.has(b.id) ? 0 : 1;
    return ad - bd || a.name.localeCompare(b.name);
  });

  root.innerHTML = `
  <div class="page-head">
    <div>
      <div class="eyebrow">复习</div>
      <h1>在忘记之前，再看一次</h1>
      <p class="sub">默认间隔 1、3、7、14 天。答错回到 1 天；模糊则维持阶段，明天再看。</p>
    </div>
    <span class="badge ${reviews.due.length ? "amber" : "green"}">${reviews.due.length ? `今天到期 ${reviews.due.length} 项` : "今天没有到期任务"}</span>
  </div>

  <div class="section-head"><h2>已到期的知识点</h2><span class="meta">${reviews.today}</span></div>
  <div class="review-list">
    ${dueKp.length ? dueKp.map((r) => `
      <div class="review-item">
        <div class="grow"><h3>${esc(r.title)}</h3><p>第 ${r.stage + 1} 阶段 · 到期 ${esc(r.dueDate)}${r.lastResult ? ` · 上次：${lastResultLabel(r.lastResult)}` : ""}</p></div>
        <a class="btn sm primary" href="#/review-practice/${encodeURIComponent(r.targetId)}">开始复习（6 题）</a>
        <a class="btn sm ghost" href="#/kp/${encodeURIComponent(r.targetId)}">回看讲解</a>
      </div>`).join("") : `<div class="card flat"><p class="muted small">没有到期的知识点复习。完成一节新课后，会自动安排下一次。</p></div>`}
  </div>

  <div class="section-head"><h2>公式复习</h2><span class="meta">先回想，再揭示；自评只影响公式卡安排</span></div>
  <div class="grid two">
    ${order.map((f) => formulaCard(f, formulaIds.has(f.id))).join("")}
  </div>

  ${reviews.upcoming.length ? `
  <div class="section-head"><h2>接下来</h2><span class="meta">按最早到期排序</span></div>
  <div class="card flat">
    ${reviews.upcoming.slice(0, 8).map((r) => `<div class="row between" style="padding:7px 0;border-bottom:1px solid var(--line)"><span>${esc(r.title)}</span><span class="small muted">${esc(r.dueDate)} · 第 ${r.stage + 1} 阶段</span></div>`).join("")}
  </div>` : ""}

  <p class="tiny muted mt-4">公式自评不会直接改变计算能力的掌握状态；知识点的掌握仍以不同题目的独立作答为准。</p>`;

  root.querySelectorAll<HTMLElement>("[data-formula]").forEach((card) => {
    const id = card.dataset.formula!;
    const hidden = card.querySelector<HTMLElement>(".hidden-answer");
    const reveal = card.querySelector<HTMLButtonElement>("[data-reveal]");
    const ratings = card.querySelector<HTMLElement>("[data-ratings]");
    reveal?.addEventListener("click", () => {
      hidden?.classList.add("revealed");
      if (reveal) reveal.hidden = true;
      if (ratings) ratings.hidden = false;
    });
    card.querySelectorAll<HTMLButtonElement>("[data-rate]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const result = btn.dataset.rate!;
        btn.disabled = true;
        try {
          const res = await api.post<{ review: ReviewView }>(`/api/formulas/${encodeURIComponent(id)}/result`, { result });
          toast(`已记录：${lastResultLabel(result)}，下次 ${res.review.dueDate}`);
          const meta = card.querySelector<HTMLElement>("[data-formula-meta]");
          if (meta) meta.textContent = `下次复习：${res.review.dueDate} · 第 ${res.review.stage + 1} 阶段`;
          refreshBootstrap();
        } catch (e) {
          toast(e instanceof ApiError ? e.message : "暂时无法记录。");
        } finally {
          btn.disabled = false;
        }
      });
    });
  });
}

function formulaCard(f: FormulaView, due: boolean): string {
  return `
  <article class="card formula-card" data-formula="${esc(f.id)}">
    <div class="row between">
      <h3>${md(f.name)}</h3>
      <span class="badge ${due ? "amber" : "line"}">${due ? "今天到期" : f.review ? `下次 ${esc(f.review.dueDate)}` : "未安排"}</span>
    </div>
    <p class="tiny muted mt-1">${esc(f.kpTitles.join("、"))}</p>
    <div class="hidden-answer">
      <div class="formula-tex">${renderTex(f.tex, true)}</div>
      <div class="formula-meta">
        <div><span class="k">适用条件</span>${md(f.conditions)}</div>
        <div><span class="k">一个例子</span>${md(f.example)}</div>
        <div><span class="k">常见误用</span>${md(f.misuse)}</div>
      </div>
    </div>
    <div class="row between">
      <button class="btn soft sm" data-reveal>想好了，揭示答案</button>
      <span class="tiny muted" data-formula-meta>${f.review ? `下次复习：${esc(f.review.dueDate)} · 第 ${f.review.stage + 1} 阶段` : "完成相关课程后自动安排"}</span>
    </div>
    <div class="rating-row" data-ratings hidden>
      <button class="btn sm primary" data-rate="good">记得</button>
      <button class="btn sm" data-rate="fuzzy">模糊</button>
      <button class="btn sm danger" data-rate="bad">不会</button>
    </div>
  </article>`;
}

function lastResultLabel(r: string): string {
  return r === "good" ? "记得" : r === "bad" ? "不会" : "模糊";
}
