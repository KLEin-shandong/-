import { esc } from "../dom.ts";

export function renderAgentDocs(root: HTMLElement): void {
  const origin = location.origin;
  root.innerHTML = `
  <div class="page-head">
    <div>
      <div class="eyebrow">外部 Agent 接口</div>
      <h1>让人或程序读懂当前学习状态</h1>
      <p class="sub">接口前缀 <code>/api/agent/v1</code>。只读学习上下文，或提交待审核的复习建议与候选题目；不能修改掌握状态或正式题库。</p>
    </div>
    <a class="btn primary" href="#/settings">创建令牌</a>
  </div>

  <div class="grid two">
    <section class="card">
      <h2 style="font-size:17px">认证与权限</h2>
      <ul class="prose small mt-2">
        <li>在<a href="#/settings">设置</a>中创建令牌，只显示一次。</li>
        <li>请求头：<code>Authorization: Bearer &lt;令牌&gt;</code>。</li>
        <li>权限：<code>learning:read</code> 读取上下文、知识点、复习任务；<code>suggestions:write</code> 提交建议。</li>
        <li>默认有效期 90 天；每令牌每分钟 60 次请求，超限返回 <code>429</code>。</li>
        <li>令牌绑定单个用户；已撤销或过期令牌返回 <code>401</code>。</li>
      </ul>
      <p class="tiny muted mt-2">私人托管若另有平台访问凭据，应与这里的应用令牌分开配置。平台凭据用于访问站点，应用令牌只用于本接口。</p>
    </section>

    <section class="card">
      <h2 style="font-size:17px">接口清单</h2>
      <div class="table-wrap flat mt-2" style="border:0">
        <table class="data-table" style="min-width:0">
          <tbody>
            <tr><td><code>GET /context</code></td><td>当前课堂位置、薄弱点、近期摘要、到期复习</td></tr>
            <tr><td><code>GET /knowledge-points</code></td><td>知识点、前置关系、掌握状态，游标分页</td></tr>
            <tr><td><code>GET /review-items</code></td><td>复习任务，默认只返回已到期</td></tr>
            <tr><td><code>POST /suggestions</code></td><td>提交复习建议或候选题目</td></tr>
          </tbody>
        </table>
      </div>
      <p class="tiny muted mt-2">分页：<code>limit</code> 默认 20、最多 100；响应中的 <code>nextCursor</code> 作为下一次的 <code>cursor</code>。</p>
      <p class="tiny mt-1"><a href="/openapi.yaml">下载 OpenAPI 文档（YAML）</a></p>
    </section>
  </div>

  <section class="card mt-3">
    <h2 style="font-size:17px">curl 示例</h2>
    <p class="small muted mt-1">以下示例不含真实令牌。站点地址：<code>${esc(origin)}</code>。</p>
    <pre class="suggestion" style="white-space:pre-wrap">export TOKEN="粘贴你的令牌"
export BASE="${esc(origin)}/api/agent/v1"

curl -s "$BASE/context" \\
  -H "Authorization: Bearer $TOKEN"

curl -s "$BASE/knowledge-points?limit=20" \\
  -H "Authorization: Bearer $TOKEN"

curl -s "$BASE/review-items?due=1&limit=20" \\
  -H "Authorization: Bearer $TOKEN"

curl -s -X POST "$BASE/suggestions" \\
  -H "Authorization: Bearer $TOKEN" \\
  -H "Content-Type: application/json" \\
  -d '{
    "kind": "review_recommendation",
    "content": {
      "text": "建议明天先复习左极限与右极限，再做分段函数连续性。",
      "kpIds": ["limit-one-sided", "limit-piecewise-continuity"]
    }
  }'</pre>
  </section>

  <section class="card mt-3">
    <h2 style="font-size:17px">最小 JavaScript 示例</h2>
    <pre class="suggestion" style="white-space:pre-wrap">const base = "${esc(origin)}/api/agent/v1";
const token = process.env.AGENT_TOKEN;

const res = await fetch(\`\${base}/context\`, {
  headers: { Authorization: \`Bearer \${token}\` }
});
if (!res.ok) {
  const err = await res.json();
  throw new Error(\`\${err.error.code}: \${err.error.message}\`);
}
const context = await res.json();
console.log(context.classroom, context.weakPoints);</pre>
  </section>

  <section class="card mt-3">
    <h2 style="font-size:17px">错误格式与建议边界</h2>
    <pre class="suggestion">{
  "error": {
    "code": "INVALID_REQUEST",
    "message": "请提供有效的知识点编号。"
  }
}</pre>
    <p class="small muted mt-2">候选题必须包含 <code>kpId</code>、<code>prompt</code>、<code>type</code>、<code>answer</code>、<code>solution</code>、<code>source</code>。提交后进入待采纳列表，第一版只能预览和审核，不参与正式计分；由维护者核验后写入版本化题库。</p>
    <p class="small muted mt-1">Agent 不能修改题库、掌握状态或原始作答；建议也不会自动改变学习进度。</p>
  </section>

  <p class="tiny muted mt-4">当前部署为自托管服务器。若要从外部网络调用，需要自行配置反向代理、VPN 或其他访问方式；本次交付未验证公网可达性，不会把私人站点改成公开访问。</p>`;
}
