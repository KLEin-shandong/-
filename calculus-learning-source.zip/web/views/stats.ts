import { api, ApiError, downloadExport } from "../api.ts";
import type { Bootstrap } from "../client-types.ts";
import { DIFFICULTY_LABEL, MASTERY_CLASS, MASTERY_LABEL, esc, toast } from "../dom.ts";
import { loadingHtml, errorHtml } from "../nav.ts";

interface StatRow {
  kpId: string;
  title: string;
  module: string;
  firstAttempts: number;
  independentCorrect: number;
  hintedCorrect: number;
  wrong: number;
  lastAt: string | null;
  difficulty: string;
  mastery: string;
}

export async function renderStats(root: HTMLElement, data: Bootstrap): Promise<void> {
  root.innerHTML = loadingHtml("正在汇总学习记录……");
  let res: { stats: StatRow[]; totals: { firstAttempts: number; independentCorrect: number; hintedCorrect: number; wrong: number }; dueCount: number };
  try {
    res = await api.get("/api/stats");
  } catch (e) {
    root.innerHTML = errorHtml(e instanceof ApiError ? e.message : "无法载入记录。");
    return;
  }

  const withWork = res.stats.filter((s) => s.firstAttempts > 0);
  const total = res.totals;
  const rate = total.firstAttempts ? Math.round((total.independentCorrect / total.firstAttempts) * 100) : 0;

  root.innerHTML = `
  <div class="page-head">
    <div>
      <div class="eyebrow">学习记录</div>
      <h1>看见具体做了什么</h1>
      <p class="sub">这里记录独立答对、提示后完成和待巩固，不用在线时长代替学习效果。</p>
    </div>
    <div class="row">
      <button class="btn" id="export-btn">导出 JSON</button>
      <a class="btn ghost" href="#/settings">设置</a>
    </div>
  </div>

  <div class="grid three">
    <div class="card stat-tile"><span class="num">${total.firstAttempts}</span><span class="lbl">首次有效作答</span></div>
    <div class="card stat-tile"><span class="num">${total.independentCorrect}</span><span class="lbl">独立答对 · ${rate}%</span></div>
    <div class="card stat-tile"><span class="num">${res.dueCount}</span><span class="lbl">到期复习</span></div>
  </div>

  <div class="section-head"><h2>按知识点</h2><span class="meta">${withWork.length} 个知识点有记录</span></div>
  <div class="table-wrap">
    <table class="data-table">
      <thead><tr><th>知识点</th><th>掌握状态</th><th>难度</th><th>首次作答</th><th>独立答对</th><th>提示后完成</th><th>答错</th></tr></thead>
      <tbody>
        ${res.stats.map((s) => `
          <tr>
            <td><a href="#/kp/${encodeURIComponent(s.kpId)}">${esc(s.title)}</a></td>
            <td><span class="badge ${MASTERY_CLASS[s.mastery] ?? "line"}">${MASTERY_LABEL[s.mastery] ?? s.mastery}</span></td>
            <td>${DIFFICULTY_LABEL[s.difficulty] ?? s.difficulty}</td>
            <td class="num">${s.firstAttempts}</td>
            <td class="num">${s.independentCorrect}</td>
            <td class="num">${s.hintedCorrect}</td>
            <td class="num">${s.wrong}</td>
          </tr>`).join("")}
      </tbody>
    </table>
  </div>

  <div class="card flat mt-3" style="display:flex;gap:16px;flex-wrap:wrap;align-items:center">
    <p class="small muted" style="flex:1;min-width:220px">「待复习验证」不是已掌握。需要在之后的自然日独立答对一道同知识点复习题，才标为已掌握（按 Asia/Shanghai 计算）。</p>
    <a class="btn" href="#/notebook">查看错题本</a>
    <a class="btn ghost" href="#/review">到期复习</a>
  </div>`;

  root.querySelector("#export-btn")?.addEventListener("click", async () => {
    try {
      await downloadExport();
      toast("已导出学习记录。");
    } catch {
      toast("导出失败，请稍后重试。");
    }
  });
}
