import { api, ApiError, downloadExport } from "../api.ts";
import type { Bootstrap } from "../client-types.ts";
import { esc, toast, confirmDialog } from "../dom.ts";
import { authChanged, refreshBootstrap } from "../nav.ts";

interface TokenRow {
  id: string;
  name: string;
  scopes: string;
  created_at: string;
  expires_at: string;
  revoked_at: string | null;
  last_used_at: string | null;
}
interface Suggestion {
  id: string;
  kind: string;
  content: unknown;
  status: string;
  createdAt: string;
}

export async function renderSettings(root: HTMLElement, data: Bootstrap): Promise<void> {
  root.innerHTML = `
  <div class="page-head">
    <div>
      <div class="eyebrow">设置</div>
      <h1>学习节奏与接入</h1>
      <p class="sub">课堂位置、练习时长、AI 与 Agent 令牌都在这里管理。</p>
    </div>
    <a class="btn ghost" href="#/agent">Agent 接口说明</a>
  </div>

  <div class="settings-grid">
    <section class="card">
      <h2 style="font-size:17px">学习设置</h2>
      <form id="settings-form" class="stack mt-2">
        <div class="field">
          <label for="classroom">课堂位置</label>
          <select class="select" id="classroom" name="classroomKpId">
            ${data.kps.map((k) => `<option value="${k.id}" ${k.id === data.settings.classroomKpId ? "selected" : ""}>${esc(k.title)}</option>`).join("")}
          </select>
          <span class="help">下次打开首页时从这节开始；掌握状态不会因此改变。</span>
        </div>
        <div class="field">
          <label for="minutes">每天学习时长（分钟）</label>
          <input class="input" id="minutes" name="defaultMinutes" type="number" min="10" max="90" step="5" value="${data.settings.defaultMinutes}" />
          <span class="help">只是建议，不强制计时，也不会因超时扣分。默认 90 分钟。</span>
        </div>
        <button class="btn primary" type="submit">保存设置</button>
      </form>
    </section>

    <section class="card">
      <h2 style="font-size:17px">AI 接入</h2>
      <div id="ai-status" class="mt-2"><span class="muted small">读取中……</span></div>
      <p class="tiny muted mt-2">AI 默认关闭。未配置、超时或返回不合格时，自动使用已有的讲解、提示与解析，不影响提交和判分。</p>
    </section>

    <section class="card" style="grid-column:1/-1">
      <div class="row between">
        <h2 style="font-size:17px">Agent 令牌</h2>
        <span class="badge line">learning:read / suggestions:write</span>
      </div>
      <p class="small muted mt-1">令牌用于外部 Agent 读取学习上下文或提交建议。只显示一次；数据库只存摘要。默认有效期 90 天，每令牌每分钟 60 次请求。</p>
      <div id="token-list" class="mt-2"><span class="muted small">读取中……</span></div>
      <form id="token-form" class="row mt-3" style="align-items:flex-end">
        <div class="field" style="flex:1;min-width:220px">
          <label for="token-name">新令牌名称</label>
          <input class="input" id="token-name" name="name" placeholder="例如：复习计划 Agent" maxlength="60" />
        </div>
        <label class="row small" style="gap:6px"><input type="checkbox" name="scope" value="learning:read" checked /> 读取学习数据</label>
        <label class="row small" style="gap:6px"><input type="checkbox" name="scope" value="suggestions:write" checked /> 提交建议</label>
        <button class="btn primary" type="submit">创建</button>
      </form>
      <div id="token-once"></div>
    </section>

    <section class="card" style="grid-column:1/-1">
      <div class="row between"><h2 style="font-size:17px">Agent 建议与候选题目</h2><span class="badge line">待采纳</span></div>
      <p class="small muted mt-1">候选题目第一版只能预览与审核，不参与正式计分；需要维护者核验后写入版本化题库。</p>
      <div id="suggestions" class="mt-2"><span class="muted small">读取中……</span></div>
    </section>

    <section class="card">
      <h2 style="font-size:17px">数据</h2>
      <p class="small muted mt-1">导出包含设置、知识点状态、会话、作答、复习任务与建议，不含密码或令牌摘要。</p>
      <div class="row mt-2">
        <button class="btn" id="export-btn">导出学习记录</button>
        <button class="btn danger" id="logout-btn">退出登录</button>
      </div>
    </section>

    <section class="card">
      <h2 style="font-size:17px">关于本站</h2>
      <p class="small muted mt-1">自托管版本。手机与电脑登录同一账号即可接续（需能访问同一服务器地址）。私人访问，不提供公开分享链接。</p>
      <p class="tiny muted mt-2">内容版本 ${esc(data.contentVersion)} · 默认课堂 ${esc(data.kps.find((k) => k.id === data.settings.classroomKpId)?.title ?? "")}</p>
    </section>
  </div>`;

  // 学习设置
  const form = root.querySelector("#settings-form") as HTMLFormElement;
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const fd = new FormData(form);
    try {
      await api.post("/api/settings", {
        classroomKpId: String(fd.get("classroomKpId")),
        defaultMinutes: Number(fd.get("defaultMinutes")),
      });
      toast("设置已保存。");
      refreshBootstrap();
    } catch (err) {
      toast(err instanceof ApiError ? err.message : "保存失败。");
    }
  });

  // AI 状态
  try {
    const ai = await api.get<{ enabled: boolean; configured: boolean; model: string | null; timeoutMs: number }>("/api/ai/status");
    const box = root.querySelector("#ai-status") as HTMLElement;
    if (!ai.enabled) {
      box.innerHTML = `<span class="badge line">未启用</span><p class="small muted mt-1">使用内置讲解、三级提示与完整解析。所有核心学习功能正常。</p>`;
    } else if (!ai.configured) {
      box.innerHTML = `<span class="badge amber">配置不完整</span><p class="small muted mt-1">缺少服务地址、模型或密钥，调用会自动降级为内置内容。</p>`;
    } else {
      box.innerHTML = `<span class="badge green">已配置</span><p class="small muted mt-1">模型 <code>${esc(ai.model ?? "")}</code>，超时 ${ai.timeoutMs / 1000} 秒。调用失败时自动降级；本页不发起真实调用，可用学习页的 AI 任务验证。</p>`;
    }
  } catch {
    /* 状态读取失败不阻断设置页 */
  }

  await loadTokens();
  await loadSuggestions();

  async function loadTokens() {
    const box = root.querySelector("#token-list") as HTMLElement;
    try {
      const res = await api.get<{ tokens: TokenRow[] }>("/api/agent-tokens");
      if (!res.tokens.length) {
        box.innerHTML = `<p class="small muted">还没有令牌。</p>`;
        return;
      }
      box.innerHTML = res.tokens.map((t) => {
        const scopes = safeScopes(t.scopes);
        return `<div class="token-row">
          <div><strong>${esc(t.name)}</strong><div class="tiny muted">${scopes.join(" · ")} · 创建 ${esc(t.created_at.slice(0, 10))} · 到期 ${esc(t.expires_at.slice(0, 10))}${t.last_used_at ? ` · 最近使用 ${esc(t.last_used_at.slice(0, 10))}` : ""}</div></div>
          ${t.revoked_at ? `<span class="badge red">已撤销</span>` : `<button class="btn sm danger" data-revoke="${esc(t.id)}" data-name="${esc(t.name)}">撤销</button>`}
        </div>`;
      }).join("");
      box.querySelectorAll<HTMLButtonElement>("[data-revoke]").forEach((btn) => {
        btn.addEventListener("click", async () => {
          const ok = await confirmDialog("撤销令牌", `撤销「${esc(btn.dataset.name ?? "")}」后，使用它的 Agent 将立即失效。此操作不可恢复。`, "撤销");
          if (!ok) return;
          try {
            await api.delete(`/api/agent-tokens/${encodeURIComponent(btn.dataset.revoke!)}`);
            toast("令牌已撤销。");
            await loadTokens();
          } catch (e) {
            toast(e instanceof ApiError ? e.message : "撤销失败。");
          }
        });
      });
    } catch {
      box.innerHTML = `<p class="small error-text">令牌列表读取失败。</p>`;
    }
  }

  const tokenForm = root.querySelector("#token-form") as HTMLFormElement;
  tokenForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const fd = new FormData(tokenForm);
    const name = String(fd.get("name") ?? "").trim();
    const scopes = fd.getAll("scope").map(String);
    if (!name) {
      toast("请给令牌起一个名字。");
      return;
    }
    if (!scopes.length) {
      toast("至少选择一个权限。");
      return;
    }
    try {
      const res = await api.post<{ token: string; expiresAt: string }>("/api/agent-tokens", { name, scopes });
      const once = root.querySelector("#token-once") as HTMLElement;
      once.innerHTML = `<div class="token-once"><strong>只显示这一次：</strong><div class="mt-1" id="new-token">${esc(res.token)}</div><div class="row mt-2"><button class="btn sm" id="copy-token">复制令牌</button><span class="tiny muted">到期 ${esc(res.expiresAt.slice(0, 10))}</span></div></div>`;
      once.querySelector("#copy-token")?.addEventListener("click", async () => {
        try {
          await navigator.clipboard.writeText(res.token);
          toast("已复制。");
        } catch {
          toast("浏览器未允许复制，请手动选择。");
        }
      });
      tokenForm.reset();
      await loadTokens();
    } catch (err) {
      toast(err instanceof ApiError ? err.message : "创建失败。");
    }
  });

  async function loadSuggestions() {
    const box = root.querySelector("#suggestions") as HTMLElement;
    try {
      const res = await api.get<{ suggestions: Suggestion[] }>("/api/suggestions?status=pending");
      if (!res.suggestions.length) {
        box.innerHTML = `<p class="small muted">没有待处理的建议。</p>`;
        return;
      }
      box.innerHTML = res.suggestions.map((s) => `
        <div class="suggestion">
          <div class="row between">
            <strong class="small">${s.kind === "question_candidate" ? "候选题目" : "复习建议"}</strong>
            <span class="tiny muted">${esc(s.createdAt.slice(0, 16).replace("T", " "))}</span>
          </div>
          <pre>${esc(JSON.stringify(s.content, null, 2))}</pre>
          <div class="row">
            <button class="btn sm primary" data-accept="${esc(s.id)}">采纳</button>
            <button class="btn sm ghost" data-ignore="${esc(s.id)}">忽略</button>
          </div>
        </div>`).join("");
      box.querySelectorAll<HTMLButtonElement>("[data-accept]").forEach((b) => b.addEventListener("click", () => reviewSuggestion(b.dataset.accept!, "accept", b)));
      box.querySelectorAll<HTMLButtonElement>("[data-ignore]").forEach((b) => b.addEventListener("click", () => reviewSuggestion(b.dataset.ignore!, "ignore", b)));
    } catch {
      box.innerHTML = `<p class="small error-text">建议列表读取失败。</p>`;
    }
  }

  async function reviewSuggestion(id: string, action: "accept" | "ignore", btn: HTMLButtonElement) {
    btn.disabled = true;
    try {
      await api.post(`/api/suggestions/${encodeURIComponent(id)}/review`, { action });
      toast(action === "accept" ? "已采纳，等待维护者核验。" : "已忽略。");
      await loadSuggestions();
      refreshBootstrap();
    } catch (e) {
      toast(e instanceof ApiError ? e.message : "操作失败。");
      btn.disabled = false;
    }
  }

  root.querySelector("#export-btn")?.addEventListener("click", async () => {
    try {
      await downloadExport();
      toast("已导出。");
    } catch {
      toast("导出失败。");
    }
  });

  root.querySelector("#logout-btn")?.addEventListener("click", async () => {
    const ok = await confirmDialog("退出登录", "本机该账号的草稿缓存会被清理，避免下一个账号看到旧数据。云端记录不会删除。", "退出");
    if (!ok) return;
    try {
      await api.post("/api/auth/logout");
    } catch {
      /* 即使请求失败也回到登录页 */
    }
    authChanged();
  });
}

function safeScopes(raw: string): string[] {
  try {
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? arr.map(String) : [];
  } catch {
    return [];
  }
}
