import { api, ApiError } from "../api.ts";
import type { Bootstrap, GradeResponse, PublicQuestion, SessionPayload } from "../client-types.ts";
import { renderBlocks } from "../blocks.ts";
import { md } from "../markdown.ts";
import { DIFFICULTY_LABEL, ROLE_LABEL, esc, toast, modal } from "../dom.ts";
import { loadingHtml, errorHtml, navigate, refreshBootstrap } from "../nav.ts";
import {
  draftKey,
  enqueue,
  getKV,
  listOutbox,
  removeOutbox,
  setKV,
  type OutboxItem,
} from "../localdb.ts";

type DraftMap = Record<string, unknown>;

interface PracticeOptions {
  kpId?: string;
  sessionId?: string;
  mode?: "learn" | "review";
}

interface ResultState {
  correct: boolean;
  formatError: boolean;
  message?: string;
  detail?: Array<{ label: string; correct: boolean; message?: string }>;
  independent: boolean;
  firstAttempt: boolean;
  state: GradeResponse["state"];
}

export async function renderPractice(root: HTMLElement, data: Bootstrap, opts: PracticeOptions): Promise<void> {
  root.innerHTML = loadingHtml("正在准备练习……");
  let payload: SessionPayload;
  try {
    if (opts.sessionId) {
      payload = await api.get<SessionPayload>(`/api/sessions/${encodeURIComponent(opts.sessionId)}`);
    } else {
      const kpId = opts.kpId ?? data.settings.classroomKpId;
      payload = await api.post<SessionPayload>("/api/sessions", { kpId, mode: opts.mode ?? "learn" });
    }
  } catch (e) {
    root.innerHTML = errorHtml(e instanceof ApiError ? e.message : "无法开始练习。");
    return;
  }

  const sessionId = payload.session.id;
  const userId = data.user.id;
  let revision = payload.session.revision;
  let index = Math.min(Math.max(payload.session.position, 0), Math.max(0, payload.questions.length - 1));
  let drafts: DraftMap = { ...payload.session.drafts };
  const local = await getKV<DraftMap>(draftKey(userId, sessionId));
  if (local) drafts = { ...drafts, ...local };
  const results = new Map<string, ResultState>();
  const hints = new Map<string, string[]>();
  const solutions = new Map<string, unknown>();
  const solutionSeen = new Set<string>();
  let solving = false;
  let disposed = false;
  let saveTimer: number | undefined;
  let retryTimer: number | undefined;
  let saveState: "saved" | "saving" | "pending" | "error" = "saved";

  for (const q of payload.questions) {
    if (q.hints?.length) hints.set(q.id, [...q.hints]);
    if (q.solutionViewed) solutionSeen.add(q.id);
    if (q.solution) solutions.set(q.id, q.solution);
  }

  root.innerHTML = `
  <div class="practice-wrap">
    <div class="practice-head">
      <div>
        <div class="eyebrow" style="color:var(--green-dark);font-size:12.5px;letter-spacing:.1em;font-weight:600">${payload.mode === "review" ? "复习练习" : "本节练习"}</div>
        <h1 style="font-size:22px;margin-top:2px">${esc(payload.kp?.title ?? "练习")}</h1>
      </div>
      <div class="row">
        <span class="sync" id="sync-state"><span class="dot"></span><span>已保存</span></span>
        <a class="btn sm ghost" href="#/home" id="pause-btn">暂停并返回</a>
      </div>
    </div>
    <div class="practice-head" style="margin-bottom:18px">
      <span class="small muted" id="progress-label"></span>
      <div class="progress"><i id="progress-bar"></i></div>
    </div>
    <div id="question-root"></div>
    <div class="pause-bar">
      <span>今天建议学习约 ${data.settings.defaultMinutes} 分钟，可以分次完成。没有强制计时，也不会因超时扣分。</span>
      <a href="#/kp/${encodeURIComponent(payload.kp?.id ?? "")}" class="small">回看讲解</a>
    </div>
  </div>`;

  const qRoot = root.querySelector("#question-root") as HTMLElement;
  const progressBar = root.querySelector("#progress-bar") as HTMLElement;
  const progressLabel = root.querySelector("#progress-label") as HTMLElement;
  const syncState = root.querySelector("#sync-state") as HTMLElement;

  window.addEventListener("hashchange", () => {
    disposed = true;
    if (saveTimer) window.clearTimeout(saveTimer);
    if (retryTimer) window.clearTimeout(retryTimer);
  }, { once: true });
  window.addEventListener("online", () => { void replayQueue(); }, { once: true });

  function setSync(state: typeof saveState) {
    saveState = state;
    if (!syncState) return;
    const label = state === "saved" ? "已保存" : state === "saving" ? "保存中" : state === "pending" ? "待同步" : "保存失败";
    syncState.className = `sync ${state}`;
    syncState.innerHTML = `<span class="dot"></span><span>${label}</span>`;
  }

  function currentQuestion(): PublicQuestion {
    return payload.questions[index];
  }

  function updateProgress() {
    const total = payload.questions.length;
    const n = Math.min(index + 1, total);
    progressLabel.textContent = `第 ${n} / ${total} 题`;
    progressBar.style.width = `${(n / total) * 100}%`;
  }

  function collect(q: PublicQuestion): { kind: string; value?: string; values?: Record<string, string> } | null {
    const card = qRoot.querySelector(".q-card");
    if (!card) return null;
    if (q.type === "choice") {
      const checked = card.querySelector<HTMLInputElement>("input[name=q-option]:checked");
      if (!checked) return null;
      return { kind: "choice", value: checked.value };
    }
    if (q.type === "steps") {
      const values: Record<string, string> = {};
      for (const label of q.stepLabels ?? []) {
        const input = card.querySelector<HTMLInputElement>(`[data-step="${cssEscape(label)}"]`);
        values[label] = input?.value ?? "";
      }
      return { kind: "steps", values };
    }
    const input = card.querySelector<HTMLInputElement>("#q-answer");
    if (!input) return null;
    return { kind: "number", value: input.value };
  }

  function hasAnyInput(a: { kind: string; value?: string; values?: Record<string, string> } | null): boolean {
    if (!a) return false;
    if (a.kind === "steps") return Object.values(a.values ?? {}).some((v) => String(v).trim() !== "");
    return String(a.value ?? "").trim() !== "";
  }

  function onInputChange() {
    const q = currentQuestion();
    const a = collect(q);
    if (a) {
      if (a.kind === "steps") drafts[q.id] = { kind: "steps", values: a.values };
      else drafts[q.id] = { kind: a.kind, value: a.value };
    }
    void persist(false);
  }

  function renderQuestion() {
    const q = currentQuestion();
    updateProgress();
    const draft = drafts[q.id] as Record<string, unknown> | undefined;
    const result = results.get(q.id);
    const shownHints = hints.get(q.id) ?? [];
    const solution = solutions.get(q.id);
    const isCorrect = result?.correct === true;
    const isWrong = result ? !result.correct && !result.formatError : q.answered && q.correct === false;
    const isFormat = result?.formatError === true;

    const options = q.options?.map((o) => {
      const selected = draft?.kind === "choice" && draft.value === o.id;
      return `<label class="q-option ${selected ? "selected" : ""}">
        <input type="radio" name="q-option" value="${esc(o.id)}" ${selected ? "checked" : ""} ${isCorrect ? "disabled" : ""} />
        <span class="opt-id">${esc(o.id)}</span><span>${md(o.md)}</span>
      </label>`;
    }).join("") ?? "";

    let fields = "";
    if (q.type === "choice") {
      fields = `<div class="q-options">${options}</div>`;
    } else if (q.type === "steps") {
      fields = `<div class="steps-inputs">${(q.stepLabels ?? []).map((label) => {
        const v = draft?.kind === "steps" ? String((draft.values as Record<string, string> | undefined)?.[label] ?? "") : "";
        return `<div class="step-input"><label for="step-${esc(label)}">${esc(label)}</label><input class="input" id="step-${esc(label)}" data-step="${esc(label)}" value="${esc(v)}" autocomplete="off" ${isCorrect ? "disabled" : ""} /></div>`;
      }).join("")}</div>`;
    } else {
      const v = draft && typeof draft.value === "string" ? draft.value : "";
      fields = `<div class="q-input-row"><input class="input" id="q-answer" value="${esc(v)}" autocomplete="off" inputmode="text" placeholder="在这里填写答案" ${isCorrect ? "disabled" : ""} /><button class="btn primary" id="submit-btn">提交答案</button></div>`;
    }

    const prereq = data.kps.find((k) => k.id === payload.session.kpId);
    const baseLinks = prereq?.prereqs.length
      ? `<div class="row mt-2"><span class="tiny muted">这一步不懂？</span>${prereq.prereqs.map((id, i) => `<a class="btn sm ghost" href="#/kp/${encodeURIComponent(id)}">补一下：${esc(prereq.prereqTitles[i] ?? id)}</a>`).join("")}</div>`
      : "";

    qRoot.innerHTML = `
    <article class="card q-card">
      <div class="q-meta">
        <span class="badge line">${ROLE_LABEL[q.role] ?? q.role}</span>
        <span class="badge line">${DIFFICULTY_LABEL[q.difficulty] ?? q.difficulty}</span>
        ${hints.get(q.id)?.length ? `<span class="badge amber">已用提示 ${hints.get(q.id)!.length} 级</span>` : ""}
        ${solutionSeen.has(q.id) ? `<span class="badge blue">已看解析</span>` : ""}
        ${result?.independent ? `<span class="badge green">独立答对</span>` : ""}
      </div>
      <div class="q-prompt">${renderBlocks(q.prompt)}</div>
      ${fields}
      ${q.formatHint ? `<p class="help mt-2">格式：${esc(q.formatHint)}</p>` : ""}
      ${q.type !== "choice" ? `<div class="practice-actions" style="margin-top:12px">${q.type === "steps" ? `<button class="btn primary" id="submit-btn">提交答案</button>` : ""}<button class="btn sm ghost" id="hint-btn" ${shownHints.length >= 3 ? "disabled" : ""}>${shownHints.length ? "再提示一点" : "给我一个提示"}</button><button class="btn sm ghost" id="solution-btn">看完整解析</button></div>` : `<div class="practice-actions" style="margin-top:12px"><button class="btn primary" id="submit-btn">提交答案</button><button class="btn sm ghost" id="hint-btn" ${shownHints.length >= 3 ? "disabled" : ""}>${shownHints.length ? "再提示一点" : "给我一个提示"}</button><button class="btn sm ghost" id="solution-btn">看完整解析</button></div>`}
      <div class="hint-stack" id="hint-stack">${shownHints.map((h, i) => `<div class="hint-item"><div class="hint-label">第 ${i + 1} 级提示</div><div>${md(h)}</div></div>`).join("")}</div>
      <div id="feedback-root">${feedbackHtml(result ?? null, isWrong, isFormat, q)}</div>
      ${solution ? `<div class="solution-box"><h4>完整解析</h4>${renderBlocks(solution as never)}</div>` : ""}
      ${baseLinks}
    </article>`;

    // 绑定输入与按钮
    qRoot.querySelectorAll<HTMLInputElement>("input[name=q-option]").forEach((input) => {
      input.addEventListener("change", () => {
        qRoot.querySelectorAll(".q-option").forEach((o) => o.classList.remove("selected"));
        input.closest(".q-option")?.classList.add("selected");
        onInputChange();
      });
    });
    qRoot.querySelectorAll<HTMLInputElement>(".input").forEach((input) => {
      input.addEventListener("input", onInputChange);
      input.addEventListener("keydown", (e) => {
        if (e.key === "Enter" && !e.isComposing) {
          e.preventDefault();
          void submit();
        }
      });
    });
    qRoot.querySelector("#hint-btn")?.addEventListener("click", () => void requestHint());
    qRoot.querySelector("#solution-btn")?.addEventListener("click", () => void requestSolution());
    qRoot.querySelector("#submit-btn")?.addEventListener("click", () => void submit());
    qRoot.querySelector("#next-btn")?.addEventListener("click", () => void nextQuestion());
    qRoot.querySelector("#retry-btn")?.addEventListener("click", () => {
      const qq = currentQuestion();
      results.delete(qq.id);
      renderQuestion();
    });
    qRoot.querySelector("#finish-btn")?.addEventListener("click", () => void complete());
    (qRoot.querySelector("#q-answer, input[name=q-option]:checked, input[data-step]") as HTMLElement | null)?.focus?.();
  }

  function feedbackHtml(r: ResultState | null, isWrong: boolean, isFormat: boolean, q: PublicQuestion): string {
    if (!r) {
      if (isWrong) {
        return `<div class="feedback bad"><strong>这道题第一次作答不正确</strong>可以再试一次，或者看提示与解析。第一次作答的结果已经记录。</div>
        <div class="practice-actions"><button class="btn primary sm" id="retry-btn">再试一次</button>${index < payload.questions.length - 1 ? `<button class="btn sm" id="next-btn">下一题</button>` : `<button class="btn sm" id="finish-btn">完成本节</button>`}</div>`;
      }
      if (q.answered && q.correct) {
        return `<div class="feedback ok"><strong>这道题已答对</strong>可以继续下一题。</div><div class="practice-actions"><button class="btn primary" id="${index < payload.questions.length - 1 ? "next-btn" : "finish-btn"}">${index < payload.questions.length - 1 ? "下一题" : "完成本节"}</button></div>`;
      }
      return "";
    }
    if (r.formatError) {
      return `<div class="feedback info"><strong>格式需要调整</strong>${esc(r.message ?? "请按题目要求的格式填写。")}格式错误不计入答错统计。</div>`;
    }
    if (r.correct) {
      const extra = r.independent ? "首次作答、未用提示、未看解析。" : "用了提示或看过解析，不计为独立答对。";
      return `<div class="feedback ok"><strong>答对了</strong>${extra}${r.state ? `<div class="tiny mt-1">${esc(r.state.moved)}</div>` : ""}</div>
      <div class="practice-actions"><button class="btn primary" id="${index < payload.questions.length - 1 ? "next-btn" : "finish-btn"}">${index < payload.questions.length - 1 ? "下一题" : "完成本节"}</button></div>`;
    }
    const detail = r.detail?.length
      ? `<ul class="small">${r.detail.map((d) => `<li>${d.correct ? "✓" : "✗"} ${esc(d.label)}${d.message ? `：${esc(d.message)}` : ""}</li>`).join("")}</ul>`
      : "";
    return `<div class="feedback bad"><strong>还不对</strong>先对照提示找出第一个不同的步骤，再试一次。${detail}</div>
    <div class="practice-actions"><button class="btn primary sm" id="retry-btn">再试一次</button>${index < payload.questions.length - 1 ? `<button class="btn sm" id="next-btn">下一题</button>` : `<button class="btn sm" id="finish-btn">完成本节</button>`}</div>`;
  }

  async function persist(immediate: boolean): Promise<void> {
    if (saveTimer) window.clearTimeout(saveTimer);
    setSync("saving");
    const run = async () => {
      try {
        const res = await api.post<SessionPayload>(`/api/sessions/${sessionId}/state`, {
          revision,
          position: index,
          drafts,
        });
        revision = res.session.revision;
        await setKV(draftKey(userId, sessionId), drafts);
        setSync("saved");
      } catch (e) {
        if (e instanceof ApiError && e.code === "REVISION_CONFLICT") {
          setSync("error");
          showConflict(e);
          return;
        }
        setSync("pending");
        await setKV(draftKey(userId, sessionId), drafts);
        if (retryTimer) window.clearTimeout(retryTimer);
        retryTimer = window.setTimeout(() => { if (!disposed) void persist(true); }, 8000);
      }
    };
    if (immediate) await run();
    else saveTimer = window.setTimeout(() => { if (!disposed) void run(); }, 1000);
  }

  function showConflict(e: ApiError): void {
    const snapshot = (e.data as { session?: SessionPayload } | null)?.session;
    modal({
      title: "云端会话已在其他设备更新",
      body: `<p class="small muted">为避免覆盖另一台设备上的内容，本次没有写入云端。你可以恢复云端版本，或把本机内容另存为一个新会话。</p>`,
      actions: [
        {
          label: "恢复云端",
          kind: "primary",
          onClick: async () => {
            if (snapshot) {
              payload = snapshot;
              revision = snapshot.session.revision;
              index = Math.min(snapshot.session.position, snapshot.questions.length - 1);
              drafts = { ...snapshot.session.drafts };
              await setKV(draftKey(userId, sessionId), drafts);
              renderQuestion();
            } else location.reload();
          },
        },
        {
          label: "保留本地另开会话",
          kind: "ghost",
          onClick: async () => {
            const forked = await api.post<SessionPayload>(`/api/sessions/${sessionId}/fork`, { position: index, drafts });
            await setKV(draftKey(userId, forked.session.id), drafts);
            navigate(`/session/${forked.session.id}`);
          },
        },
      ],
    });
  }

  async function requestHint(): Promise<void> {
    const q = currentQuestion();
    const used = hints.get(q.id)?.length ?? 0;
    if (used >= 3) return;
    try {
      const res = await api.post<{ level: number; content: string }>(`/api/sessions/${sessionId}/hint`, {
        sessionId,
        questionId: q.id,
        level: used + 1,
      });
      const list = hints.get(q.id) ?? [];
      list.push(res.content);
      hints.set(q.id, list);
      q.hintLevel = Math.max(q.hintLevel, res.level);
      renderQuestion();
    } catch (e) {
      toast(e instanceof ApiError ? e.message : "提示暂时不可用。");
    }
  }

  async function requestSolution(): Promise<void> {
    const q = currentQuestion();
    try {
      const res = await api.post<{ solution: unknown }>(`/api/sessions/${sessionId}/solution`, { sessionId, questionId: q.id });
      solutions.set(q.id, res.solution);
      solutionSeen.add(q.id);
      renderQuestion();
    } catch (e) {
      toast(e instanceof ApiError ? e.message : "解析暂时不可用。");
    }
  }

  async function submit(): Promise<void> {
    if (solving) return;
    const q = currentQuestion();
    const answer = collect(q);
    if (!hasAnyInput(answer)) {
      toast("请先填写答案。");
      (qRoot.querySelector("#q-answer") as HTMLInputElement | null)?.focus();
      return;
    }
    solving = true;
    const btn = qRoot.querySelector("#submit-btn") as HTMLButtonElement | null;
    if (btn) {
      btn.disabled = true;
      btn.textContent = "判分中……";
    }
    const clientId = crypto.randomUUID();
    const payloadBody = {
      clientId,
      sessionId,
      questionId: q.id,
      questionVersion: q.version,
      answer,
    };
    try {
      const res = await api.post<GradeResponse>("/api/submissions", payloadBody);
      applyResult(q, res);
      refreshBootstrap();
    } catch (e) {
      if (e instanceof ApiError && e.code === "NETWORK") {
        const item: OutboxItem = {
          id: clientId,
          userId,
          kind: "submission",
          payload: payloadBody as unknown as Record<string, unknown>,
          createdAt: new Date().toISOString(),
        };
        await enqueue(item);
        setSync("pending");
        qRoot.querySelector("#feedback-root")!.innerHTML = `<div class="feedback info"><strong>提交已保存在本机</strong>当前网络不可用，联网后会自动判分；同一提交不会重复计分。</div>`;
        startRetry();
      } else {
        toast(e instanceof ApiError ? e.message : "提交失败。");
      }
    } finally {
      solving = false;
      const b = qRoot.querySelector("#submit-btn") as HTMLButtonElement | null;
      if (b) {
        b.disabled = false;
        b.textContent = "提交答案";
      }
    }
  }

  function applyResult(q: PublicQuestion, res: GradeResponse): void {
    const r: ResultState = {
      correct: res.correct,
      formatError: res.formatError,
      message: res.message,
      detail: res.detail,
      independent: res.independent,
      firstAttempt: res.firstAttempt,
      state: res.state,
    };
    q.answered = true;
    q.correct = res.correct;
    results.set(q.id, r);
    if (res.state) {
      toast(res.state.justMastered ? "已达到掌握标准" : `难度：${DIFFICULTY_LABEL[res.state.difficulty] ?? res.state.difficulty}`);
    }
    renderQuestion();
  }

  function startRetry(): void {
    if (retryTimer) window.clearTimeout(retryTimer);
    retryTimer = window.setTimeout(() => { if (!disposed) void replayQueue(); }, 6000);
  }

  async function replayQueue(): Promise<void> {
    if (disposed || !navigator.onLine) {
      if (!disposed) startRetry();
      return;
    }
    const items = (await listOutbox(userId)).filter((i) => i.kind === "submission");
    for (const item of items) {
      try {
        const res = await api.post<GradeResponse>("/api/submissions", item.payload);
        await removeOutbox(item.id);
        const qid = String(item.payload.questionId ?? "");
        const q = payload.questions.find((x) => x.id === qid);
        if (q) {
          applyResult(q, res);
          refreshBootstrap();
        }
      } catch (e) {
        if (e instanceof ApiError && e.code === "NETWORK") {
          startRetry();
          return;
        }
        if (e instanceof ApiError && (e.status === 409 || e.status === 404)) {
          await removeOutbox(item.id);
          toast("有一条未同步提交对应的题目版本已更新，已跳过。");
          continue;
        }
        await removeOutbox(item.id);
      }
    }
    if (items.length) setSync("saved");
  }

  async function nextQuestion(): Promise<void> {
    await persist(true);
    if (index < payload.questions.length - 1) {
      index++;
      await persist(true);
      renderQuestion();
      window.scrollTo({ top: 0, behavior: "smooth" });
    } else {
      await complete();
    }
  }

  async function complete(): Promise<void> {
    const queue = await listOutbox(userId);
    if (queue.some((q) => q.kind === "submission")) {
      toast("还有未同步的提交，请联网后再完成本节。");
      return;
    }
    try {
      const res = await api.post<{
        state: { difficulty: string; mastery: string };
        reviewResult: string | null;
        nextReview: { dueDate: string; stage: number } | null;
        stats: { firstAttempts: number; independentCorrect: number; wrong: number };
      }>(`/api/sessions/${sessionId}/complete`, { revision });
      renderFinish(res);
      refreshBootstrap();
    } catch (e) {
      toast(e instanceof ApiError ? e.message : "暂时无法完成本节。");
    }
  }

  function renderFinish(res: {
    state: { difficulty: string; mastery: string };
    reviewResult: string | null;
    nextReview: { dueDate: string; stage: number } | null;
    stats: { firstAttempts: number; independentCorrect: number; wrong: number };
  }): void {
    const masteryLabel: Record<string, string> = {
      not_started: "未开始", learning: "正在学习", needs_review: "需要巩固", pending_verify: "待复习验证", mastered: "已掌握",
    };
    const reviewLabel: Record<string, string> = { good: "记得", fuzzy: "有点模糊", bad: "还不会" };
    root.innerHTML = `
    <div class="practice-wrap">
      <div class="card finish-card">
        <div class="big">✓</div>
        <h2>${payload.mode === "review" ? "复习完成" : "本节完成"}</h2>
        <p class="muted">${payload.mode === "review" ? "这次复习的结果已用于安排下一次间隔。" : "今天的练习已经保存。下一次复习会按间隔安排。"}</p>
        <div class="finish-stats">
          <div><span class="n">${res.stats.firstAttempts}</span><span class="l">首次作答</span></div>
          <div><span class="n">${res.stats.independentCorrect}</span><span class="l">独立答对</span></div>
          <div><span class="n">${res.stats.wrong}</span><span class="l">答错</span></div>
        </div>
        <div class="row" style="justify-content:center">
          <span class="badge blue">${masteryLabel[res.state.mastery] ?? res.state.mastery}</span>
          <span class="badge line">难度 ${DIFFICULTY_LABEL[res.state.difficulty] ?? res.state.difficulty}</span>
          ${res.reviewResult ? `<span class="badge amber">复习自评：${reviewLabel[res.reviewResult] ?? res.reviewResult}</span>` : ""}
          ${res.nextReview ? `<span class="badge line">下次复习 ${esc(res.nextReview.dueDate)}</span>` : ""}
        </div>
        <div class="row mt-3" style="justify-content:center">
          <a class="btn primary" href="#/home">返回首页</a>
          <a class="btn" href="#/map">课程地图</a>
          <a class="btn ghost" href="#/review">去复习</a>
        </div>
      </div>
    </div>`;
  }

  root.querySelector("#pause-btn")?.addEventListener("click", async (e) => {
    e.preventDefault();
    await persist(true);
    navigate("/home");
  });

  renderQuestion();
  void replayQueue();
}

function cssEscape(s: string): string {
  return s.replace(/["\\]/g, "\\$&");
}
