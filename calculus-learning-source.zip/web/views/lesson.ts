import { api, ApiError } from "../api.ts";
import type { Bootstrap, KnowledgePointDetail } from "../client-types.ts";
import { renderBlocks } from "../blocks.ts";
import { renderTex } from "../tex.ts";
import { md } from "../markdown.ts";
import { MASTERY_LABEL, MASTERY_CLASS, DIFFICULTY_LABEL, esc } from "../dom.ts";
import { loadingHtml, errorHtml } from "../nav.ts";

export async function renderLesson(root: HTMLElement, kpId: string, data: Bootstrap): Promise<void> {
  root.innerHTML = loadingHtml();
  let detail: KnowledgePointDetail;
  try {
    detail = await api.get<KnowledgePointDetail>(`/api/knowledge-points/${encodeURIComponent(kpId)}`);
  } catch (e) {
    root.innerHTML = errorHtml(e instanceof ApiError ? e.message : "无法载入知识点。");
    return;
  }
  const { kp, state, review } = detail;
  const moduleInfo = data.modules.find((m) => m.id === kp.module);
  const last = data.lastSession;
  const hasActive = last?.kpId === kp.id && last.status === "active";
  const sourceKind: Record<string, string> = { course: "课件整理", supplement: "基础补充", original: "原创练习" };

  root.innerHTML = `
  <div class="page-head">
    <div>
      <div class="eyebrow">${esc(moduleInfo?.title ?? "")} · 第 ${kp.order} 节</div>
      <h1 class="lesson-title">${esc(kp.title)}</h1>
      <p class="sub">${esc(kp.subtitle)}</p>
      <div class="row mt-2">
        <span class="badge ${MASTERY_CLASS[state.mastery] ?? "line"}">${MASTERY_LABEL[state.mastery] ?? state.mastery}</span>
        <span class="badge line">${DIFFICULTY_LABEL[state.difficulty] ?? state.difficulty}</span>
        <span class="badge line">约 ${kp.minutes} 分钟</span>
        ${review ? `<span class="badge ${review.dueDate <= new Date().toISOString().slice(0, 10) ? "amber" : "line"}">复习 ${esc(review.dueDate)}</span>` : ""}
      </div>
    </div>
    <div class="row">
      <a class="btn ghost" href="#/map">返回地图</a>
      <a class="btn primary" href="#/practice/${encodeURIComponent(kp.id)}">${hasActive ? "继续练习" : "开始练习"} →</a>
    </div>
  </div>

  ${data.dueReviewCount > 0 ? `
  <div class="card flat" style="display:flex;gap:14px;align-items:center;flex-wrap:wrap;margin-bottom:18px;background:var(--amber-soft);border-color:#eedcc6">
    <span style="flex:1;min-width:220px" class="small">今天有 ${data.dueReviewCount} 项到期复习。先完成复习，再开始新内容，记忆会更稳。</span>
    <a class="btn sm" href="#/review">去复习</a>
  </div>` : ""}

  <div class="lesson-layout">
    <article class="lesson-body">
      <section class="objectives">
        <h3>学完能做什么</h3>
        <ul>${kp.objectives.map((o) => `<li>${md(o)}</li>`).join("")}</ul>
      </section>
      ${renderBlocks(kp.blocks)}
      <section class="summary-card mt-3" style="background:var(--green-soft);border-color:#d3e4dc">
        <h3 style="font-size:14px;color:var(--green-dark);letter-spacing:.04em">本节小结</h3>
        <ul>${kp.summary.map((s) => `<li>${md(s)}</li>`).join("")}</ul>
      </section>
      <div class="row between mt-3">
        <a class="btn primary" href="#/practice/${encodeURIComponent(kp.id)}">${hasActive ? "继续练习" : "开始练习"}（${detail.questionCount} 道）</a>
        <a class="btn ghost" href="#/map">返回地图</a>
      </div>
    </article>

    <aside class="side-panel">
      <div class="card flat">
        <h3>练习安排</h3>
        <p class="small muted mt-1">建议 ${kp.minutes} 分钟。题目会按你的答题情况调整难度；随时可以暂停，草稿会保存。</p>
        <a class="btn primary block mt-2" href="#/practice/${encodeURIComponent(kp.id)}">${hasActive ? "继续练习" : "开始练习"}</a>
      </div>

      ${kp.prereqs.length ? `
      <div class="card flat">
        <h3>需要的前置基础</h3>
        <div class="stack mt-2">
          ${kp.prereqs.map((id, i) => `<a class="btn sm soft block" href="#/kp/${encodeURIComponent(id)}">补一下：${esc(kp.prereqTitles[i] ?? id)}</a>`).join("")}
        </div>
        <p class="tiny muted mt-2">做完基础小课后，回到这里继续原题。</p>
      </div>` : ""}

      ${kp.formulas.length ? `
      <div class="card flat">
        <h3>公式卡</h3>
        ${kp.formulas.map((f) => `
          <div class="mt-2">
            <div class="small" style="font-weight:600">${md(f.name)}</div>
            <div class="math-block" style="font-size:18px;padding:10px 6px;margin:6px 0">${renderTex(f.tex, true)}</div>
            <p class="tiny muted">${md(f.conditions)}</p>
          </div>`).join("")}
      </div>` : ""}

      <div class="card flat">
        <h3>来源</h3>
        <ul class="small muted" style="margin-top:6px">
          ${kp.source.map((s) => `<li>${esc(sourceKind[s.kind] ?? s.kind)}：${esc(s.file)}${s.pages ? ` 第 ${esc(s.pages)} 页` : ""}${s.note ? `（${esc(s.note)}）` : ""}</li>`).join("")}
        </ul>
        <p class="tiny muted mt-2">课件为图片型 PDF，页码对应原始文件；补充内容已明确标记。</p>
      </div>
    </aside>
  </div>`;
}
