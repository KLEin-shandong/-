import { api, ApiError } from "../api.ts";
import { authChanged } from "../nav.ts";

export function renderLogin(root: HTMLElement): void {
  root.innerHTML = `
  <div class="auth-wrap">
    <section class="auth-intro">
      <div>
        <div class="brand" style="color:#f4f1e9">
          <span class="brand-mark" style="background:rgba(255,255,255,.16)">∫</span>
          <span>微积分 · 一步一步<small style="color:#bcd3c7">CALCULUS, STEP BY STEP</small></span>
        </div>
        <h1 class="mt-4">先理解一个小知识点，再独立做出来。</h1>
        <p>从“趋近”开始，不要求先补完所有高中内容。遇到基础障碍，可以跳过去补，再回来接着做。</p>
        <div class="quote">理解 → 跟着做 → 独立做 → 找错误 → 隔天复习 → 接着学</div>
      </div>
      <p class="small" style="color:#bcd3c7">私人学习站点 · 数据保存在自己的服务器</p>
    </section>
    <section class="auth-panel">
      <div class="auth-form">
        <div class="tabs" role="tablist">
          <button class="active" data-tab="login" role="tab">登录</button>
          <button data-tab="register" role="tab">创建账号</button>
        </div>
        <h2 id="auth-title">继续上次的位置</h2>
        <p class="sub" id="auth-sub">登录后，手机和电脑可以接着同一个进度。</p>
        <form id="auth-form" class="stack" novalidate>
          <div class="field">
            <label for="username">用户名</label>
            <input class="input" id="username" name="username" autocomplete="username" required minlength="2" maxlength="32" />
          </div>
          <div class="field">
            <label for="password">密码</label>
            <input class="input" id="password" name="password" type="password" autocomplete="current-password" required minlength="8" />
            <span class="help" id="pw-help">至少 8 位。</span>
          </div>
          <div class="field" id="signup-wrap" hidden>
            <label for="signupCode">邀请码（如站点要求）</label>
            <input class="input" id="signupCode" name="signupCode" autocomplete="off" />
            <span class="help">第一个账号不需要邀请码。若站点已设置邀请码，请向维护者获取。</span>
          </div>
          <p class="error-text" id="auth-error" hidden></p>
          <button class="btn primary block" id="auth-submit" type="submit">登录</button>
        </form>
        <p class="tiny muted mt-3">不配置 AI 时，讲解、提示、判分与复习仍可完整使用。</p>
      </div>
    </section>
  </div>`;

  let mode: "login" | "register" = "login";
  const tabs = [...root.querySelectorAll<HTMLButtonElement>(".tabs button")];
  const title = root.querySelector("#auth-title") as HTMLElement;
  const sub = root.querySelector("#auth-sub") as HTMLElement;
  const signupWrap = root.querySelector("#signup-wrap") as HTMLElement;
  const submit = root.querySelector("#auth-submit") as HTMLButtonElement;
  const errBox = root.querySelector("#auth-error") as HTMLElement;
  const pwHelp = root.querySelector("#pw-help") as HTMLElement;

  function setMode(next: "login" | "register") {
    mode = next;
    tabs.forEach((t) => t.classList.toggle("active", t.dataset.tab === next));
    title.textContent = next === "login" ? "继续上次的位置" : "创建学习账号";
    sub.textContent = next === "login" ? "登录后，手机和电脑可以接着同一个进度。" : "账号只用于保存你自己的学习记录。";
    signupWrap.hidden = next !== "register";
    submit.textContent = next === "login" ? "登录" : "创建账号";
    errBox.hidden = true;
    const pw = root.querySelector("#password") as HTMLInputElement;
    pw.autocomplete = next === "login" ? "current-password" : "new-password";
    pwHelp.textContent = next === "login" ? "至少 8 位。" : "至少 8 位，建议使用一句只有你知道的话。";
  }

  tabs.forEach((t) => t.addEventListener("click", () => setMode(t.dataset.tab as "login" | "register")));

  const form = root.querySelector("#auth-form") as HTMLFormElement;
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    errBox.hidden = true;
    const fd = new FormData(form);
    const username = String(fd.get("username") ?? "").trim();
    const password = String(fd.get("password") ?? "");
    if (!username || password.length < 8) {
      errBox.textContent = "请填写用户名，密码至少 8 位。";
      errBox.hidden = false;
      return;
    }
    submit.disabled = true;
    const old = submit.textContent;
    submit.textContent = "请稍候……";
    try {
      if (mode === "login") {
        await api.post("/api/auth/login", { username, password });
      } else {
        await api.post("/api/auth/register", { username, password, signupCode: String(fd.get("signupCode") ?? "") });
      }
      authChanged();
    } catch (err) {
      const msg = err instanceof ApiError ? err.message : "暂时无法连接服务器。";
      errBox.textContent = msg;
      errBox.hidden = false;
    } finally {
      submit.disabled = false;
      submit.textContent = old ?? "登录";
    }
  });
}
