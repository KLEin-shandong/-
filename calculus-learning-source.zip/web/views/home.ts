import type { Bootstrap, KpSummary } from "../client-types.ts";
import { MASTERY_LABEL, MASTERY_CLASS, DIFFICULTY_LABEL, esc, initials } from "../dom.ts";
import { navigate } from "../nav.ts";

export function renderHome(root: HTMLElement, data: Bootstrap): void {
  const classroom = data.kps.find((k) => k.id === data.settings.classroomKpId) ?? data.kps[0];
  const last = data.lastSession;
  const lastKp = last ? data.kps.find((k) => k.id === last.kpId) : null;
  const mastered = data.kps.filter((k) => k.mastery === "mastered").length;
  const pending = data.kps.filter((k) => k.mastery === "pending_verify").length;
  const needs = data.kps.filter((k) => k.mastery === "needs_review").length;
  const online = navigator.onLine;

  const primaryHref = last && last.status === "active" && lastKp ? `#/practice/${last.kpId}` : classroom ? `#/kp/${classroom.id}` : "#/map";
  const primaryLabel = last && last.status === "active" && lastKp ? "继续上次练习" : "开始学习";

  root.innerHTML = `
  <div class="page-head">
    <div>
      <div class="eyebrow">今天从这里开始</div>
      <h1>${greeting()}，${esc(data.user.username)}</h1>
      <p class="sub">每天建议学习约 ${data.settings.defaultMinutes} 分钟，围绕一个主要知识点循序渐进；随时可以暂停。</p>
    </div>
    <div class="save-state ${online ? "" : "pending"}" id="cloud-state"><span class="dot"></span>${online ? "云端已连接" : "离线：本地暂存"}</div>
  </div>

  <div class="hero">
    <section class="card hero-main">
      <div class="eyebrow" style="color:var(--green-dark);font-size:12.5px;letter-spacing:.12em;font-weight:600">课堂位置</div>
      <h2>${esc(classroom?.title ?? "极限与连续")}</h2>
      <p class="sub">${esc(classroom?.subtitle ?? "")}</p>
      <div class="row mt-2">
        ${classroom ? `<span class="badge ${MASTERY_CLASS[classroom.mastery] ?? "line"}">${MASTERY_LABEL[classroom.mastery] ?? classroom.mastery}</span><span class="badge line">${DIFFICULTY_LABEL[classroom.difficulty] ?? classroom.difficulty}</span><span class="badge line">约 ${classroom.minutes} 分钟</span>` : ""}
      </div>
      <div class="continue-row">
        <a class="btn primary" href="${primaryHref}">${primaryLabel} →</a>
        ${data.dueReviewCount > 0 ? `<a class="btn soft" href="#/review">先复习 ${data.dueReviewCount} 项</a>` : `<a class="btn ghost" href="#/map">课程地图</a>`}
        ${last && last.status === "active" && lastKp && last.kpId !== classroom?.id ? `<span class="small muted">上次停在「${esc(lastKp.title)}」</span>` : ""}
      </div>
    </section>
    <aside class="hero-side">
      <div class="card stat-tile"><span class="num">${data.dueReviewCount}</span><span class="lbl">今天到期复习</span></div>
      <div class="card stat-tile"><span class="num">${mastered}<span style="font-size:15px;color:var(--muted);font-weight:400"> / ${data.kps.length}</span></span><span class="lbl">已掌握知识点</span></div>
      <div class="card stat-tile"><span class="num">${pending + needs}</span><span class="lbl">待验证或需要巩固</span></div>
    </aside>
  </div>

  ${data.dueReviews.length ? `
  <div class="section-head"><h2>今天先复习</h2><a class="small" href="#/review">查看全部</a></div>
  <div class="review-list">
    ${data.dueReviews.slice(0, 2).map((r) => `
      <div class="review-item">
        <div class="grow"><h3>${esc(r.title)}</h3><p>${r.kind === "formula" ? "公式卡回想" : "知识点复习"} · 第 ${r.stage + 1} 阶段 · 到期 ${esc(r.dueDate)}</p></div>
        ${r.kind === "formula"
          ? `<a class="btn sm soft" href="#/review">去回想</a>`
          : `<a class="btn sm primary" href="#/review-practice/${encodeURIComponent(r.targetId)}">开始复习</a>`}
      </div>`).join("")}
  </div>` : ""}

  ${!data.placement ? `
  <div class="card mt-3" style="display:flex;gap:18px;align-items:center;flex-wrap:wrap">
    <div style="flex:1;min-width:220px">
      <h3 style="font-size:16px">花 5 分钟做个摸底？</h3>
      <p class="small muted mt-1">6 道小题，覆盖代入、分式、因式分解、读图、分段函数和趋近。只影响推荐，不阻挡课程，也可以跳过。</p>
    </div>
    <a class="btn" href="#/placement">去摸底</a>
  </div>` : ""}

  <div class="section-head"><h2>课程进度</h2><span class="meta">掌握状态与课堂位置分别记录</span></div>
  ${data.modules.map((m) => {
    const kps = data.kps.filter((k) => k.module === m.id);
    return `
    <div class="module-block">
      <div class="module-head"><h2 style="font-size:17px">${esc(m.title)}</h2><span>${esc(m.description)}</span></div>
      <div class="kp-list">
        ${kps.map((kp) => kpCard(kp, kp.id === data.settings.classroomKpId)).join("")}
      </div>
    </div>`;
  }).join("")}

  <p class="tiny muted mt-4">AI：${data.aiEnabled ? "已启用（可随时降级为内置内容）" : "未启用，全部核心功能使用内置讲解与提示"} · 内容版本 ${esc(data.contentVersion)}</p>
  `;

  const cloud = root.querySelector("#cloud-state");
  const updateOnline = () => {
    if (!cloud) return;
    cloud.className = `save-state ${navigator.onLine ? "" : "pending"}`;
    cloud.innerHTML = `<span class="dot"></span>${navigator.onLine ? "云端已连接" : "离线：本地暂存"}`;
  };
  window.addEventListener("online", updateOnline, { once: true });
  window.addEventListener("offline", updateOnline, { once: true });
}

function kpCard(kp: KpSummary, current: boolean): string {
  return `
  <a class="card kp-card ${current ? "current" : ""}" href="#/kp/${encodeURIComponent(kp.id)}">
    <div class="row between">
      <h3>${esc(kp.title)}</h3>
      <span class="badge ${MASTERY_CLASS[kp.mastery] ?? "line"}">${MASTERY_LABEL[kp.mastery] ?? kp.mastery}</span>
    </div>
    <p>${esc(kp.subtitle)}</p>
    <div class="foot">
      <span class="tiny muted">${kp.questionCount} 道练习 · ${kp.minutes} 分钟</span>
      ${kp.reviewDue ? `<span class="badge amber">待复习</span>` : ""}
    </div>
  </a>`;
}

function greeting(): string {
  const hour = new Date().getHours();
  if (hour < 6) return "夜深了";
  if (hour < 11) return "早上好";
  if (hour < 14) return "中午好";
  if (hour < 18) return "下午好";
  return "晚上好";
}
