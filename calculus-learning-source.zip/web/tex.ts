// 轻量 TeX 子集渲染器（无外部依赖）。
// 仅支持课程内容实际使用的命令；输出经过转义的安全 HTML。

const SYMBOLS: Record<string, string> = {
  to: "→",
  rightarrow: "→",
  leftarrow: "←",
  Rightarrow: "⇒",
  Leftarrow: "⇐",
  Leftrightarrow: "⇔",
  leftrightarrow: "↔",
  infty: "∞",
  cdot: "·",
  times: "×",
  div: "÷",
  pm: "±",
  mp: "∓",
  le: "≤",
  leq: "≤",
  ge: "≥",
  geq: "≥",
  ne: "≠",
  neq: "≠",
  approx: "≈",
  equiv: "≡",
  sim: "∼",
  propto: "∝",
  Delta: "Δ",
  delta: "δ",
  varepsilon: "ε",
  epsilon: "ϵ",
  alpha: "α",
  beta: "β",
  gamma: "γ",
  theta: "θ",
  lambda: "λ",
  mu: "μ",
  sigma: "σ",
  phi: "φ",
  omega: "ω",
  partial: "∂",
  sum: "∑",
  prod: "∏",
  int: "∫",
  in: "∈",
  notin: "∉",
  subset: "⊂",
  subseteq: "⊆",
  cup: "∪",
  cap: "∩",
  emptyset: "∅",
  forall: "∀",
  exists: "∃",
  cdots: "⋯",
  ldots: "…",
  dots: "…",
  circ: "∘",
  angle: "∠",
  perp: "⊥",
  parallel: "∥",
  triangle: "△",
  checkmark: "✓",
  degree: "°",
  prime: "′",
  therefore: "∴",
  because: "∵",
  cong: "≅",
  iff: "⇔",
  implies: "⇒",
  lt: "<",
  gt: ">",
  "|": "‖",
  "{": "{",
  "}": "}",
  "%": "%",
  "#": "#",
  "&": "&",
  _: "_",
};
const BLACKBOARD: Record<string, string> = { R: "ℝ", N: "ℕ", Z: "ℤ", Q: "ℚ", C: "ℂ" };
const FUNCS = new Set([
  "sin", "cos", "tan", "cot", "sec", "csc",
  "arcsin", "arccos", "arctan",
  "ln", "log", "lg", "exp", "lim", "max", "min", "sup", "inf", "det",
]);

function esc(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

export function renderTex(src: string, display = false): string {
  let i = 0;
  const s = src;

  function readRawGroup(): string {
    skipSpace();
    if (s[i] !== "{") {
      const c = s[i] ?? "";
      i++;
      return c;
    }
    i++;
    let depth = 1;
    let out = "";
    while (i < s.length) {
      const c = s[i];
      if (c === "\\") {
        out += c + (s[i + 1] ?? "");
        i += 2;
        continue;
      }
      if (c === "{") depth++;
      if (c === "}") {
        depth--;
        if (depth === 0) {
          i++;
          break;
        }
      }
      out += c;
      i++;
    }
    return out;
  }

  function skipSpace(): void {
    while (i < s.length && /\s/.test(s[i])) i++;
  }

  function readAtom(): string {
    skipSpace();
    if (i >= s.length) return "";
    const c = s[i];
    if (c === "{") {
      i++;
      return parseSequence("}");
    }
    if (c === "\\") return renderCommand();
    i++;
    return renderChar(c);
  }

  function renderChar(c: string): string {
    if (c === "-") return '<span class="mbin">−</span>';
    if (c === "*") return '<span class="mbin">·</span>';
    if (c === "+") return '<span class="mbin">+</span>';
    if (c === "=" || c === "<" || c === ">") return `<span class="mrel">${esc(c)}</span>`;
    if (c === ",") return '<span class="sp"></span>';
    if (c === "~") return '<span class="sp wide"></span>';
    if (c === "'") return "<sup>′</sup>";
    if (/[0-9.]/.test(c)) return `<span class="mnum">${esc(c)}</span>`;
    if (/[a-zA-Z]/.test(c)) return `<span class="mvar">${esc(c)}</span>`;
    if (c === " ") return "";
    return esc(c);
  }

  function attach(base: string[], script: string, kind: "^" | "_"): void {
    const last = base.pop() ?? "";
    if (kind === "_" && last === '<span class="limop">lim</span>') {
      base.push(`<span class="lim"><span class="limop">lim</span><span class="limsub">${script}</span></span>`);
      return;
    }
    const tag = kind === "^" ? "sup" : "sub";
    base.push(`<span class="scripted">${last}<${tag}>${script}</${tag}></span>`);
  }

  function renderCommand(): string {
    if (s[i] !== "\\") return "";
    i++;
    const c = s[i];
    if (c == null) return "";
    if (!/[a-zA-Z]/.test(c)) {
      i++;
      if (c === "\\") return "<br>";
      if (c === "," || c === ":" || c === ";" || c === " ") return '<span class="sp"></span>';
      if (c === "!") return "";
      if (c === "{" || c === "}" || c === "%" || c === "#" || c === "&" || c === "_" || c === "|") {
        return esc(SYMBOLS[c] ?? c);
      }
      return esc(c);
    }
    let name = "";
    while (i < s.length && /[a-zA-Z]/.test(s[i])) {
      name += s[i];
      i++;
    }
    if (name === "frac" || name === "dfrac" || name === "tfrac") {
      const num = readAtom();
      const den = readAtom();
      return `<span class="frac"><span class="num">${num}</span><span class="den">${den}</span></span>`;
    }
    if (name === "sqrt") {
      skipSpace();
      let index = "";
      if (s[i] === "[") {
        i++;
        let d = 1;
        let raw = "";
        while (i < s.length) {
          if (s[i] === "[") d++;
          if (s[i] === "]") {
            d--;
            if (d === 0) {
              i++;
              break;
            }
          }
          raw += s[i++];
        }
        index = `<sup>${renderTex(raw)}</sup>`;
      }
      const body = readAtom();
      return `<span class="sqrt">${index}<span class="radical">√</span><span class="rad-body">${body}</span></span>`;
    }
    if (name === "text" || name === "textrm" || name === "mathrm" || name === "operatorname") {
      const raw = readRawGroup();
      return `<span class="${name === "text" ? "mtext" : "mop"}">${esc(raw)}</span>`;
    }
    if (name === "mathbb") {
      const raw = readRawGroup();
      return `<span class="mop">${esc(BLACKBOARD[raw.trim()] ?? raw)}</span>`;
    }
    if (name === "overline" || name === "bar") {
      return `<span class="overline" style="border-top:1.2px solid currentColor">${readAtom()}</span>`;
    }
    if (name === "underline") {
      return `<span class="underline" style="border-bottom:1.2px solid currentColor">${readAtom()}</span>`;
    }
    if (name === "vec" || name === "hat") {
      const mark = name === "vec" ? "→" : "^";
      return `<span class="accent"><span class="accent-mark">${mark}</span>${readAtom()}</span>`;
    }
    if (name === "left" || name === "right") {
      skipSpace();
      if (s[i] === ".") {
        i++;
        return "";
      }
      if (s[i] === "\\") {
        const d = renderCommand();
        return `<span class="mop">${d}</span>`;
      }
      const d = s[i++] ?? "";
      return `<span class="mop">${esc(d)}</span>`;
    }
    if (name === "big" || name === "Big" || name === "bigl" || name === "bigr" || name === "Bigl" || name === "Bigr" || name === "bigg" || name === "Bigg") {
      skipSpace();
      if (s[i] === "\\") return `<span class="mop">${renderCommand()}</span>`;
      return `<span class="mop">${esc(s[i++] ?? "")}</span>`;
    }
    if (name === "displaystyle" || name === "textstyle" || name === "limits" || name === "nolimits") return "";
    if (name === "quad") return '<span class="sp wide"></span>';
    if (name === "qquad") return '<span class="sp wide"></span><span class="sp wide"></span>';
    if (name === "langle" || name === "rangle") return `<span class="mop">${name === "langle" ? "⟨" : "⟩"}</span>`;
    if (name === "lfloor" || name === "rfloor") return `<span class="mop">${name === "lfloor" ? "⌊" : "⌋"}</span>`;
    if (name === "lceil" || name === "rceil") return `<span class="mop">${name === "lceil" ? "⌈" : "⌉"}</span>`;
    if (name === "lim") return '<span class="limop">lim</span>';
    if (FUNCS.has(name)) {
      return `<span class="mfn">${esc(name)}</span>`;
    }
    if (SYMBOLS[name]) return `<span class="mop">${SYMBOLS[name]}</span>`;
    // 未知命令按名称原样展示，避免静默丢失
    return `<span class="mop">${esc(name)}</span>`;
  }

  function parseSequence(stop?: string): string {
    const items: string[] = [];
    let pending = "";
    const flush = () => {
      if (pending) {
        items.push(pending);
        pending = "";
      }
    };
    while (i < s.length) {
      const c = s[i];
      if (stop && c === stop) {
        i++;
        flush();
        return items.join("");
      }
      if (c === "{") {
        flush();
        items.push(readAtom());
        continue;
      }
      if (c === "}") {
        i++;
        continue;
      }
      if (c === "^" || c === "_") {
        flush();
        i++;
        const atom = readAtom();
        // 连续的上下标都挂在同一个基上；简单起见逐个处理
        if (items.length === 0) items.push(atom);
        else attach(items, atom, c);
        continue;
      }
      if (c === "\\") {
        flush();
        items.push(renderCommand());
        continue;
      }
      if (/\s/.test(c)) {
        i++;
        continue;
      }
      pending += renderChar(c);
      i++;
    }
    flush();
    return items.join("");
  }

  const body = parseSequence();
  return `<span class="tex${display ? " tex-display" : ""}">${body}</span>`;
}
