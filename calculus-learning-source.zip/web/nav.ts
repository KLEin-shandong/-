export function navigate(path: string): void {
  const hash = path.startsWith("#") ? path : `#${path}`;
  if (location.hash === hash) {
    window.dispatchEvent(new HashChangeEvent("hashchange"));
  } else {
    location.hash = hash;
  }
}

export function currentPath(): string {
  const h = location.hash.replace(/^#/, "");
  return h || "/";
}

export function refreshBootstrap(): void {
  window.dispatchEvent(new CustomEvent("cl:refresh-bootstrap"));
}

export function authChanged(): void {
  window.dispatchEvent(new CustomEvent("cl:auth-changed"));
}

export function loadingHtml(text = "正在载入……"): string {
  return `<div class="boot">${text}</div>`;
}

export function errorHtml(message: string): string {
  return `<div class="card"><h2>出了点问题</h2><p class="muted mt-1">${escapeHtml(message)}</p><div class="mt-3"><button class="btn primary" onclick="location.reload()">重新载入</button></div></div>`;
}

export function escapeHtml(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
