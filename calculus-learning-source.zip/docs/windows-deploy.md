# Windows 电脑公网部署手册

本手册把 [GitHub + Cloudflare 公网访问方案](cloudflare-deploy.md) 落到 Windows 电脑上。目标是一个公网 HTTPS 地址，例如 `https://calc.example.com`，只有通过 Cloudflare Access 的授权邮箱能打开，同时保留本站自己的登录。

## 前提

- Windows 10/11，管理员 PowerShell。
- Node.js ≥ 22.18、Git。
- 一个**已托管到 Cloudflare** 的域名；没有域名无法使用固定域名和 Access。购买和接入步骤见 [公网方案的“没有域名怎么办”](cloudflare-deploy.md#没有域名怎么办)。
- 一台常开的电脑。笔记本合盖或睡眠会让网站下线。
- 不需要路由器端口映射，也不需要公网 IP。

以下命令以项目位于 `D:\obsidian\calculus-learning` 为例；脚本会自动定位项目根目录，换路径也可以。

## 1. 建立 GitHub 私有仓库

在项目目录打开 PowerShell：

```powershell
cd D:\obsidian\calculus-learning
git init
git add .
git status
git commit -m "Initial calculus learning app"
git branch -M main
git remote add origin git@github.com:<你的账号>/calculus-learning.git
git push -u origin main
```

`git status` 中不应出现 `data/`、`.env`、`*.log`。仓库必须是 **Private**。

当前 `.gitignore` 已忽略：

```text
node_modules/
data/
.env
.DS_Store
*.log
```

`data/` 里有数据库、WAL 文件和会话密钥；`.env` 里有会话密钥、邀请码和可选的 AI Key。

## 2. 配置 `.env` 并首次启动

```powershell
Copy-Item .env.example .env
notepad .env
```

生成一个随机会话密钥：

```powershell
$bytes = New-Object byte[] 48
[Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
[Convert]::ToBase64String($bytes)
```

`.env` 至少包含：

```dotenv
PORT=3102
HOST=127.0.0.1
SESSION_SECRET=上一步生成的随机字符串
SIGNUP_CODE=只有自己知道的邀请码
APP_ALLOW_REGISTRATION=false
```

说明：

- `HOST=127.0.0.1`：只监听本机，公网只能通过 Cloudflare Tunnel 进来。
- 不要设置 `ALLOW_LAN=true`。
- 第一个注册的账号不受邀请码限制；之后保持关闭注册。
- AI 配置按 [AI 配置](ai.md) 填写；不填也能使用内置内容。

前台试运行：

```powershell
npm start
```

另开一个 PowerShell 验证：

```powershell
Invoke-WebRequest -UseBasicParsing http://127.0.0.1:3102/api/health
```

在浏览器打开 `http://127.0.0.1:3102`，注册第一个账号，确认能登录、进入课程。然后回到运行 `npm start` 的窗口按 `Ctrl+C` 停止。

> 如果 3102 已被占用，先停止占用它的服务。当前开发会话可能仍在 3102 运行；安装计划任务前必须让它空闲。

## 3. 把 Node 服务注册为开机任务

以**管理员身份**打开 PowerShell，执行：

```powershell
cd D:\obsidian\calculus-learning
powershell -ExecutionPolicy Bypass -File .\scripts\windows\install-node-task.ps1
```

脚本会：

- 检查 `.env` 和 `server/main.ts`；
- 检查 3102 是否空闲；
- 创建计划任务 `CalculusLearning`；
- 开机自动启动，以 `SYSTEM` 运行；
- 失败后最多重启 3 次；
- 启动后请求 `/api/health` 验证。

如果项目不在脚本所在目录的上两级，可以显式传入：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\windows\install-node-task.ps1 -ProjectDir "D:\obsidian\calculus-learning"
```

验证：

```powershell
Get-ScheduledTask -TaskName CalculusLearning
Invoke-WebRequest -UseBasicParsing http://127.0.0.1:3102/api/health
```

计划任务直接运行 Node，不捕获控制台输出。需要看启动日志时，先停任务，再在项目目录用 `npm start` 前台运行。若反复启动失败，查看任务计划程序中的“上次运行结果”，并确认 `SYSTEM` 对项目目录和 `data/` 有读写权限。

### 电源设置

网站要一直在线，电脑不能自动睡眠。插电时执行：

```powershell
powercfg /change standby-timeout-ac 0
powercfg /change hibernate-timeout-ac 0
```

再到“设置 → 系统 → 电源”里把“接通电源时使设备进入睡眠状态”设为“从不”。笔记本还要把合盖动作设为“不采取任何操作”，或改用迷你主机/台式机。

## 4. 安装 Cloudflare Tunnel

推荐用 Cloudflare 控制台的 **token 方式**，在 Windows 上比手写 `config.yml` 更稳，也不会遇到 LocalSystem 找不到用户目录配置的问题。

1. 安装 cloudflared：

```powershell
winget install --id Cloudflare.cloudflared -e
```

如果 `winget` 不可用，到 Cloudflare 官网下载 Windows 版 `cloudflared.exe`，放到 `C:\Program Files\cloudflared\` 并加入 PATH。

2. 打开 Cloudflare Zero Trust → `Networks` → `Tunnels` → `Create a tunnel`。
3. 选择 `Cloudflared`，命名例如 `calculus`。
4. 选择 Windows，复制页面给出的安装命令，类似：

```powershell
cloudflared.exe service install <TUNNEL_TOKEN>
```

5. 在**管理员 PowerShell**执行该命令，然后检查服务：

```powershell
Get-Service cloudflared
```

6. 回到 Tunnel 的 `Public Hostname` 标签，添加：

- Subdomain：`calc`
- Domain：你的域名，例如 `example.com`
- Service：`HTTP`
- URL：`127.0.0.1:3102`

保存后，`https://calc.example.com` 应该能到本机应用。**先不要把这个地址发给别人，下一步立刻加 Access。**

如果显示 502：

- 确认 `Get-ScheduledTask -TaskName CalculusLearning` 是 Running；
- 确认 `Invoke-WebRequest http://127.0.0.1:3102/api/health` 正常；
- 确认 Public Hostname 填的是 `127.0.0.1:3102`，不是 `localhost` 以外的地址。

## 5. 配置 Cloudflare Access

在 Zero Trust 控制台：

1. `Access` → `Applications` → `Add an application` → `Self-hosted`。
2. 域名填 `calc.example.com`，路径留空，保护整个站点（包括 `/api`）。
3. 新建策略：
   - Action：`Allow`
   - Include：`Emails`，填你自己的邮箱
   - Session duration：建议 1 周
4. 登录方式选 `One-time PIN`、`GitHub` 或 `Google`。
5. 用无痕窗口访问 `https://calc.example.com`：
   - 先出现 Cloudflare Access 登录；
   - 通过后出现本站登录页；
   - 登录后能正常学习。

站内登录要保留。Access 是外层门，本站账号是第二层。

### 外部 Agent API

如果整个 `calc.example.com` 都受 Access 保护，外部 Agent 还需要 Cloudflare Access Service Token。不要为了 Agent 直接关闭整站 Access。具体做法见 [公网方案中的 Agent 部分](cloudflare-deploy.md#外部-agent-api-的额外处理)。

## 6. 更新代码和内容

### 只改课程内容

直接在 Windows 上编辑 `content/` 下的 JSON，服务会自动热重载，页面约 15 秒内刷新，不需要重启任务。

### 从 GitHub 拉取内容

```powershell
cd D:\obsidian\calculus-learning
git pull --ff-only
```

内容文件会自动热重载；如果拉到的是服务端/前端代码，再重启任务：

```powershell
Stop-ScheduledTask -TaskName CalculusLearning
Start-ScheduledTask -TaskName CalculusLearning
```

### 可选：push 后自动部署

在运行主机安装 GitHub Actions self-hosted runner，只绑定这个私有仓库。工作流示例：

```yaml
name: deploy
on:
  push:
    branches: [main]
jobs:
  deploy:
    runs-on: self-hosted
    steps:
      - name: Pull latest
        shell: powershell
        run: git -C D:\obsidian\calculus-learning pull --ff-only
      - name: Restart app
        shell: powershell
        run: |
          Stop-ScheduledTask -TaskName CalculusLearning
          Start-ScheduledTask -TaskName CalculusLearning
```

不熟悉 runner 时，手动 `git pull` 更简单，也不会误删 `data/` 或 `.env`。

## 7. 备份、恢复与回滚

备份前停止任务，复制整个 `data/`：

```powershell
Stop-ScheduledTask -TaskName CalculusLearning
Copy-Item -Recurse data "data-backup-$(Get-Date -Format yyyyMMdd-HHmmss)"
Start-ScheduledTask -TaskName CalculusLearning
```

不要只复制 `calculus.db`，要连同 `calculus.db-wal`、`calculus.db-shm` 和 `session.key` 一起复制。

恢复：

```powershell
Stop-ScheduledTask -TaskName CalculusLearning
# 把备份目录复制回 data
Start-ScheduledTask -TaskName CalculusLearning
```

卸载开机任务：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\windows\uninstall-node-task.ps1
```

卸载 cloudflared 服务：

```powershell
cloudflared.exe service uninstall
```

Cloudflare 的 Tunnel、Public Hostname 和 Access 应用在控制台删除。

## 8. 验收清单

- [ ] `Get-ScheduledTask -TaskName CalculusLearning` 为 Running。
- [ ] `Invoke-WebRequest http://127.0.0.1:3102/api/health` 返回 `ok: true`。
- [ ] 公网 IP:3102 无法访问；Windows 防火墙没有放行 3102。
- [ ] 无痕窗口访问 `https://calc.example.com` 先出现 Cloudflare Access。
- [ ] 未授权邮箱无法通过 Access。
- [ ] 通过 Access 后出现本站登录页。
- [ ] 手机用 4G/5G 能打开并登录。
- [ ] 关闭注册后，新账号注册被拒绝。
- [ ] 修改一个 `content/*.json`，页面自动刷新。
- [ ] 重启 Windows 后，Node 任务和 cloudflared 服务都自动启动。
- [ ] 备份并恢复 `data/` 后，学习记录还在。
- [ ] 外部 Agent 如启用，已单独配置 Access Service Token，没有关闭整站 Access。

## 9. 常见问题

### 3102 被占用

```powershell
Get-NetTCPConnection -LocalPort 3102 -State Listen
```

取得 `OwningProcess` 后，确认它确实是旧的本项目进程，再停止。不要直接结束不认识的进程。

### 计划任务启动失败

- 用管理员 PowerShell 运行 `install-node-task.ps1`；
- 确认 `.env` 存在；
- 确认 `node.exe` 路径仍有效；
- 确认 `SYSTEM` 对项目目录和 `data/` 有读写权限；
- 把项目放在 `C:\apps\calculus-learning` 这类普通目录，避免放在权限特殊的用户目录。

### 公网 502

先在本机验证 3102，再检查 Tunnel 的 Public Hostname 是否填 `127.0.0.1:3102`。本机正常、公网 502 时，问题通常在 Tunnel 或 Access，而不是应用。

### Access 登录循环

- 确认访问的是 `https://calc.example.com`，不是旧标签页或 `http://`；
- 清除该域名 Cookie 后重试；
- 检查 Access 应用域名和策略邮箱是否正确。

### 电脑睡眠后网站打不开

按第 3 节的电源设置关闭睡眠和休眠；笔记本合盖也会触发睡眠。

## 10. 安全边界

- 不开放路由器端口，不做端口映射。
- `HOST=127.0.0.1`，不设置 `ALLOW_LAN=true`。
- GitHub 仓库保持 Private；`data/`、`.env` 永不提交。
- Cloudflare Access 和本站登录同时保留。
- 不在聊天、文档或日志中放 `SESSION_SECRET`、数据库、Agent 令牌明文。
- 备份文件也按私人数据保管。
