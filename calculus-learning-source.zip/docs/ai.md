# AI 配置与降级

AI 是可选增强，默认关闭。关闭时，讲解、提示、错因分析、复习建议全部使用内置文本，学习流程不受影响。

## 配置

在 `.env` 中设置：

```dotenv
AI_ENABLED=true
AI_BASE_URL=https://your-provider.example/v1
AI_MODEL=your-model-name
AI_API_KEY=你的密钥
AI_TIMEOUT_MS=20000
```

- `AI_BASE_URL` 填 OpenAI 兼容 API 的基础地址；程序会自动追加 `/chat/completions`。若地址本身已以 `/chat/completions` 结尾，则直接使用。
- 需要服务端支持 `POST /chat/completions`，请求体含 `model`、`messages`、`temperature`、`max_tokens`。
- 密钥只从环境变量读取，不写入数据库，不返回浏览器。`GET /api/ai/status` 只返回是否启用、是否配置完整、模型名（未启用时不返回）和超时时间。

## 调用约束

- 系统提示要求：简体中文、一次只讲一个动作、不使用“显然”“易知”、不编造来源、提示不得直接给最终答案、不输出 HTML/脚本/链接。
- 只接受一个 JSON 对象：`{"content": "...", "references": ["..."]}`。代码会剥掉 Markdown 代码围栏后再解析。
- 内容会去标签、去 `javascript:`、截断到 4000 字；提示任务超过 800 字视为不合格。
- 单次调用受 `AI_TIMEOUT_MS` 限制，超时即降级。
- 每次调用写入 `ai_log`，只记录任务、来源（ai/builtin）、状态和降级原因，不记录密钥或完整提示。

## 降级规则

以下任一情况都回退到内置内容，响应中的 `source` 为 `builtin`：

- AI 未启用，或地址/模型/密钥缺失；
- 上游非 2xx、超时、网络失败；
- 返回不是 JSON、缺少非空 `content`、或内容清洗后为空；
- 提示内容过长。

界面会显示内容来源；不会把内置内容标成 AI 生成。

## 未完成事项

- 本次没有配置真实 AI 服务和密钥，因此**未做真实上游联调**；只用本地测试验证了“未配置时降级”和 JSON 结构校验路径。
- 未实现流式输出、多轮对话、费用统计或提示词版本管理。
- 使用第三方服务时，题目文本与学生作答会发送给该服务；需要自行评估隐私与合规。内置模式不发送任何数据。

## 相关代码

- `server/ai.ts`：请求、校验、清洗、降级。
- `server/api.ts`：`/api/ai/status` 与 `/api/ai/tasks`。
- `web/views/settings.ts`：显示 AI 状态。
