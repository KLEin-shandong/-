# 通过 GitHub + Cloudflare 提供公网访问

本文是**部署方案**，尚未在真实域名上执行。当前交付仍是本地自托管版本。

## 结论

当前应用是常驻的 Node.js 进程 + 本地 SQLite，不能直接放到 GitHub Pages 或 Cloudflare Pages 上运行。推荐路径是：

- **GitHub 私有仓库**保存代码和课程内容；
- 一台常开的电脑、迷你主机、NAS 或 VPS 运行现有 Node 服务；
- **Cloudflare Tunnel** 把 `https://calc.example.com` 转发到这台机器的 `127.0.0.1:3102`；
- **Cloudflare Access** 只允许你授权的邮箱或 GitHub 账号打开站点；
- 站点自己的用户名密码登录继续保留。

这样会有一个公网 HTTPS 链接，但未授权的人打不开，符合“公网可达、仍然私人”的要求。不要把站点改成无鉴权的公开页面。

## 架构

```text
手机 / 电脑
    │ HTTPS
    ▼
Cloudflare Access（邮箱 / GitHub 登录）
    ▼
Cloudflare Tunnel（cloudflared 主动向外连接）
    ▼
运行主机 127.0.0.1:3102
    ├─ Node 服务
    ├─ SQLite: data/calculus.db
    └─ 课程内容: content/
GitHub 私有仓库 ──手动或自动拉取──┘
```

Cloudflare Tunnel 不需要路由器端口映射，也不需要在防火墙开放 3000/3102。运行主机只需要能主动访问外网。

## 前置条件

1. **一个已托管到 Cloudflare 的域名**。固定域名和 Access 都需要它。没有域名时，`trycloudflare.com` 的临时链接是随机地址，不能加 Access，不适合放私人学习数据。
2. **一台常开主机**：家里电脑、迷你主机、NAS 或 Linux VPS 均可。Node.js ≥ 22.18。
3. **Cloudflare Zero Trust**：个人使用免费额度足够（1 个用户）。
4. **GitHub 私有仓库**：课程内容和学习数据不应公开。

### 没有域名怎么办

Cloudflare Access 和固定 Tunnel 都要求你控制一个**托管在 Cloudflare 的域名**。没有域名时，这套方案不能完整落地。

不建议用 `trycloudflare.com` 临时隧道代替：

- 地址是随机生成、会变化的；
- 不能配置 Cloudflare Access；
- 任何拿到链接的人都能打开，只剩本站登录一层保护；
- 不适合放私人学习数据。

推荐先买一个便宜域名：

1. 在 Cloudflare Registrar、Porkbun、Namecheap 等注册商买一个最便宜的域名（`.xyz`、`.top`、`.com` 等，通常每年几十元人民币，具体以注册商为准），开启 WHOIS 隐私。
2. 在 Cloudflare 控制台 `Add a site` 添加这个域名，选 Free 计划。
3. Cloudflare 会给出两个 nameserver；到注册商后台把域名的 nameserver 改成这两个。
4. 等 Cloudflare 显示 `Active`（通常几分钟到 24 小时）。
5. 用子域名作为学习站地址，例如 `calc.yourdomain.com`；根域名以后还可以做别的用途。

如果是在 Cloudflare Registrar 直接注册，域名默认就在 Cloudflare DNS 里，通常不需要再改 nameserver。

**暂时不想买域名**的替代方案：

- **Tailscale（推荐作为临时私人方案）**：把电脑和手机加入同一个 tailnet，用 `tailscale serve` 把 `127.0.0.1:3102` 暴露给 tailnet 内的设备。它没有公网链接，但能在手机/电脑之间私人访问。
- **Cloudflare 临时隧道**：只适合几分钟的演示，不要放真实学习数据。
- 不要使用无法转移 nameserver 的免费二级域名；Cloudflare 无法接管它的 DNS，也就无法配置 Access。

> 合规与网络提醒：在中国大陆通过家庭宽带对外提供网站，可能涉及 ICP 备案、运营商条款和学校网络规定；公开传播前请自行确认。Cloudflare 免费边缘节点在中国大陆的访问速度也可能不稳定。只给自己和家人用、且通过 Tailscale 等私人网络访问，通常可以避开“公网网站”的一部分合规问题，但就没有公网链接了。

## 步骤

### 1. GitHub 私有仓库

当前目录还不是 Git 仓库。首次推送时：

```bash
cd D:/obsidian/calculus-learning
git init
git add .
git status
git commit -m "Initial calculus learning app"
git branch -M main
git remote add origin git@github.com:<你的账号>/calculus-learning.git
git push -u origin main
```

推送前确认 `git status` 里**没有**：

- `data/`（数据库、`session.key`、WAL 文件）
- `.env`（会话密钥、AI Key、邀请码）
- 任何备份文件

本项目的 `.gitignore` 已经把 `data/` 和 `.env` 排除。`content/`、`server/`、`web/`、`shared/`、`tests/`、`docs/` 应该提交。

仓库必须是 Private。课程内容、题目和解析即使答案在服务端，也不适合公开。

### 2. 准备运行主机

把仓库克隆到常开主机，例如 Linux 的 `/opt/calculus-learning`，或 Windows 的 `C:\apps\calculus-learning`。

创建 `.env`：

```dotenv
PORT=3102
HOST=127.0.0.1
SESSION_SECRET=一串足够长的随机字符
SIGNUP_CODE=只有自己知道的邀请码
APP_ALLOW_REGISTRATION=false
```

说明：

- `HOST=127.0.0.1` 很关键：应用只接受本机连接，公网只能通过 Tunnel 进来。
- **不要**设置 `ALLOW_LAN=true`。
- 第一个注册的账号不受邀请码限制；注册完成后保持 `APP_ALLOW_REGISTRATION=false`。
- AI 配置按 `docs/ai.md` 填写；不填也能使用内置内容。

启动并验证：

```bash
npm start
curl http://127.0.0.1:3102/api/health
```

确认防火墙没有对公网开放 3102。云主机安全组也不要放行该端口。

长期运行可以用 systemd（Linux）：

```ini
[Unit]
Description=Calculus Learning
After=network.target

[Service]
WorkingDirectory=/opt/calculus-learning
ExecStart=/usr/bin/node --disable-warning=ExperimentalWarning server/main.ts
EnvironmentFile=/opt/calculus-learning/.env
Restart=always
User=calc

[Install]
WantedBy=multi-user.target
```

Windows 可以用任务计划程序或 NSSM 把 `npm start` 注册为开机启动服务。

### 3. 安装并创建 Cloudflare Tunnel

**Windows 用户建议直接按 [Windows 电脑公网部署手册](windows-deploy.md) 操作**：在 Cloudflare 控制台创建 Tunnel，用 `cloudflared.exe service install <TOKEN>` 安装服务，公网主机名也在控制台配置，不需要处理本地 `config.yml` 的权限和路径问题。

下面是 CLI 管理方式，适合 Linux 或希望把配置写在文件里的用户。先在运行主机安装 `cloudflared`，然后：

```bash
cloudflared tunnel login
cloudflared tunnel create calculus
cloudflared tunnel route dns calculus calc.example.com
```

`cloudflared tunnel create` 会生成一个 Tunnel UUID 和凭据 JSON。新建配置文件：

Windows：`C:\Users\<用户名>\.cloudflared\config.yml`

Linux：`/etc/cloudflared/config.yml`

```yaml
tunnel: <TUNNEL_UUID>
credentials-file: C:\Users\<用户名>\.cloudflared\<TUNNEL_UUID>.json
ingress:
  - hostname: calc.example.com
    service: http://127.0.0.1:3102
  - service: http_status:404
```

Linux 的 `credentials-file` 改成 `/etc/cloudflared/<TUNNEL_UUID>.json`。

先前台运行确认：

```bash
cloudflared tunnel run calculus
```

然后安装为系统服务：

```bash
cloudflared service install
```

Windows 上以管理员身份执行；Linux 上用 `sudo cloudflared service install`。

Windows 服务默认以 LocalSystem 运行，可能读不到当前用户的 `%USERPROFILE%\.cloudflared\config.yml`。如果服务启动后日志提示找不到配置，把配置和凭据复制到 `C:\Windows\System32\config\systemprofile\.cloudflared\`，或在服务命令中显式指定 `--config`。以前台 `cloudflared tunnel run calculus` 能通、但服务不能通时，优先检查这一点。

此时 `https://calc.example.com` 已经能通过 Tunnel 到达本机。**下一步要立刻加 Access，避免在配置完成前处于无外层保护状态。**

### 4. 配置 Cloudflare Access（私人访问的关键）

在 Cloudflare Zero Trust 控制台：

1. `Access` → `Applications` → `Add an application` → `Self-hosted`。
2. 域名填 `calc.example.com`，路径留空（保护整个站点，包括 `/api`）。
3. 新建策略：
   - Action：`Allow`
   - Include：`Emails`，填你自己的邮箱；需要多人时逐个添加。
   - Session duration：建议 1 周。
4. 登录方式选 `One-time PIN`（邮箱验证码）或 `GitHub` / `Google`。
5. 保存后，用无痕窗口访问 `https://calc.example.com`，应先看到 Cloudflare Access 登录，而不是本站登录页。

Access 通过后，仍然会看到本站自己的登录页。这是双层保护，不要关掉站内登录。

#### 外部 Agent API 的额外处理

如果整个 `calc.example.com` 都受 Access 保护，外部 Agent 只带本站 Bearer Token 会被 Cloudflare 登录页拦住。有两种做法：

- **推荐**：为 Agent 单独建一个主机名，例如 `agent.example.com`，在 Access 中创建 `Service Auth` 策略，给 Agent 发 Cloudflare Service Token；请求同时带：
  - `CF-Access-Client-Id: ...`
  - `CF-Access-Client-Secret: ...`
  - `Authorization: Bearer <本站 Agent 令牌>`
- 或者给 `/api/agent/*` 单独配置 Access 策略。不要为了方便直接对所有路径关闭 Access；那会把整个站点暴露到公网。

本站 Agent 令牌仍然只保存在服务端摘要中，有作用域、90 天有效期和每分钟 60 次限制，但 Cloudflare Access 是额外的外层门槛。

### 5. 代码和内容如何更新

#### 只改课程内容

如果直接在运行主机上编辑 `content/` 下的 JSON，服务会自动热重载，浏览器约 15 秒内刷新，不需要重启，也不需要重新部署。

#### 通过 GitHub 网页改内容

GitHub 上的修改不会自动出现在运行主机，需要在主机上拉取：

```bash
cd /opt/calculus-learning
git pull --ff-only
```

内容文件拉取后会自动热重载；代码文件变化才需要重启服务。

#### 希望 push 后自动部署

最稳妥的是在运行主机上安装 **GitHub Actions self-hosted runner**，让它主动连接 GitHub，不需要公网 SSH。工作流可以做：

```yaml
name: deploy
on:
  push:
    branches: [main]
jobs:
  deploy:
    runs-on: self-hosted
    steps:
      - run: git -C /opt/calculus-learning pull --ff-only
      - run: sudo systemctl restart calculus-learning
```

注意：

- runner 只用于这个私有仓库，不要给不受信任的仓库使用。
- 不要用 `rsync --delete` 覆盖整个目录，否则可能误删 `data/` 和 `.env`。
- 只改内容时不必重启；只有服务端/前端代码变化才需要重启。
- 如果不熟悉 runner，手动 `git pull` 更简单，也更不容易误删数据。

### 6. 验收清单

- [ ] 无痕窗口访问 `https://calc.example.com`，先出现 Cloudflare Access，未授权邮箱无法通过。
- [ ] 通过 Access 后出现本站登录页；登录后手机和电脑都能使用。
- [ ] `http://<公网IP>:3102` 无法访问，安全组和防火墙没有开放该端口。
- [ ] `HOST=127.0.0.1`，没有设置 `ALLOW_LAN=true`。
- [ ] 浏览器开发者工具里登录 Cookie 带 `HttpOnly` 和 `SameSite=Lax`；在 Cloudflare 下应同时带 `Secure`（应用会读取 `X-Forwarded-Proto`）。
- [ ] 关闭注册后，新账号注册被拒绝。
- [ ] 修改 `content/` 中一个 JSON，页面自动刷新；恢复后再次刷新。
- [ ] 重启运行主机后，Node 服务和 cloudflared 都能自动启动。
- [ ] 备份 `data/` 后重启，学习记录仍在。
- [ ] 外部 Agent 如果需要访问，已单独配置 Access Service Token，而不是关闭整站 Access。

## 不推荐的路径

### GitHub Pages

只能托管静态文件。当前站点需要服务端判分、SQLite 学习记录和登录；把答案打包到前端会直接违反“正式答案只在服务端”的要求。

### Cloudflare Pages

同样偏静态托管，不能直接运行当前 Node HTTP 服务和 `node:sqlite`。

### 直接改写成 Cloudflare Workers + D1

理论上可行，但不是“部署一下”的工作量，需要重写：

- Node HTTP 路由 → Worker `fetch`；
- `node:sqlite` → D1；
- `scrypt` 密码哈希 → Web Crypto（如 PBKDF2）或兼容库；
- `fs` 读取课程内容 → 构建产物 / R2 / D1；
- `fs.watch` 热更新 → 部署时构建或管理端上传；
- 浏览器直接加载 TypeScript → 增加构建步骤。

如果以后不满足于“家里/主机常开”，可以另立项目做这次迁移；不建议为了一个公网链接先重写。

### `trycloudflare.com` 临时 Tunnel

随机域名、无 Access、随时变化，只适合临时演示，不适合私人学习数据。

## 还需要你确认

要把它落成可直接执行的文件和命令，还需要知道：

1. 是否已有域名，DNS 是否已经托管到 Cloudflare？
2. 运行主机是 Windows 家庭电脑，还是 Linux VPS/迷你主机？
3. 是否需要“GitHub push 后自动部署”，还是手动 `git pull` 即可？

确认后可以继续补：`cloudflared` 配置、systemd/Windows 服务、GitHub Actions 工作流和一次真实验收。
