# 课程内容编写规范（施工用）

本文件给内容作者使用。目标是让每一节都能照着学、照着做、独立做，并且答案可核对。

## 文件与编号

每个知识点两个文件：

- `content/knowledge-points/<kpId>.json`：一个对象。
- `content/questions/<kpId>.json`：一个数组，正好 9 道题。

`kpId`、标题、模块、顺序、前置和来源以 `content/manifest.json` 为准，不得自行改动编号或前置关系。文件名用 `模块-序号-短名.json`，例如 `func-fractions.json`、`limits-03-table-graph.json`、`derivatives-02-instantaneous.json`。

不要修改其他知识点、`formulas.json`、服务端或前端文件。需要新公式卡时在交付说明中列出，不要直接改共享文件。

## 知识点对象

```json
{
  "id": "func-fractions",
  "module": "func",
  "order": 2,
  "title": "分数与分式的基本运算",
  "subtitle": "分母不为零，约分要有条件",
  "version": 1,
  "minutes": 30,
  "prereqs": ["func-signs-order"],
  "source": [{ "file": "基础补充", "kind": "supplement", "note": "高中基础补充：分数与分式" }],
  "objectives": ["……", "……", "……"],
  "blocks": [],
  "summary": ["……", "……", "……"],
  "formulaIds": ["fraction-rules"],
  "remediationPriority": 2
}
```

要求：

- `objectives` 3—5 条，写“能做什么”，不写“了解”。
- `blocks` 8—16 个，必须包含：白话解释、一个具体例子（数值/图像/生活）、必要的定义或公式、一道完整例题、常见错误。
- `summary` 3—4 条，用于课后回看。
- `formulaIds` 只能引用 `content/formulas.json` 已有的 `id`；没有合适的就写空数组，并在交付说明中列出建议新增的公式卡。
- `source` 与 manifest 一致。`kind` 只能为 `course`（课件整理）、`supplement`（基础补充）、`original`（原创）。课件来源必须写 PDF 文件名与页码；补充内容不得冒充课件。

### 可用内容块

```json
{ "t": "p", "md": "一段文字，行内公式用 $x\\to a$。" }
{ "t": "h", "text": "小标题" }
{ "t": "math", "tex": "\\lim_{x\\to a}f(x)=A" }
{ "t": "example", "title": "例：……", "steps": ["第一步……", "第二步……"], "answer": "$2$" }
{ "t": "pitfall", "title": "常见错误", "md": "……" }
{ "t": "callout", "tone": "info|warn|good", "title": "提示", "md": "……" }
{ "t": "table", "head": ["x", "1.9", "2.0"], "rows": [["$f(x)$", "3.61", "4"]], "caption": "……" }
{ "t": "figure", "spec": { "kind": "graph", "fn": "x^2", "xMin": -1, "xMax": 3, "yMin": 0, "yMax": 8, "caption": "……" } }
{ "t": "list", "items": ["……", "……"], "ordered": false }
{ "t": "link", "kpId": "func-factoring", "text": "补一下：因式分解" }
{ "t": "formula", "id": "fraction-rules" }
```

图像 `kind` 支持 `graph`（`fn` 用受限表达式）、`table`（`table.head/rows`）、`numberline`、`piecewise`（`segments`）。函数表达式只支持 `x`、数字、`+ - * / ^`、括号、`sqrt/sin/cos/tan/ln/log/exp/abs`、`pi/e`。不要写 `\begin{cases}`；使用表格或 `figure` 表达分段。

## 题目对象

每题字段：

```json
{
  "id": "q-frac-01",
  "version": 1,
  "kpId": "func-fractions",
  "difficulty": "basic",
  "type": "choice",
  "role": "concept",
  "prompt": [{ "t": "p", "md": "……" }],
  "options": [{ "id": "A", "md": "……" }, { "id": "B", "md": "……" }],
  "answer": { "kind": "choice", "value": "B" },
  "hints": ["一级提示", "二级提示", "三级提示"],
  "solution": [{ "t": "p", "md": "完整过程与答案。" }],
  "source": { "kind": "original", "ref": "按本节知识点编写" },
  "formatHint": "选择一个选项"
}
```

### 数量与分布（必须）

- 每个知识点正好 9 道题。
- 3 个难度 × 3 个角色，各一道：
  - `basic`、`standard`、`advanced` 每个难度都包含 `concept`、`step`、`independent` 各一道。
- `concept`：概念或方法辨认，通常选择题。
- `step`：分步填空或关键步骤，通常 `type: "steps"` 或 `fill`。
- `independent`：独立作答，通常 `fill` / `calc` / `choice`。
- 题目编号 `<模块缩写>-<序号>-<两位题号>`，例如 `q-frac-01`；同一知识点内不重复。

### 答案类型

```json
{ "kind": "choice", "value": "B" }
{ "kind": "number", "value": 2 }
{ "kind": "number", "value": 2.5, "tolerance": 0.01, "toleranceKind": "absolute" }
{ "kind": "fraction", "numerator": 1, "denominator": 2 }
{ "kind": "symbol", "value": "infinity" }   // 或 -infinity、dne、zero
{ "kind": "expression", "accept": ["2x+2", "2(x+1)"] }
{ "kind": "steps", "steps": [
  { "label": "第一步", "answer": { "kind": "number", "value": 3 } },
  { "label": "第二步", "answer": { "kind": "choice", "value": "A" } }
] }
```

- 分数答案必须约分，分母为正。
- 近似答案必须在题干中明确误差要求，并配置 `tolerance`。
- 表达式答案只用于可通过精确代数比较的式子；`accept` 列出审核过的等价形式。不要用“随便取几个点相等”来判定。
- 无穷、负无穷、极限不存在必须用 `symbol` 专用选项，题干要说明填法。
- 非选择题必须写 `formatHint`，说明填分数、整数、小数、表达式还是“不存在”。
- 选择题至少 3 个选项（建议 4 个），选项编号 A/B/C/D 不重复。

### 提示与解析

- 三条提示，逐级展开：
  1. 思路或需要观察的条件；
  2. 关键运算或下一步；
  3. 主要计算过程。
- 任何一级都不得直接给出最终答案；三级提示可以写出大部分算式，但最后一步留给学生。
- `solution` 展示完整推导、最终答案与注意事项。解析中的公式必须用 `$...$` 包裹。
- 不使用“显然”“易知”“不认真”等措辞；不省略分母非零、根号范围、定义域等条件。

## 数学写法

行内公式用 `$...$`，独立公式用 `math` 块。支持的命令：

`\frac \dfrac \sqrt \text \mathrm \mathbb \overline \left \right \lim \to \infty \cdot \times \div \pm \le \ge \ne \approx \equiv \Delta \delta \varepsilon \alpha \theta \pi \sin \cos \tan \ln \log \exp \max \min \sum \int \in \notin \subset \subseteq \cup \cap \emptyset \Rightarrow \Leftrightarrow \cdots \ldots \circ \checkmark`

不要使用 `\begin`、矩阵、多行对齐；分段内容用表格或图像。所有 `$` 必须配对，所有 `{` 必须配对。

## 来源与措辞

- 课件整理的术语与顺序以 manifest 和现有笔记为准；基础补充要明确标为补充，不冒充课件原题。
- 原创练习题 `source.kind` 用 `original`，`ref` 写“按本节知识点编写”。
- 涉及经济含义时只用“多一个单位大约多多少”，不引入复杂经济学。

## 保存后的自动更新

编辑并保存上述 JSON 后，运行中的服务会自动重新载入，不需要重启。服务端比较的是全部内容文件的原文摘要，因此即使忘记提升 `version`，只改标题或一段讲解也会触发页面更新。

- 校验问题变多时，新内容不会生效，旧内容继续提供服务；看服务端日志中的 `[content] 热更新未应用`。
- 已开始的练习会话使用提交时的题目快照，不会因为热更新而改变。
- 浏览器自动刷新规则与部署注意事项见 [内容更新与自动刷新](content-update.md)。

## 自检清单

1. 9 道题，3 难度 × 3 角色齐全。
2. 每题三条提示、完整解析、格式说明。
3. 所有答案重新算过一遍；分式已约分；负数、零、定义域条件都检查。
4. 选择题正确项与解析一致；干扰项不是明显重复。
5. 题干没有依赖未在本节或前置节出现的概念。
6. 没有占位文字、没有空题、没有“略”。
7. 运行 `npm run validate:content`，本知识点没有错误。

## 样板

参考已完成的：

- `content/knowledge-points/limits-01-approach.json`
- `content/questions/limits-01-approach.json`

它们展示了叙述节奏、提示层级与 JSON 结构。可以模仿结构，但必须按本知识点的 manifest 元数据重新写内容。
