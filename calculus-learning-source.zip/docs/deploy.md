# 部署、备份与回滚

## 1. 本地运行

```bash
cd D:/obsidian/calculus-learning
cp .env.example .env
npm start
```

默认地址 `http://127.0.0.1:3000`。首次注册的账号直接生效；站点已有账号后，注册受 `APP_ALLOW_REGISTRATION` 与 `SIGNUP_CODE` 控制。

生产使用前至少修改：

```dotenv
SESSION_SECRET=一串足够长的随机字符
SIGNUP_CODE=只有自己知道的邀请码
APP_ALLOW_REGISTRATION=false
```

若 `SESSION_SECRET` 留空，服务会在 `data/session.key` 自动生成并复用。该文件与会话 Cookie 等效敏感，不要提交到代码库或发给别人。

## 2. 局域网访问（手机 + 电脑）

```dotenv
HOST=0.0.0.0
ALLOW_LAN=true
```

重启后，用电脑的局域网 IP 访问，例如 `http://192.168.1.20:3000`。Windows 防火墙需要允许该端口的入站连接。只应在可信的家庭/宿舍网络中使用；不要做路由器端口映射。

若需要校外访问，使用 VPN（如 WireGuard/Tailscale）或带身份验证的反向代理，不要把站点直接暴露到公网。本次交付**没有验证任何公网部署**。

如果希望通过 GitHub + Cloudflare 获得公网 HTTPS 链接，同时保持私人访问，参见 [GitHub + Cloudflare 公网访问方案](cloudflare-deploy.md)。该方案使用 Cloudflare Tunnel + Access，不需要开放路由器端口。

## 3. 运行环境

- Node.js ≥ 22.18；本项目不依赖第三方 npm 包，`npm install` 只生成锁文件。
- 数据目录 `data/` 必须可写。
- 服务是单进程；SQLite 开启 WAL 与外键。不要用多个应用进程同时写同一个数据库文件。
- 静态文件和 API 由同一个端口提供，没有单独的构建步骤。

### 反向代理要点

如使用 Nginx/Caddy：

- 将整个站点（含 `/api`）转发到 Node 端口。
- 保留 `Cookie`、`Origin` 头；写接口会检查同源。
- 启用 HTTPS 后，会话 Cookie 会自动带 `Secure`（依据请求是否走 HTTPS）。
- 上传/请求体限制建议不低于 1 MB；应用自身只接受小体积 JSON。

## 4. 数据库迁移

- 迁移文件在 `server/migrations/`，按编号顺序执行。
- 使用 `PRAGMA user_version` 记录已执行版本；启动时自动执行尚未应用的迁移。
- 迁移原则是**向前兼容的增量变更**：只新增表、列、索引；不删表、不改写已有学习记录。
- 升级前备份 `data/`；升级后如发现应用版本有问题，回滚应用代码即可，数据库保持新结构，旧代码应能继续读取（新增列有默认值或可空）。

## 5. 内容更新与热重载

修改 `content/knowledge-points/`、`content/questions/`、`content/archive/` 或 `content/formulas.json` 后，服务会自动重新载入，不需要重启进程。已打开的页面约 15 秒内自动刷新；练习、已开始会话、摸底和设置页只提示，下次进入时使用新内容。

如果新内容带来更多校验问题，服务保留旧内容并在日志中说明原因。部署到只读镜像时，应把 `content/` 作为挂载卷；修改镜像内文件不会影响运行中的容器。详见 [内容更新与自动刷新](content-update.md)。

## 6. 备份

最稳妥的方式是停止服务后复制整个 `data/`：

```bash
# 先停止 npm start，再执行
cp -a data "backup-data-$(date +%Y%m%d-%H%M%S)"
```

不要只复制 `calculus.db` 而遗漏 `calculus.db-wal` 和 `calculus.db-shm`，否则可能丢失最近提交。

也可以在服务运行时通过网页「设置 → 导出我的数据」获得个人学习数据的 JSON 副本。该导出不包含密码摘要和 Agent 令牌摘要。

## 7. 回滚

1. 停止服务。
2. 将应用代码恢复到上一个可用版本（Git 或保留的目录副本）。
3. 数据库**不要删表回滚**。新版本只做增量迁移，旧版本可以继续使用新结构；若旧版本确实无法读取，恢复升级前的 `data/` 备份。
4. 启动并检查 `GET /api/health`，再用一个测试账号完成一次登录、开始会话、提交答案。

应用版本回滚优先于数据库回滚；学习记录不应因为回滚而被删除。

## 8. 访问控制与隐私

- 站点默认只监听本机；没有公开注册入口以外的暴露面。
- 所有站内接口都要求登录；用户之间不能读取彼此的会话、错题或统计。
- Agent 令牌只保存 SHA-256 摘要，明文只显示一次；可随时在设置中撤销。
- AI 密钥只从环境变量读取，不写入数据库、不返回前端。
- 日志中不记录密码、Cookie 或令牌明文。

## 9. 已知部署阻塞

本次环境没有平台托管、平台账号或 D1 数据库能力，npm 外部网络也不可用。因此无法按原计划部署为平台站点，也无法提供平台单点登录。当前交付是自托管替代方案；详见 `docs/limitations.md`。
