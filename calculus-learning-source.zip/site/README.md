# 静态介绍页

`site/index.html` 是完整学习站的公开介绍页，不包含题目答案、个人数据或登录信息。

它只用于介绍课程结构、学习循环和设计原则。完整功能（登录、判分、错题本、复习、SQLite 学习记录）仍由 Node 服务端提供，不能由这个静态页替代。

## 本地预览

直接双击 `site/index.html`，或在项目根目录运行：

```bash
python -m http.server 8080 --directory site
```

然后打开 `http://127.0.0.1:8080`。

## 发布到 Cloudflare Pages

推荐用 Cloudflare Pages 连接 GitHub 私有仓库：

- Framework preset：None
- Build command：留空
- Build output directory：`site`

这样只有 `site/` 会被发布，服务端代码、`.env` 和 `data/` 不会进入静态站点。

## 发布到 GitHub Pages

GitHub Pages 对私有仓库的可用性取决于 GitHub 账户计划。如果账户支持，用 GitHub Actions 把 `site/` 作为 Pages artifact 发布，或把仓库的 Pages 源设置为包含 `index.html` 的目录。不要把整个项目根目录直接作为公开静态站点发布。

## 边界

- 这是介绍页，不是可用的练习站。
- 不要在 `site/` 中放题库 JSON、`.env`、数据库或任何答案。
- 完整学习站的公网入口仍按 [Windows 部署手册](../docs/windows-deploy.md) 和 [GitHub + Cloudflare 方案](../docs/cloudflare-deploy.md) 配置。
